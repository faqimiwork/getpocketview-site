// PocketView service worker.
import { setToken } from './license.js';
// Header changes are scoped to simulator tabs only, and are removed when the simulator closes.

const SIM_URL = chrome.runtime.getURL('simulator.html');
const SCRIPT_IDS = ['pv-frame-main', 'pv-frame-isolated'];

const SUBRESOURCE_TYPES = [
  'sub_frame', 'script', 'stylesheet', 'image', 'font', 'xmlhttprequest',
  'media', 'ping', 'websocket', 'other'
];

function isSim(url) {
  return typeof url === 'string' && url.startsWith(SIM_URL);
}

function simUrlFor(target) {
  return target ? `${SIM_URL}?url=${encodeURIComponent(target)}` : SIM_URL;
}

// Rule updates run one at a time so rule IDs never collide.
let queue = Promise.resolve();
function serial(fn) {
  queue = queue.catch(() => {}).then(fn);
  return queue;
}

// ---------- state (survives service worker restarts) ----------
async function getState() {
  const { pvTabs = {} } = await chrome.storage.session.get('pvTabs');
  return pvTabs;
}
async function setState(pvTabs) {
  await chrome.storage.session.set({ pvTabs });
}

async function nextRuleIds(count) {
  const rules = await chrome.declarativeNetRequest.getSessionRules();
  let max = rules.reduce((m, r) => Math.max(m, r.id), 0);
  return Array.from({ length: count }, () => ++max);
}

function platformFromUA(ua) {
  if (!ua) return null;
  if (ua.includes('iPhone')) return '"iOS"';
  if (ua.includes('Android')) return '"Android"';
  if (ua.includes('Macintosh')) return '"macOS"';
  return null;
}

async function applyRules(tabId, ua) {
  const pvTabs = await getState();
  const old = pvTabs[tabId]?.ruleIds || [];
  const [frameRuleId, uaRuleId] = await nextRuleIds(2);

  const addRules = [{
    id: frameRuleId,
    priority: 1,
    action: {
      type: 'modifyHeaders',
      responseHeaders: [
        { header: 'x-frame-options', operation: 'remove' },
        { header: 'content-security-policy', operation: 'remove' }
      ]
    },
    condition: { tabIds: [tabId], resourceTypes: ['sub_frame'] }
  }];

  const ruleIds = [frameRuleId];
  if (ua) {
    const mobile = /Mobile/.test(ua);
    const requestHeaders = [
      { header: 'user-agent', operation: 'set', value: ua },
      { header: 'sec-ch-ua-mobile', operation: 'set', value: mobile ? '?1' : '?0' }
    ];
    const platform = platformFromUA(ua);
    if (platform) requestHeaders.push({ header: 'sec-ch-ua-platform', operation: 'set', value: platform });
    addRules.push({
      id: uaRuleId,
      priority: 1,
      action: { type: 'modifyHeaders', requestHeaders },
      condition: { tabIds: [tabId], resourceTypes: SUBRESOURCE_TYPES }
    });
    ruleIds.push(uaRuleId);
  }

  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: old, addRules });
  pvTabs[tabId] = { ruleIds, ua, hosts: pvTabs[tabId]?.hosts || [], exiting: false };
  await setState(pvTabs);
  await ensureScripts(true);
}

async function releaseTab(tabId) {
  const pvTabs = await getState();
  const entry = pvTabs[tabId];
  if (!entry) return;
  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: entry.ruleIds });
  delete pvTabs[tabId];
  await setState(pvTabs);
  if (Object.keys(pvTabs).length === 0) await ensureScripts(false);
}

// Frame scripts run only while at least one simulator is open.
async function ensureScripts(on) {
  const registered = await chrome.scripting.getRegisteredContentScripts({ ids: SCRIPT_IDS });
  if (on && registered.length < SCRIPT_IDS.length) {
    if (registered.length) await chrome.scripting.unregisterContentScripts({ ids: registered.map(s => s.id) });
    await chrome.scripting.registerContentScripts([
      {
        id: 'pv-frame-main',
        js: ['frame-main.js'],
        matches: ['<all_urls>'],
        allFrames: true,
        runAt: 'document_start',
        world: 'MAIN',
        persistAcrossSessions: false
      },
      {
        id: 'pv-frame-isolated',
        js: ['frame-isolated.js'],
        matches: ['<all_urls>'],
        allFrames: true,
        runAt: 'document_start',
        persistAcrossSessions: false
      }
    ]);
  } else if (!on && registered.length) {
    await chrome.scripting.unregisterContentScripts({ ids: registered.map(s => s.id) });
  }
}

// ---------- entry points ----------
async function markExit(tabId) {
  const pvTabs = await getState();
  if (pvTabs[tabId]) { pvTabs[tabId].exiting = true; await setState(pvTabs); }
}

chrome.action.onClicked.addListener(async (tab) => {
  if (isSim(tab.url)) {
    await serial(() => markExit(tab.id));
    const target = new URL(tab.url).searchParams.get('url');
    if (target) chrome.tabs.update(tab.id, { url: target });
    else chrome.tabs.goBack(tab.id).catch(() => {});
    return;
  }
  const target = /^https?:/.test(tab.url || '') ? tab.url : '';
  chrome.tabs.update(tab.id, { url: simUrlFor(target) });
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'pv-page', title: 'View this page in PocketView', contexts: ['page'] });
    chrome.contextMenus.create({ id: 'pv-link', title: 'Open link in PocketView', contexts: ['link'] });
    chrome.contextMenus.create({ id: 'pv-studio', title: 'Open PocketView Studio', contexts: ['action'] });
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'pv-link' && info.linkUrl) {
    chrome.tabs.create({ url: simUrlFor(info.linkUrl), index: tab ? tab.index + 1 : undefined });
  } else if (info.menuItemId === 'pv-studio') {
    chrome.tabs.create({ url: chrome.runtime.getURL('studio.html') });
  } else if (info.menuItemId === 'pv-page' && tab) {
    chrome.tabs.update(tab.id, { url: simUrlFor(info.pageUrl || tab.url) });
  }
});

// Licence handed over by getpocketview.com (see site-bridge.js). Only that site may send it.
const LICENSE_ORIGINS = /^https:\/\/(getpocketview\.com|[a-z0-9-]+--getpocketview\.netlify\.app)$/;
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'pv:license:set') return;
  let origin = '';
  try { origin = new URL(sender.url || '').origin; } catch {}
  if (!LICENSE_ORIGINS.test(origin) || sender.id !== chrome.runtime.id) { sendResponse({ ok: false }); return; }
  setToken(msg.token, origin)
    .then((rec) => sendResponse({ ok: !!rec.token, pro: !!rec.plan?.pro }))
    .catch(() => sendResponse({ ok: false }));
  return true;
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;
  if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('pv:bg:')) return;
  if (tabId == null || !isSim(sender.url)) { sendResponse({ ok: false }); return; }

  serial(async () => {
    try {
      if (msg.type === 'pv:bg:register') await applyRules(tabId, msg.ua || null);
      else if (msg.type === 'pv:bg:release') await releaseTab(tabId);
      else if (msg.type === 'pv:bg:exit') await markExit(tabId);
      else if (msg.type === 'pv:bg:hosts') {
        const pvTabs = await getState();
        if (pvTabs[tabId]) { pvTabs[tabId].hosts = (msg.hosts || []).slice(0, 20); await setState(pvTabs); }
      }
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
  });
  return true;
});

chrome.tabs.onRemoved.addListener((tabId) => { serial(() => releaseTab(tabId)); });
// A simulated site that navigates the whole tab ("frame busting") would replace the
// simulator. Detect it, bring the simulator back, and ask it to contain that site.
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (!info.url || isSim(info.url)) return;
  serial(async () => {
    const pvTabs = await getState();
    const entry = pvTabs[tabId];
    if (!entry) return;
    let host = '';
    try { host = new URL(info.url).hostname; } catch (e) { /* ignore */ }
    if (!entry.exiting && host && entry.hosts.includes(host)) {
      entry.exiting = true;
      await setState(pvTabs);
      await chrome.tabs.update(tabId, { url: `${simUrlFor(info.url)}&contain=${encodeURIComponent(host)}` });
      return;
    }
    await releaseTab(tabId);
  });
});

// Clean up anything left over from a previous browser session.
chrome.runtime.onStartup.addListener(async () => {
  const rules = await chrome.declarativeNetRequest.getSessionRules();
  if (rules.length) await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: rules.map(r => r.id) });
  await setState({});
  await ensureScripts(false);
});
