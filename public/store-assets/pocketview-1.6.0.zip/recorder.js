// PocketView recorder: captures this tab, crops to the device (or mockup) area,
// draws touch indicators and encodes to MP4/WebM (MediaRecorder) or GIF (gifenc).
import { GIFEncoder, quantize, applyPalette } from './vendor/gifenc.js';

export function pickVideoMime() {
  const options = [
    ['video/mp4;codecs=avc1.640028', 'mp4'],
    ['video/mp4;codecs=avc1.42E01E', 'mp4'],
    ['video/mp4', 'mp4'],
    ['video/webm;codecs=vp9', 'webm'],
    ['video/webm;codecs=vp8', 'webm'],
    ['video/webm', 'webm']
  ];
  if (typeof MediaRecorder === 'undefined') return null;
  for (const [mime, ext] of options) if (MediaRecorder.isTypeSupported(mime)) return { mime, ext };
  return null;
}

const even = (n) => Math.max(2, Math.round(n / 2) * 2);

export class Recorder {
  /**
   * @param {object} o
   * @param {'video'|'gif'} o.format
   * @param {() => {x:number,y:number,w:number,h:number}} o.getRect  crop area in viewport CSS px
   * @param {{w:number,h:number}} o.size  output size in px
   * @param {() => Array} o.getTouches  [{x,y,down,downAt,upAt}] in viewport CSS px
   * @param {string} o.fill  background color behind the crop
   */
  constructor(o) {
    Object.assign(this, o);
    this.fps = o.format === 'gif' ? 10 : 30;
    this.maxMs = o.format === 'gif' ? 20000 : 180000;
    this.stopped = false;
  }

  async start() {
    this.stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: { ideal: 30, max: 30 }, displaySurface: 'browser' },
      audio: false,
      preferCurrentTab: true,
      selfBrowserSurface: 'include',
      surfaceSwitching: 'exclude',
      monitorTypeSurfaces: 'exclude'
    });
    const track = this.stream.getVideoTracks()[0];
    track.addEventListener('ended', () => this.stop());

    this.video = document.createElement('video');
    this.video.muted = true;
    this.video.playsInline = true;
    this.video.srcObject = this.stream;
    await this.video.play();
    for (let i = 0; i < 50 && !this.video.videoWidth; i++) await new Promise((r) => setTimeout(r, 40));

    this.canvas = document.createElement('canvas');
    this.canvas.width = even(this.size.w);
    this.canvas.height = even(this.size.h);
    this.ctx = this.canvas.getContext('2d', { willReadFrequently: this.format === 'gif' });
    this.startedAt = performance.now();

    if (this.format === 'gif') {
      this.gif = GIFEncoder();
      this.timer = setInterval(() => this.gifFrame(), 1000 / this.fps);
    } else {
      const pick = pickVideoMime();
      if (!pick) throw new Error('This browser cannot record video.');
      this.ext = pick.ext;
      this.mime = pick.mime;
      const out = this.canvas.captureStream(this.fps);
      this.chunks = [];
      this.mr = new MediaRecorder(out, { mimeType: pick.mime, videoBitsPerSecond: 10_000_000 });
      this.mr.ondataavailable = (e) => { if (e.data && e.data.size) this.chunks.push(e.data); };
      this.done = new Promise((resolve) => { this.mr.onstop = resolve; });
      this.mr.start(500);
      this.timer = setInterval(() => this.draw(), 1000 / this.fps);
    }
    this.draw();
    this.guard = setTimeout(() => this.stop(), this.maxMs);
  }

  elapsed() { return performance.now() - (this.startedAt || performance.now()); }

  draw() {
    const { ctx, canvas, video } = this;
    if (!video.videoWidth) return;
    const r = this.getRect();
    const kx = video.videoWidth / window.innerWidth;
    const ky = video.videoHeight / window.innerHeight;
    ctx.fillStyle = this.fill || '#0f1218';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    try {
      ctx.drawImage(video, r.x * kx, r.y * ky, r.w * kx, r.h * ky, 0, 0, canvas.width, canvas.height);
    } catch (e) { /* frame not ready */ }

    // touch indicators
    const now = performance.now();
    const sx = canvas.width / r.w;
    for (const t of this.getTouches()) {
      const x = (t.x - r.x) * sx;
      const y = (t.y - r.y) * sx;
      if (t.down) {
        ctx.beginPath();
        ctx.arc(x, y, 20 * sx, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,255,255,0.35)';
        ctx.fill();
        ctx.lineWidth = 2.5 * sx;
        ctx.strokeStyle = 'rgba(30,30,30,0.35)';
        ctx.stroke();
      }
      const since = now - (t.downAt || 0);
      if (since < 450) {
        const p = since / 450;
        ctx.beginPath();
        ctx.arc(x, y, (20 + 26 * p) * sx, 0, Math.PI * 2);
        ctx.lineWidth = 3 * sx;
        ctx.strokeStyle = `rgba(255,255,255,${0.7 * (1 - p)})`;
        ctx.stroke();
      }
    }
  }

  gifFrame() {
    this.draw();
    const { width: w, height: h } = this.canvas;
    const { data } = this.ctx.getImageData(0, 0, w, h);
    const palette = quantize(data, 256, { format: 'rgb444' });
    const index = applyPalette(data, palette, 'rgb444');
    this.gif.writeFrame(index, w, h, { palette, delay: Math.round(1000 / this.fps) });
  }

  async stop() {
    if (this.stopped) return this.result;
    this.stopped = true;
    clearInterval(this.timer);
    clearTimeout(this.guard);
    this.result = (async () => {
      let blob, ext;
      if (this.format === 'gif') {
        this.gif.finish();
        blob = new Blob([this.gif.bytes()], { type: 'image/gif' });
        ext = 'gif';
      } else {
        if (this.mr.state !== 'inactive') this.mr.stop();
        await this.done;
        blob = new Blob(this.chunks, { type: this.mime.split(';')[0] });
        ext = this.ext;
      }
      this.stream.getTracks().forEach((t) => t.stop());
      return { blob, ext };
    })();
    if (this.onStop) this.onStop();
    return this.result;
  }
}
