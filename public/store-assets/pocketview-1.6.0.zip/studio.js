// PocketView Studio: full mockup editor.
import { DEVICES } from './devices.js';
import {
  FINISHES, CANVAS_GROUPS, CANVAS_PRESETS, LAYOUTS, SHADOWS, SCREEN_STYLES, deviceById, kindOf, renderScene,
  renderDevice, applyLayout, paletteFrom, autoInk, migrate, defaultsInto, cameraOf, geometry, styleOf, FONTS, WM_STYLES, drawWatermark,
  mediaOf
} from './studio-render.js';
import { SHADOW_SCENES } from './studio-scene.js';
const LK = (p) => p.looks[p.style.frame];
import { BG_CATEGORIES, BACKGROUNDS, bgById, paintPreset, magicPreset, MAGIC_STYLES, wallpaperUrl } from './studio-bg.js';
import { putImage, getImage, setKV, getKV, delKV } from './studio-store.js';
import { getLicense, isPro } from './license.js';
import { openAccount, wirePlanButton } from './account-ui.js';

// Free exports at 1x with a small PocketView badge; Pro exports up to 4x without it.
let PRO = isPro(await getLicense());

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const clone = (o) => JSON.parse(JSON.stringify(o));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const FINISH_NAME = Object.fromEntries(FINISHES.map(([id, , n]) => [id, n]));

// ---------- project ----------
function newItem(deviceId = 'iphone-17-pro', from = {}) {
  const dev = deviceById(deviceId);
  return {
    device: dev.id,
    finish: dev.colors ? dev.colors[0] : (kindOf(dev) === 'laptop' ? 'silver' : 'midnight'),
    image: null, iw: 0, ih: 0, landscape: false, open: !!(dev.fold && dev.fold.defaultOpen),
    focusX: 0.5, focusY: 0, host: '',
    cx: 0.5, cy: 0.5, s: 0.92, rot: 0, rx: 0, ry: 0, rz: 0, z: 0, blur: 0, share: 1,
    ...from
  };
}
function newProject() {
  const P = defaultsInto({
    v: 2,
    size: { preset: 'portrait', w: 1080, h: 1350 },
    padding: 8,
    bg: { kind: 'preset', id: 'pv-pocket', color: '#0d1016', image: null, palette: [], magic: 'mesh' },
    text: { on: true, title: 'Your app, ready to post', sub: 'Made in PocketView Studio', pos: 'top', align: 'center', size: 7, color: 'auto' },
    items: [newItem()],
    layout: 'center'
  });
  applyLayout(P, LAYOUTS[1][0]);
  return P;
}

let P = newProject();
let sel = 0;
const images = new Map(); // id -> ImageBitmap (uploads, and wallpapers as "wp:<file>" / "wpt:<file>")
let hits = [];
const undoStack = [];
const redoStack = [];
let lastMerge = { key: null, at: 0 };
let exportFmt = 'png';
let exportScale = PRO ? 2 : 1;

// ---------- history ----------
function change(fn, mergeKey = null) {
  const now = Date.now();
  const merge = mergeKey && lastMerge.key === mergeKey && now - lastMerge.at < 800;
  if (!merge) {
    undoStack.push(JSON.stringify(P));
    if (undoStack.length > 80) undoStack.shift();
    redoStack.length = 0;
  }
  lastMerge = { key: mergeKey, at: now };
  fn(P);
  afterChange();
}
function undo() {
  if (!undoStack.length) return;
  redoStack.push(JSON.stringify(P));
  P = JSON.parse(undoStack.pop());
  sel = clamp(sel, 0, P.items.length - 1);
  lastMerge = { key: null, at: 0 };
  afterChange();
}
function redo() {
  if (!redoStack.length) return;
  undoStack.push(JSON.stringify(P));
  P = JSON.parse(redoStack.pop());
  sel = clamp(sel, 0, P.items.length - 1);
  afterChange();
}
let saveTimer = 0;
function afterChange() {
  syncUI();
  requestRender();
  scheduleThumbs();
  ensureWallpaper();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => setKV('project', P).catch(() => {}), 400);
}

// ---------- images ----------
async function loadBitmap(id) {
  if (!id || images.has(id)) return images.get(id);
  try {
    const blob = await getImage(id);
    if (!blob) return null;
    const bmp = await createImageBitmap(blob);
    images.set(id, bmp);
    return bmp;
  } catch { return null; }
}
async function addImageBlob(blob) {
  const bmp = await createImageBitmap(blob);
  const id = await putImage(blob);
  images.set(id, bmp);
  return id;
}
async function ensureImages() {
  const ids = [...P.items.flatMap((i) => [i.image, i.clean]), P.bg.image].filter(Boolean);
  await Promise.all(ids.map(loadBitmap));
}
function firstImage() {
  for (const it of P.items) { const b = images.get(it.image); if (b) return b; }
  return null;
}
const urlBitmaps = new Map();
function loadUrl(key, url) {
  if (images.has(key)) return Promise.resolve(images.get(key));
  if (urlBitmaps.has(key)) return urlBitmaps.get(key);
  const p = fetch(url).then((r) => r.blob()).then(createImageBitmap).then((b) => { images.set(key, b); return b; }).catch(() => null);
  urlBitmaps.set(key, p);
  return p;
}
function ensureWallpaper() {
  if (P.bg.kind !== 'preset') return;
  const b = bgById(P.bg.id);
  if (!b || b.kind !== 'wallpaper' || images.has(`wp:${b.file}`)) return;
  loadUrl(`wpt:${b.file}`, wallpaperUrl(b.file, true)).then(() => requestRender());
  loadUrl(`wp:${b.file}`, wallpaperUrl(b.file, false)).then(() => { requestRender(); scheduleThumbs(); });
}

async function placeImage(blob, index = sel) {
  if (!blob || !blob.type.startsWith('image/')) { toast('That file is not an image.'); return; }
  const id = await addImageBlob(blob);
  const target = P.items[index] ? index : 0;
  const bmp = images.get(id);
  const pal = paletteFrom(bmp);
  change((p) => {
    const it = p.items[target];
    it.image = id; it.iw = bmp.width; it.ih = bmp.height; it.focusY = 0; it.captured = false; it.clean = null;
    if (!p.bg.palette?.length || target === 0) p.bg.palette = pal;
  });
}

// ---------- rendering ----------
const view = $('#view'), overlay = $('#overlay');
let previewScale = 1;
let renderQueued = false;
function requestRender() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => { renderQueued = false; render(); });
}
function fitCanvas() {
  const stage = $('#stage').getBoundingClientRect();
  const pad = 48;
  const s = Math.min((stage.width - pad * 2) / P.size.w, (stage.height - pad * 2) / P.size.h);
  previewScale = Math.max(0.05, s);
  const cw = Math.round(P.size.w * previewScale), ch = Math.round(P.size.h * previewScale);
  const dpr = window.devicePixelRatio || 1;
  for (const c of [view, overlay]) {
    c.style.width = `${cw}px`; c.style.height = `${ch}px`;
    c.width = Math.round(cw * dpr); c.height = Math.round(ch * dpr);
  }
  $('#canvasWrap').classList.toggle('checker', P.bg.kind === 'transparent');
}
function render() {
  fitCanvas();
  const ctx = view.getContext('2d');
  ctx.clearRect(0, 0, view.width, view.height);
  const dpr = window.devicePixelRatio || 1;
  hits = renderScene(ctx, P, images, { scale: previewScale * dpr, placeholder: true, watermark: !PRO });
  drawOverlay();
  drawCamPad();
}
function drawOverlay() {
  const ctx = overlay.getContext('2d');
  ctx.clearRect(0, 0, overlay.width, overlay.height);
  const h = hits[sel];
  if (!h || (P.items.length < 2 && !dragging)) return;
  const dpr = window.devicePixelRatio || 1;
  const k = previewScale * dpr;
  ctx.save();
  ctx.strokeStyle = '#c6f432';
  ctx.lineWidth = 2 * dpr;
  ctx.setLineDash([6 * dpr, 5 * dpr]);
  ctx.beginPath();
  h.quad.forEach(([x, y], i) => (i ? ctx.lineTo(x * k, y * k) : ctx.moveTo(x * k, y * k)));
  ctx.closePath();
  ctx.stroke();
  ctx.restore();
}

// ---------- thumbnails ----------
function fitInto(c, src, pad = 0.12) {
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  const s = Math.min(c.width * (1 - pad * 2) / src.width, c.height * (1 - pad * 2) / src.height);
  const w = src.width * s, h = src.height * s;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(src, (c.width - w) / 2, (c.height - h) / 2, w, h);
}
function deviceThumb(item, style, size = 120) {
  const g = geometry(item, style);
  const k = size / Math.max(g.W, g.H);
  return renderDevice(item, style, images.get(mediaOf(item, style).id) || null, k).canvas;
}
function makeCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }

let thumbTimer = 0;
function scheduleThumbs() { clearTimeout(thumbTimer); thumbTimer = setTimeout(renderThumbs, 160); }
function buildLayoutButtons() {
  const n = P.items.length;
  const box = $('#layouts');
  box.innerHTML = '';
  for (const l of LAYOUTS[n]) {
    const b = document.createElement('button');
    b.dataset.id = l.id;
    b.title = l.name;
    const span = document.createElement('span');
    span.textContent = l.name;
    b.append(makeCanvas(10, 10), span);
    b.addEventListener('click', () => change((p) => applyLayout(p, l)));
    box.appendChild(b);
  }
  box.dataset.n = n;
}
function renderThumbs() {
  const n = P.items.length;
  if ($('#layouts').dataset.n !== String(n)) buildLayoutButtons();
  const tw = 250;
  const s = tw / P.size.w;
  for (const b of $$('#layouts button')) {
    const l = LAYOUTS[n].find((x) => x.id === b.dataset.id);
    b.classList.toggle('on', P.layout === l.id);
    const c = b.querySelector('canvas');
    c.width = Math.round(P.size.w * s); c.height = Math.round(P.size.h * s);
    const q = clone(P);
    applyLayout(q, l);
    q.text.on = false; q.camera = { zoom: 1, fx: 0.5, fy: 0.5, rx: 0, ry: 0 };
    renderScene(c.getContext('2d'), q, images, { scale: s });
  }
  renderStyleThumbs();
  renderShadowThumbs();
  renderMagicThumbs();
  renderPickThumb();
  renderMediaThumb();
}

// Style row: device colours, browser looks or screenshot styles, each drawn with the real image.
function renderStyleThumbs() {
  const grid = $('#styleGrid');
  const it = P.items[sel];
  const dev = deviceById(it.device);
  let opts;
  if (P.style.frame === 'device') {
    const list = dev.colors || FINISHES.map((f) => f[0]).filter((f) => !['red', 'orange', 'blue', 'pink', 'mint', 'pistachio', 'violetgreen', 'violetshadow', 'nightsky', 'starwhite'].includes(f));
    opts = list.map((f) => ({ key: f, name: FINISH_NAME[f] || f, on: it.finish === f && !P.style.hideFrame, item: { ...it, finish: f }, style: { ...P.style, hideFrame: false } }));
  } else if (P.style.frame === 'browser') {
    opts = [false, true].map((dark) => ({ key: dark ? 'dark' : 'light', name: dark ? 'Dark' : 'Light', on: !!LK(P).dark === dark, item: it, style: { ...styleOf(P), dark } }));
  } else {
    opts = SCREEN_STYLES.map((s) => ({ key: s.id, name: s.name, on: LK(P).screenStyle === s.id, item: it, style: { ...styleOf(P), screenStyle: s.id } }));
  }
  const sig = `${P.style.frame}|${opts.map((o) => o.key).join(',')}`;
  if (grid.dataset.sig !== sig) {
    grid.dataset.sig = sig;
    grid.innerHTML = '';
    for (const o of opts) {
      const b = document.createElement('button');
      b.dataset.key = o.key;
      b.append(makeCanvas(160, 160));
      const sp = document.createElement('span'); sp.textContent = o.name; b.append(sp);
      b.title = o.name;
      b.addEventListener('click', () => change((p) => {
        if (p.style.frame === 'device') { p.items[sel].finish = o.key; p.style.hideFrame = false; }
        else if (p.style.frame === 'browser') LK(p).dark = o.key === 'dark';
        else LK(p).screenStyle = o.key;
      }));
      grid.appendChild(b);
    }
  }
  const bgThumb = makeCanvas(160, 160);
  paintThumbBg(bgThumb);
  opts.forEach((o, i) => {
    const b = grid.children[i];
    b.classList.toggle('on', o.on);
    const c = b.querySelector('canvas');
    const ctx = c.getContext('2d');
    ctx.clearRect(0, 0, 160, 160);
    if (P.style.frame === 'screen') ctx.drawImage(bgThumb, 0, 0);
    ctx.imageSmoothingQuality = 'high';
    if (P.style.frame === 'device') {
      // Colour swatches: a close-up of the device's top corner with a dark screen, so the
      // finish is what you see.
      const src = deviceThumb({ ...o.item, image: null, landscape: false }, o.style, 420);
      const w = 160 * 2.4, h = src.height * w / src.width;
      ctx.drawImage(src, 160 * 0.16, 160 * 0.16, w, h);
    } else {
      const src = deviceThumb(o.item, o.style, 150);
      const s = Math.min(160 * 0.72 / src.width, 160 * 0.72 / src.height);
      const w = src.width * s, h = src.height * s;
      ctx.drawImage(src, (160 - w) / 2, (160 - h) / 2, w, h);
    }
  });
}
function paintThumbBg(c) {
  const ctx = c.getContext('2d');
  if (P.bg.kind === 'transparent') { ctx.fillStyle = '#2a2f3a'; ctx.fillRect(0, 0, c.width, c.height); return; }
  const fake = { ...P, size: { w: c.width, h: c.height }, items: [], text: { on: false }, fx: { ...P.fx, wm: { on: false } }, scene: { kind: 'none' } };
  renderScene(ctx, fake, images, { scale: 1 });
}
function renderShadowThumbs() {
  const grid = $('#shadowGrid');
  if (!grid.children.length) {
    for (const s of SHADOWS) {
      const b = document.createElement('button');
      b.dataset.v = s.id; b.title = s.name;
      b.append(makeCanvas(120, 120));
      const sp = document.createElement('span'); sp.textContent = s.name; b.append(sp);
      b.addEventListener('click', () => change((p) => { LK(p).shadow = s.id; }));
      grid.appendChild(b);
    }
  }
  const sig = `${(P.bg.palette || []).join()}|${LK(P).light}|${LK(P).lightDist}|${LK(P).shadowOpacity}`;
  for (const b of grid.children) {
    b.classList.toggle('on', LK(P).shadow === b.dataset.v);
    const c = b.querySelector('canvas');
    if (c.dataset.sig === sig) continue;
    c.dataset.sig = sig;
    const q = {
      v: 2, size: { w: 120, h: 120 }, padding: 0,
      bg: { kind: 'color', color: '#e9eaee', palette: P.bg.palette },
      fx: { noise: 0, blur: 0, vignette: 0, leak: 0, wm: { on: false } }, scene: { kind: 'none' },
      camera: { zoom: 1, fx: 0.5, fy: 0.5, rx: 0, ry: 0 },
      style: { ...styleOf(P), frame: 'screen', screenStyle: 'default', radius: 8, shadow: b.dataset.v },
      text: { on: false }, items: [{ ...newItem(), iw: 1000, ih: 1000, image: '__white', cx: 0.62, cy: 0.6, s: 0.62 }]
    };
    const ctx = c.getContext('2d');
    ctx.clearRect(0, 0, 120, 120);
    renderScene(ctx, q, new Map([['__white', whiteSquare()]]), { scale: 1 });
  }
}
let white = null;
function whiteSquare() { if (!white) { white = makeCanvas(8, 8); const x = white.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, 8, 8); } return white; }
function renderMagicThumbs() {
  const grid = $('#magicGrid');
  if (!grid.children.length) {
    for (const m of MAGIC_STYLES) {
      const b = document.createElement('button');
      b.dataset.v = m.id; b.title = `Magic ${m.name}`;
      b.append(makeCanvas(96, 66));
      b.addEventListener('click', () => setMagic(m.id));
      grid.appendChild(b);
    }
  }
  const sig = (P.bg.palette || []).join();
  for (const b of grid.children) {
    b.classList.toggle('on', P.bg.kind === 'magic' && P.bg.magic === b.dataset.v);
    const c = b.querySelector('canvas');
    if (c.dataset.sig === sig) continue;
    c.dataset.sig = sig;
    paintPreset(c.getContext('2d'), magicPreset(b.dataset.v, P.bg.palette), 96, 66, images);
  }
}
function renderPickThumb() {
  const it = P.items[sel];
  fitInto($('#pickThumb'), deviceThumb(it, { ...P.style, frame: 'device', hideFrame: false }, 80), 0.08);
}
function renderMediaThumb() {
  const it = P.items[sel];
  const img = images.get(mediaOf(it, styleOf(P)).id);
  const c = $('#mediaThumb');
  $('#mediaEmpty').hidden = !!img;
  c.hidden = !img;
  $('#mediaBtns').hidden = !img;
  if (!img) return;
  const h = 104, w = Math.round(h * img.width / img.height);
  c.width = Math.min(w, 270); c.height = h;
  const s = Math.max(c.width / img.width, c.height / img.height);
  c.getContext('2d').drawImage(img, (c.width - img.width * s) / 2, 0, img.width * s, img.height * s);
}

// ---------- camera pad ----------
let camMode = 'zoom';
function drawCamPad() {
  const c = $('#camCanvas');
  const w = 252, h = Math.round(w * P.size.h / P.size.w);
  const ch = Math.min(h, 200);
  const cw = Math.round(ch * P.size.w / P.size.h);
  if (c.width !== cw * 2 || c.height !== ch * 2) { c.width = cw * 2; c.height = ch * 2; }
  c.style.width = `${cw}px`; c.style.height = `${ch}px`;
  $('#camPad').style.width = `${cw}px`; $('#camPad').style.margin = '0 auto';
  const q = { ...P, camera: { zoom: 1, fx: 0.5, fy: 0.5, rx: P.camera.rx, ry: P.camera.ry }, text: { ...P.text } };
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  renderScene(ctx, q, images, { scale: c.width / P.size.w });
  const cam = cameraOf(P);
  const r = $('#camRect');
  r.hidden = camMode !== 'zoom';
  r.style.width = `${cw / cam.z}px`; r.style.height = `${ch / cam.z}px`;
  r.style.left = `${cam.fx * cw - cw / cam.z / 2}px`; r.style.top = `${cam.fy * ch - ch / cam.z / 2}px`;
  const d = $('#camDot');
  d.hidden = camMode !== 'tilt';
  d.style.left = `${(0.5 + (P.camera.ry || 0) / 80) * cw}px`;
  d.style.top = `${(0.5 - (P.camera.rx || 0) / 80) * ch}px`;
}
function wireCamPad() {
  const pad = $('#camPad');
  let active = false;
  const apply = (e, merge) => {
    const r = pad.getBoundingClientRect();
    const x = clamp((e.clientX - r.left) / r.width, 0, 1), y = clamp((e.clientY - r.top) / r.height, 0, 1);
    const fine = e.shiftKey ? 0.25 : 1;
    if (camMode === 'zoom') {
      change((p) => { p.camera.fx = x; p.camera.fy = y; if (p.camera.zoom <= 1) p.camera.zoom = 1.6; }, merge);
    } else {
      change((p) => { p.camera.ry = Math.round((x - 0.5) * 80 * fine); p.camera.rx = Math.round((0.5 - y) * 80 * fine); }, merge);
    }
  };
  pad.addEventListener('pointerdown', (e) => { active = true; pad.setPointerCapture(e.pointerId); apply(e, 'cam'); });
  pad.addEventListener('pointermove', (e) => { if (active) apply(e, 'cam'); });
  pad.addEventListener('pointerup', () => { active = false; });
  $$('#camSeg button').forEach((b) => b.addEventListener('click', () => {
    camMode = b.dataset.v;
    setSeg('#camSeg', camMode);
    $('#zoomRow').hidden = camMode !== 'zoom';
    $('#tiltRow').hidden = camMode !== 'tilt';
    drawCamPad();
  }));
  $('#camZoom').addEventListener('input', (e) => change((p) => { p.camera.zoom = Number(e.target.value) / 100; }, 'zoom'));
  $('#tiltReset').addEventListener('click', () => change((p) => { p.camera.rx = 0; p.camera.ry = 0; }));
}

// ---------- background picker ----------
function buildBackgrounds() {
  const box = $('#bgCats');
  box.innerHTML = '';
  for (const cat of BG_CATEGORIES) {
    const list = BACKGROUNDS.filter((b) => b.cat === cat.id);
    if (!list.length) continue;
    const wrap = document.createElement('div');
    wrap.className = 'cat';
    wrap.innerHTML = `<div class="cat-head"><b>${cat.name}<small>${list.length}</small></b><button>Show all</button></div><div class="sw-grid"></div>`;
    const grid = wrap.querySelector('.sw-grid');
    const more = wrap.querySelector('.cat-head button');
    let open = false;
    const fill = () => {
      grid.innerHTML = '';
      for (const b of list.slice(0, open ? list.length : 4)) {
        const btn = document.createElement('button');
        btn.dataset.id = b.id; btn.title = b.name;
        if (b.kind === 'wallpaper') {
          const img = document.createElement('img');
          img.src = wallpaperUrl(b.file, true); img.alt = ''; img.loading = 'lazy';
          btn.appendChild(img);
        } else {
          const c = makeCanvas(96, 66);
          paintPreset(c.getContext('2d'), b, 96, 66, images);
          btn.appendChild(c);
        }
        btn.addEventListener('click', () => change((p) => { p.bg.kind = 'preset'; p.bg.id = b.id; }));
        grid.appendChild(btn);
      }
      more.textContent = list.length <= 4 ? '' : open ? 'Show less' : 'Show all';
      markBg();
    };
    more.addEventListener('click', () => { open = !open; fill(); });
    fill();
    box.appendChild(wrap);
  }
}
function markBg() {
  $$('#bgCats .sw-grid button').forEach((b) => b.classList.toggle('on', P.bg.kind === 'preset' && P.bg.id === b.dataset.id));
  $$('#bgQuick button').forEach((b) => b.classList.toggle('on', b.dataset.q === P.bg.kind));
}
function setMagic(style) {
  const img = firstImage();
  change((p) => {
    p.bg.kind = 'magic'; p.bg.magic = style;
    if (img && !p.bg.palette?.length) p.bg.palette = paletteFrom(img);
  });
  if (!img) toast('Add a screenshot and Magic will use its colors.');
}

// ---------- canvas size picker ----------
function sizeIcon(w, h, max = 26) {
  const s = max / Math.max(w, h);
  return `<i style="width:${Math.max(6, Math.round(w * s))}px;height:${Math.max(6, Math.round(h * s))}px"></i>`;
}
function buildSizes() {
  const box = $('#sizeGroups');
  box.innerHTML = CANVAS_GROUPS.map((g) => `<div class="size-group"><b>${g.name}</b><div class="size-items">${g.items.map(([id, name, w, h]) => `<button data-id="${id}" title="${w} × ${h}">${sizeIcon(w, h)}<span>${name}</span></button>`).join('')}</div></div>`).join('');
  box.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-id]');
    if (!b) return;
    const c = CANVAS_PRESETS.find((x) => x.id === b.dataset.id);
    change((p) => { p.size = { preset: c.id, w: c.w, h: c.h }; });
    $('#sizePop').hidden = true;
  });
  $('#sizeBtn').addEventListener('click', () => { $('#sizePop').hidden = !$('#sizePop').hidden; });
  $('#setSize').addEventListener('click', () => {
    change((p) => {
      p.size = { preset: 'custom', w: clamp(Number($('#cw').value) || 1080, 200, 6000), h: clamp(Number($('#ch').value) || 1080, 200, 6000) };
    });
    $('#sizePop').hidden = true;
  });
}

// ---------- UI sync ----------
function setSeg(id, value) { $$(`${id} button`).forEach((b) => b.classList.toggle('on', b.dataset.v === String(value))); }

function syncUI() {
  const it = P.items[sel] || P.items[0];
  const dev = deviceById(it.device);
  const st = styleOf(P);
  $('#undoBtn').disabled = !undoStack.length;
  $('#redoBtn').disabled = !redoStack.length;
  // Mockup tab
  setSeg('#frameSeg', st.frame);
  const multi = P.items.length > 1;
  $('#itemIndex').hidden = !multi;
  $('#itemIndex').innerHTML = multi ? `Editing <b>device ${sel + 1}</b> of ${P.items.length}. Click a device on the canvas, or press Tab, to switch.` : '';
  $('#deviceField').hidden = st.frame !== 'device';
  $('#deviceName').textContent = dev.name;
  const open = !!(dev.fold && it.open);
  const sw = open ? dev.fold.w : dev.w, sh = open ? dev.fold.h : dev.h;
  $('#deviceDims').textContent = `${sw} / ${sh}${dev.fold ? (open ? ' · open' : ' · folded') : ''}`;
  $('#focusY').value = Math.round((it.focusY ?? 0) * 100);
  $('#radiusField').hidden = st.frame === 'device';
  setSeg('#radiusSeg', st.radius);
  $('#radius').value = st.radius; $('#radiusVal').textContent = `${st.radius}`;
  $('#browserField').hidden = st.frame !== 'browser';
  if (document.activeElement !== $('#hostInput')) $('#hostInput').value = it.host || '';
  $('#shOp').value = Math.round((st.shadowOpacity ?? 1) * 100); $('#shOpVal').textContent = `${$('#shOp').value}%`;
  $('#lightAng').value = st.light ?? 90; $('#lightAngVal').textContent = `${st.light ?? 90}°`;
  $('#lightDist').value = Math.round((st.lightDist ?? 1) * 100); $('#lightDistVal').textContent = `${$('#lightDist').value}%`;
  $('#hideFrameBtn').hidden = st.frame !== 'device';
  $('#hideFrameBtn').classList.toggle('on', !!st.hideFrame);
  $('#glareBtn').hidden = st.frame !== 'device';
  $('#glareBtn').classList.toggle('on', !!st.glare);
  // Details
  const kind = kindOf(dev);
  const rows = st.frame === 'device'
    ? [['Device', dev.name], ['Screen (CSS px)', `${sw} × ${sh}`], ['Physical pixels', `${Math.round(sw * dev.dpr)} × ${Math.round(sh * dev.dpr)}`], ['Type', kind === 'phone' ? (dev.fold ? 'Foldable' : 'Phone') : kind[0].toUpperCase() + kind.slice(1)]]
    : [['Frame', st.frame === 'browser' ? 'Browser window' : 'Screenshot'], ['Image', it.iw ? `${mediaOf(it, st).iw} × ${mediaOf(it, st).ih}` : 'None yet']];
  $('#details').innerHTML = rows.map(([a, b]) => `<div><span>${a}</span><b>${b}</b></div>`).join('');
  // Frame tab
  const preset = CANVAS_PRESETS.find((c) => c.id === P.size.preset);
  $('#sizeName').textContent = preset ? `${preset.group === 'Ratio' ? 'Default' : preset.group} ${preset.name}` : 'Custom';
  $('#sizeDims').textContent = `${P.size.w} × ${P.size.h}`;
  $('#sizeIcon').innerHTML = sizeIcon(P.size.w, P.size.h, 24);
  $('#cw').value = P.size.w; $('#ch').value = P.size.h;
  $$('#sizeGroups button').forEach((b) => b.classList.toggle('on', b.dataset.id === P.size.preset));
  const fx = P.fx;
  const rng = (id, v, suffix = '%') => { $(`#${id}`).value = v; $(`#${id}Val`).textContent = `${v}${suffix}`; };
  rng('fxNoise', fx.noise); rng('fxBlur', fx.blur); rng('fxVig', fx.vignette); rng('fxLeak', fx.leak);
  $('#wmOn').checked = !!fx.wm.on;
  if (document.activeElement !== $('#wmText')) $('#wmText').value = fx.wm.text || '';
  setSeg('#wmPos', fx.wm.pos || 'br'); rng('wmOp', fx.wm.opacity ?? 100);
  setSeg('#wmTone', fx.wm.tone || 'light'); rng('wmSize', fx.wm.size ?? 100); rng('wmInset', fx.wm.inset ?? 4);
  $$('#wmStyles button').forEach((b) => b.classList.toggle('on', b.dataset.v === (fx.wm.style || 'badge')));
  $('#wmLogoClear').hidden = !fx.wm.logo;
  renderWmThumbs();
  $$('#fxTiles button').forEach((b) => {
    const k = b.dataset.fx;
    const active = k === 'bg' ? (fx.noise || fx.blur || fx.vignette) : k === 'leak' ? fx.leak : fx.wm.on;
    b.classList.toggle('on', !!active);
  });
  $$('#sceneTiles button').forEach((b) => b.classList.toggle('on', b.dataset.v === P.scene.kind));
  $('#shadowScene').hidden = P.scene.kind !== 'shadow';
  $('#sceneCtl').hidden = P.scene.kind === 'none';
  $('#sceneSoftRow').hidden = P.scene.kind !== 'shadow';
  $('#sceneFlipRow').hidden = P.scene.kind !== 'shadow';
  $$('#sceneShadowGrid button').forEach((b) => b.classList.toggle('on', P.scene.kind === 'shadow' && b.dataset.v === P.scene.shadow));
  rng('sceneAmt', P.scene.amount ?? 60); rng('sceneSoft', P.scene.soft ?? 50);
  $('#sceneFlip').checked = !!P.scene.flip;
  $('#colorIco').style.background = P.bg.kind === 'color' ? P.bg.color : '';
  $('#magicRow').hidden = P.bg.kind !== 'magic';
  markBg();
  rng('padding', P.padding);
  // Text tab
  $('#textOn').checked = !!P.text.on;
  if (document.activeElement !== $('#titleIn')) $('#titleIn').value = P.text.title;
  if (document.activeElement !== $('#subIn')) $('#subIn').value = P.text.sub;
  setSeg('#posSeg', P.text.pos); setSeg('#alignSeg', P.text.align);
  $('#textSize').value = P.text.size; $('#tsVal').textContent = Number(P.text.size).toFixed(1);
  $$('#fontGrid button').forEach((b) => b.classList.toggle('on', b.dataset.v === (P.text.font || 'hubot')));
  setSeg('#weightSeg', P.text.weight || 800);
  $('#subFont').value = P.text.subFont || 'inter';
  $('#inkAuto').classList.toggle('primary', P.text.color === 'auto');
  $('#inkColor').value = P.text.color === 'auto' ? autoInk(P.bg) : P.text.color;
  // Right panel
  setSeg('#countSeg', P.items.length);
  $('#camZoom').value = Math.round((P.camera.zoom || 1) * 100); $('#camZoomVal').textContent = `${$('#camZoom').value}%`;
  $('#selName').textContent = multi ? `#${sel + 1}` : '';
  const setR = (id, out, v, t) => { $(`#${id}`).value = v; $(`#${out}`).textContent = t; };
  setR('xs', 'sVal', Math.round(it.s * 100), `${Math.round(it.s * 100)}%`);
  setR('xrot', 'rotVal', it.rot || 0, `${it.rot || 0}°`);
  setR('xrx', 'rxVal', it.rx || 0, `${it.rx || 0}°`);
  setR('xry', 'ryVal', it.ry || 0, `${it.ry || 0}°`);
  $('#xrz').value = it.rz || 0; $('#rzVal').textContent = `${it.rz || 0}°`;
  $('#xblur').value = it.blur || 0; $('#blurVal').textContent = `${it.blur || 0}`;
  $('#sVal').textContent = `${Math.round(it.s * 100)}%`;
  $('#frontBtn').hidden = !multi;
  $('#exportTag').textContent = `${exportScale}x · ${exportFmt === 'jpeg' ? 'JPG' : exportFmt.toUpperCase()}`;
  $('#exportDims').textContent = `${P.size.w * exportScale} × ${P.size.h * exportScale} px`;
}

// Fonts load on demand; render again once the face is ready.
async function useFont(id, key) {
  const f = FONTS.find((x) => x.id === id);
  change((p) => { p.text[key] = id; p.text.on = true; });
  if (f) { await document.fonts.load(`700 40px ${f.family}`).catch(() => {}); await document.fonts.load(`400 40px ${f.family}`).catch(() => {}); requestRender(); }
}
function renderWmThumbs() {
  const wm = P.fx.wm;
  const logo = wm.logo ? images.get(wm.logo) : null;
  const lt = $('#wmLogoThumb');
  $('#wmLogoBtn').classList.toggle('has', !!logo);
  lt.getContext('2d').clearRect(0, 0, lt.width, lt.height);
  if (logo) fitInto(lt, logo, 0.08);
  const sig = `${wm.text}|${wm.tone}|${wm.logo}`;
  for (const b of $$('#wmStyles button')) {
    const c = b.querySelector('canvas');
    if (c.dataset.sig === sig) continue;
    c.dataset.sig = sig;
    const ctx = c.getContext('2d');
    paintPreset(ctx, bgById('pv-aurora'), 120, 120, images);
    drawWatermark(ctx, 120, 120, { text: (wm.text || 'Watermark').slice(0, 10), style: b.dataset.v, tone: wm.tone, pos: 'mc', size: 420, inset: 0, opacity: 100 }, logo);
  }
}

// ---------- controls ----------
function wireSeg(id, fn) { $$(`${id} button`).forEach((b) => b.addEventListener('click', () => fn(b.dataset.v))); }
function wireRange(id, key, fn) { $(id).addEventListener('input', (e) => change((p) => fn(p, Number(e.target.value)), key)); }

function buildStatic() {
  buildSizes();
  buildBackgrounds();
  // Scene: tiles, then a grid of shadow scenes drawn over a white card on a light backdrop.
  const sceneSample = (scene, w, h) => {
    const c = makeCanvas(w, h);
    const q = {
      v: 2, size: { w, h }, padding: 10, bg: { kind: 'color', color: '#e4e5e9', palette: [] },
      fx: { noise: 0, blur: 0, vignette: 0, leak: 0, wm: { on: false } }, scene, camera: { zoom: 1 },
      style: { frame: 'screen', screenStyle: 'default', radius: 10, shadow: 'soft', shadowOpacity: 1 }, text: { on: false },
      items: [{ ...newItem(), iw: 1000, ih: 1000, image: '__white', s: 0.55 }]
    };
    renderScene(c.getContext('2d'), q, new Map([['__white', whiteSquare()]]), { scale: 1 });
    return c;
  };
  $$('#sceneTiles button').forEach((b) => {
    const c = b.querySelector('canvas');
    if (c) {
      const sc = b.dataset.v === 'shadow' ? { kind: 'shadow', shadow: 'blinds', amount: 90, soft: 40 } : { kind: 'shapes', amount: 70 };
      c.getContext('2d').drawImage(sceneSample(sc, 120, 62), 0, 0);
    }
    b.addEventListener('click', () => change((p) => { p.scene.kind = b.dataset.v; }));
  });
  const ssg = $('#sceneShadowGrid');
  for (const sh of SHADOW_SCENES) {
    const b = document.createElement('button');
    b.dataset.v = sh.id; b.title = sh.name;
    b.appendChild(sceneSample({ kind: 'shadow', shadow: sh.id, amount: 100, soft: 45 }, 128, 80));
    b.addEventListener('click', () => change((p) => { p.scene.kind = 'shadow'; p.scene.shadow = sh.id; }));
    ssg.appendChild(b);
  }
  wireRange('#sceneSoft', 'ssoft', (p, v) => { p.scene.soft = v; });
  $('#sceneFlip').addEventListener('change', (e) => change((p) => { p.scene.flip = e.target.checked; }));

  // Watermark styles (rendered on a gradient so each look is visible)
  const wg = $('#wmStyles');
  for (const st of WM_STYLES) {
    const b = document.createElement('button');
    b.dataset.v = st.id; b.title = st.name;
    b.append(makeCanvas(120, 120));
    const sp = document.createElement('span'); sp.textContent = st.name; b.append(sp);
    b.addEventListener('click', () => change((p) => { p.fx.wm.style = st.id; p.fx.wm.on = true; }));
    wg.appendChild(b);
  }
  $('#wmLogoBtn').addEventListener('click', () => $('#wmFileIn').click());
  $('#wmFileIn').addEventListener('change', async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    const id = await addImageBlob(f);
    change((p) => { p.fx.wm.logo = id; p.fx.wm.on = true; });
  });
  $('#wmLogoClear').addEventListener('click', () => change((p) => { p.fx.wm.logo = null; }));
  wireSeg('#wmTone', (v) => change((p) => { p.fx.wm.tone = v; p.fx.wm.on = true; }));
  wireRange('#wmSize', 'wmsize', (p, v) => { p.fx.wm.size = v; });
  wireRange('#wmInset', 'wminset', (p, v) => { p.fx.wm.inset = v; });

  // Fonts
  const fg = $('#fontGrid');
  for (const f of FONTS) {
    const b = document.createElement('button');
    b.dataset.v = f.id;
    b.innerHTML = `<b style="font-family:${f.family.replace(/"/g, "'")};font-weight:${Math.min(700, f.max)}">Aa Headline</b><small>${f.name}</small>`;
    b.addEventListener('click', () => useFont(f.id, 'font'));
    fg.appendChild(b);
  }
  $('#subFont').innerHTML = FONTS.map((f) => `<option value="${f.id}">${f.name}</option>`).join('');
  $('#subFont').addEventListener('change', (e) => useFont(e.target.value, 'subFont'));
  wireSeg('#weightSeg', (v) => change((p) => { p.text.weight = Number(v); }));

  // Mockup tab
  wireSeg('#frameSeg', (v) => change((p) => {
    p.style.frame = v;
    if (v === 'browser') p.items.forEach((it) => { if (!it.host) it.host = 'getpocketview.com'; });
  }));
  $('#hostInput').addEventListener('input', (e) => change((p) => { p.items[sel].host = e.target.value; }, 'host'));
  wireSeg('#radiusSeg', (v) => change((p) => { LK(p).radius = Number(v); }));
  wireRange('#radius', 'radius', (p, v) => { LK(p).radius = v; });
  wireRange('#shOp', 'shop', (p, v) => { LK(p).shadowOpacity = v / 100; });
  $('#lightBtn').addEventListener('click', () => { $('#lightBox').hidden = !$('#lightBox').hidden; });
  wireRange('#lightAng', 'lang', (p, v) => { LK(p).light = v; });
  wireRange('#lightDist', 'ldist', (p, v) => { LK(p).lightDist = v / 100; });
  $('#hideFrameBtn').addEventListener('click', () => change((p) => { p.style.hideFrame = !p.style.hideFrame; }));
  $('#glareBtn').addEventListener('click', () => change((p) => { p.style.glare = !p.style.glare; }));
  wireRange('#focusY', 'focus', (p, v) => { p.items[sel].focusY = v / 100; });
  $('#mediaBox').addEventListener('click', () => $('#fileIn').click());
  $('#uploadBtn').addEventListener('click', () => $('#fileIn').click());
  $('#fileIn').addEventListener('change', async (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) await placeImage(f); });
  $('#clearImgBtn').addEventListener('click', () => change((p) => { Object.assign(p.items[sel], { image: null, iw: 0, ih: 0, clean: null }); }));

  // Device list
  const groups = ['All', 'Foldable', 'iPhone', 'Android', 'Tablet', 'Desktop'];
  let group = 'All';
  $('#devGroups').innerHTML = groups.map((g) => `<button data-v="${g}">${g}</button>`).join('');
  const listDevices = () => {
    const q = $('#devSearch').value.trim().toLowerCase();
    const cur = P.items[sel].device;
    const list = DEVICES.filter((d) => d.id !== 'responsive')
      .filter((d) => group === 'All' || d.group === group)
      .filter((d) => !q || d.name.toLowerCase().includes(q) || String(d.w) === q);
    $$('#devGroups button').forEach((b) => b.classList.toggle('on', b.dataset.v === group));
    $('#devItems').innerHTML = list.map((d) => `<button data-id="${d.id}" class="${d.id === cur ? 'on' : ''}"><span>${d.name}</span><small>${d.w}×${d.h}</small></button>`).join('')
      || '<p class="hint">No device matches that search.</p>';
  };
  $('#devicePickBtn').addEventListener('click', () => {
    const list = $('#devList');
    list.hidden = !list.hidden;
    if (!list.hidden) { listDevices(); $('#devSearch').focus(); }
  });
  $('#devSearch').addEventListener('input', listDevices);
  $('#devGroups').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) { group = b.dataset.v; listDevices(); } });
  $('#devItems').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-id]');
    if (!b) return;
    change((p) => {
      const it = p.items[sel];
      const dev = deviceById(b.dataset.id);
      it.device = dev.id;
      if (dev.colors && !dev.colors.includes(it.finish)) it.finish = dev.colors[0];
      if (!dev.colors && kindOf(dev) === 'laptop') it.finish = 'silver';
      it.open = !!(dev.fold && dev.fold.defaultOpen);
      if (kindOf(dev) !== 'phone' && kindOf(dev) !== 'tablet') it.landscape = false;
    });
    $('#devList').hidden = true;
  });

  // Frame tab
  $$('#fxTiles button').forEach((b) => b.addEventListener('click', () => {
    const box = document.querySelector(`.fx-box[data-box="${b.dataset.fx}"]`);
    const show = box.hidden;
    $$('.fx-box').forEach((x) => { x.hidden = true; });
    box.hidden = !show;
  }));
  wireRange('#fxNoise', 'noise', (p, v) => { p.fx.noise = v; });
  wireRange('#fxBlur', 'fblur', (p, v) => { p.fx.blur = v; });
  wireRange('#fxVig', 'vig', (p, v) => { p.fx.vignette = v; });
  wireRange('#fxLeak', 'leak', (p, v) => { p.fx.leak = v; });
  $('#wmOn').addEventListener('change', (e) => change((p) => { p.fx.wm.on = e.target.checked; }));
  $('#wmText').addEventListener('input', (e) => change((p) => { p.fx.wm.text = e.target.value; p.fx.wm.on = true; }, 'wmtext'));
  wireSeg('#wmPos', (v) => change((p) => { p.fx.wm.pos = v; p.fx.wm.on = true; }));
  wireRange('#wmOp', 'wmop', (p, v) => { p.fx.wm.opacity = v; });
  wireRange('#sceneAmt', 'samt', (p, v) => { p.scene.amount = v; });
  $$('#bgQuick button').forEach((b) => b.addEventListener('click', () => {
    const q = b.dataset.q;
    if (q === 'transparent') change((p) => { p.bg.kind = 'transparent'; });
    else if (q === 'color') $('#bgColor').click();
    else if (q === 'image') { if (P.bg.image) change((p) => { p.bg.kind = 'image'; }); else $('#bgFileIn').click(); }
    else setMagic(P.bg.magic || 'mesh');
  }));
  $('#bgColor').addEventListener('input', (e) => change((p) => { p.bg.kind = 'color'; p.bg.color = e.target.value; }, 'bgcolor'));
  $('#bgFileIn').addEventListener('change', async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    const id = await addImageBlob(f);
    change((p) => { p.bg.kind = 'image'; p.bg.image = id; });
  });
  wireRange('#padding', 'pad', (p, v) => { p.padding = v; });

  // Text tab
  $('#textOn').addEventListener('change', (e) => change((p) => { p.text.on = e.target.checked; }));
  $('#titleIn').addEventListener('input', (e) => change((p) => { p.text.title = e.target.value; p.text.on = true; }, 'title'));
  $('#subIn').addEventListener('input', (e) => change((p) => { p.text.sub = e.target.value; p.text.on = true; }, 'sub'));
  wireSeg('#posSeg', (v) => change((p) => { p.text.pos = v; }));
  wireSeg('#alignSeg', (v) => change((p) => { p.text.align = v; }));
  wireRange('#textSize', 'tsize', (p, v) => { p.text.size = v; });
  $('#inkAuto').addEventListener('click', () => change((p) => { p.text.color = 'auto'; }));
  $('#inkColor').addEventListener('input', (e) => change((p) => { p.text.color = e.target.value; }, 'ink'));

  // Tabs
  $$('.tab').forEach((t) => t.addEventListener('click', () => {
    $$('.tab').forEach((x) => x.classList.toggle('on', x === t));
    $$('.tab-body').forEach((b) => { b.hidden = b.dataset.body !== t.dataset.tab; });
    document.querySelector('.panel.left').scrollTop = 0;
  }));

  // Right panel
  wireSeg('#countSeg', (v) => setCount(Number(v)));
  wireCamPad();
  wireRange('#xs', 'xs', (p, v) => { p.items[sel].s = v / 100; });
  wireRange('#xrot', 'xrot', (p, v) => { p.items[sel].rot = v; });
  wireRange('#xrx', 'xrx', (p, v) => { p.items[sel].rx = v; });
  wireRange('#xry', 'xry', (p, v) => { p.items[sel].ry = v; });
  wireRange('#xrz', 'xrz', (p, v) => { p.items[sel].rz = v; });
  wireRange('#xblur', 'xblur', (p, v) => { p.items[sel].blur = v; });
  $('#flatBtn').addEventListener('click', () => change((p) => { Object.assign(p.items[sel], { rot: 0, rx: 0, ry: 0, rz: 0 }); }));
  $('#frontBtn').addEventListener('click', () => change((p) => { p.items[sel].z = Math.max(...p.items.map((i) => i.z || 0)) + 1; }));

  // Top bar
  $('#undoBtn').addEventListener('click', undo);
  $('#redoBtn').addEventListener('click', redo);
  $('#newBtn').addEventListener('click', () => {
    change((p) => { Object.assign(p, newProject()); });
    sel = 0;
    toast('Started a new mockup. Undo brings the old one back.');
  });
  $('#shuffleBtn').addEventListener('click', shuffle);
  $('#exportBtn').addEventListener('click', (e) => { e.stopPropagation(); $('#exportPop').hidden = !$('#exportPop').hidden; });
  $('#exportPop').addEventListener('click', (e) => e.stopPropagation());
  document.addEventListener('click', () => { $('#exportPop').hidden = true; });
  wireSeg('#fmtSeg', (v) => { exportFmt = v; setSeg('#fmtSeg', v); syncUI(); });
  wireSeg('#scaleSeg', (v) => {
    if (!PRO && Number(v) > 1) { openAccount({ reason: `Export at ${v}x without the PocketView badge with Pro.` }); return; }
    exportScale = Number(v); setSeg('#scaleSeg', v); syncUI();
  });
  setSeg('#scaleSeg', String(exportScale));
  wirePlanButton($('#proBtn'), (rec) => {
    PRO = isPro(rec);
    document.body.classList.toggle('is-pro', PRO);
    if (!PRO && exportScale > 1) { exportScale = 1; setSeg('#scaleSeg', '1'); }
    syncUI();
    requestRender();
  });
  $('#downloadBtn').addEventListener('click', download);
  $('#copyBtn').addEventListener('click', copyImage);
}

function setCount(n) {
  if (n === P.items.length) return;
  change((p) => {
    const defaults = ['iphone-17-pro', 'galaxy-s25-ultra', 'pixel-10'];
    while (p.items.length < n) {
      const first = p.items[0];
      // New slots reuse the first device and screenshot so the layout looks right at once.
      p.items.push(newItem(defaults[p.items.length] || first.device, { image: first.image, iw: first.iw, ih: first.ih, clean: first.clean, cw: first.cw, ch: first.ch, host: first.host, captured: !!first.captured }));
    }
    p.items.length = n;
    applyLayout(p, LAYOUTS[n][0]);
  });
  sel = clamp(sel, 0, n - 1);
  syncUI();
}

// One click to try a different look: background, layout, shadow and style together.
function shuffle() {
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  const bgs = BACKGROUNDS.filter((b) => b.cat !== 'solid' && b.cat !== 'texture');
  change((p) => {
    if (Math.random() < 0.25 && firstImage()) { p.bg.kind = 'magic'; p.bg.magic = pick(MAGIC_STYLES).id; }
    else { p.bg.kind = 'preset'; p.bg.id = pick(bgs).id; }
    applyLayout(p, pick(LAYOUTS[p.items.length]));
    LK(p).shadow = pick(['soft', 'float', 'deep', 'spread', 'adaptive']);
    if (p.style.frame === 'screen') LK(p).screenStyle = pick(SCREEN_STYLES).id;
  });
}

// ---------- canvas interaction ----------
let dragging = null;
function toProject(e) {
  const r = view.getBoundingClientRect();
  return [(e.clientX - r.left) / previewScale, (e.clientY - r.top) / previewScale];
}
function inside(quad, [x, y]) {
  let c = false;
  for (let i = 0, j = quad.length - 1; i < quad.length; j = i++) {
    const [xi, yi] = quad[i], [xj, yj] = quad[j];
    if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c;
  }
  return c;
}
function hitTest(pt) {
  const order = P.items.map((it, i) => ({ i, z: it.z || 0 })).sort((a, b) => b.z - a.z || b.i - a.i);
  for (const { i } of order) if (hits[i] && inside(hits[i].quad, pt)) return i;
  return -1;
}
view.addEventListener('pointerdown', (e) => {
  const pt = toProject(e);
  const i = hitTest(pt);
  if (i < 0) return;
  if (sel !== i) { sel = i; syncUI(); scheduleThumbs(); drawOverlay(); }
  const it = P.items[i];
  dragging = { i, start: pt, cx: it.cx, cy: it.cy, box: hits[i].box, z: hits[i].z || 1, moved: false };
  view.setPointerCapture(e.pointerId);
  view.classList.add('dragging');
});
view.addEventListener('pointermove', (e) => {
  const pt = toProject(e);
  if (!dragging) { view.classList.toggle('can-drag', hitTest(pt) >= 0); return; }
  const dx = (pt[0] - dragging.start[0]) / dragging.box.w / dragging.z;
  const dy = (pt[1] - dragging.start[1]) / dragging.box.h / dragging.z;
  if (!dragging.moved && Math.hypot(dx, dy) < 0.004) return;
  dragging.moved = true;
  change((p) => {
    p.items[dragging.i].cx = dragging.cx + dx;
    p.items[dragging.i].cy = dragging.cy + dy;
    p.layout = 'custom';
  }, 'drag');
});
const endDrag = () => { dragging = null; view.classList.remove('dragging'); drawOverlay(); };
view.addEventListener('pointerup', endDrag);
view.addEventListener('pointercancel', endDrag);
view.addEventListener('dblclick', (e) => {
  const i = hitTest(toProject(e));
  if (i >= 0) { sel = i; syncUI(); $('#fileIn').click(); }
});

let dragDepth = 0;
window.addEventListener('dragenter', (e) => { if ([...e.dataTransfer.types].includes('Files')) { dragDepth++; $('#dropHint').hidden = false; } });
window.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $('#dropHint').hidden = true; });
window.addEventListener('dragover', (e) => e.preventDefault());
window.addEventListener('drop', async (e) => {
  e.preventDefault();
  dragDepth = 0; $('#dropHint').hidden = true;
  const files = [...e.dataTransfer.files].filter((f) => f.type.startsWith('image/'));
  if (!files.length) return;
  const over = e.target === view ? hitTest(toProject(e)) : -1;
  if (over >= 0) sel = over;
  for (let k = 0; k < files.length && k < P.items.length; k++) {
    const idx = files.length > 1 ? (sel + k) % P.items.length : sel;
    await placeImage(files[k], idx);
  }
});
window.addEventListener('paste', async (e) => {
  if (e.target.closest && e.target.closest('input, textarea')) return;
  const item = [...(e.clipboardData?.items || [])].find((i) => i.type.startsWith('image/'));
  if (!item) return;
  e.preventDefault();
  await placeImage(item.getAsFile());
});
window.addEventListener('keydown', (e) => {
  const typing = e.target.closest && e.target.closest('input, textarea, select');
  const mod = e.metaKey || e.ctrlKey;
  if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
  if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); return; }
  if (typing) return;
  if (e.key === 'Escape') { $('#exportPop').hidden = true; $('#devList').hidden = true; $('#sizePop').hidden = true; return; }
  if (e.key.toLowerCase() === 's' && !mod) { shuffle(); return; }
  const step = e.shiftKey ? 0.02 : 0.005;
  const mv = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[e.key];
  if (mv) {
    e.preventDefault();
    change((p) => { p.items[sel].cx += mv[0]; p.items[sel].cy += mv[1]; p.layout = 'custom'; }, 'nudge');
    return;
  }
  if (e.key === 'Tab' && P.items.length > 1) { e.preventDefault(); sel = (sel + (e.shiftKey ? P.items.length - 1 : 1)) % P.items.length; syncUI(); scheduleThumbs(); drawOverlay(); }
});
window.addEventListener('resize', requestRender);

// ---------- export ----------
async function renderExport() {
  const s = exportScale;
  // Make sure the full-size wallpaper is in before drawing the export.
  if (P.bg.kind === 'preset') { const b = bgById(P.bg.id); if (b?.kind === 'wallpaper') await loadUrl(`wp:${b.file}`, wallpaperUrl(b.file, false)); }
  const c = document.createElement('canvas');
  c.width = P.size.w * s; c.height = P.size.h * s;
  const ctx = c.getContext('2d');
  if (exportFmt === 'jpeg' && P.bg.kind === 'transparent') { ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, c.width, c.height); }
  renderScene(ctx, P, images, { scale: s, watermark: !PRO });
  return new Promise((res) => c.toBlob(res, `image/${exportFmt}`, exportFmt === 'png' ? undefined : 0.92));
}
function fileName() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `pocketview-studio-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}.${exportFmt === 'jpeg' ? 'jpg' : exportFmt}`;
}
async function download() {
  $('#downloadBtn').disabled = true;
  try {
    const blob = await renderExport();
    if (!blob) throw new Error('empty');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = fileName();
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    $('#exportPop').hidden = true;
    toast('Saved to your Downloads.');
  } catch { toast('Export failed. Try a smaller scale.'); }
  $('#downloadBtn').disabled = false;
}
async function copyImage() {
  try {
    const prev = exportFmt;
    exportFmt = 'png';
    const blob = await renderExport();
    exportFmt = prev;
    await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
    $('#exportPop').hidden = true;
    toast('Copied. Paste it anywhere.');
  } catch { toast('Copy failed. Use Download instead.'); }
}

let toastTimer = 0;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 2600);
}

// ---------- start ----------
async function importFromSimulator() {
  const data = await getKV('import').catch(() => null);
  if (!data || !data.items?.length) return false;
  await delKV('import').catch(() => {});
  const n = Math.min(3, data.items.length);
  const q = newProject();
  q.items = data.items.slice(0, n).map((d) => {
    const it = newItem(d.device, { image: d.image || null, landscape: !!d.landscape, open: !!d.open, host: d.host || '', iw: d.iw || 0, ih: d.ih || 0, clean: d.clean || null, cw: d.cw || 0, ch: d.ch || 0, captured: !!d.image });
    if (d.finish) it.finish = d.finish;
    return it;
  });
  q.text.sub = data.host || q.text.sub;
  if (n > 1) q.size = { preset: 'r16-9', w: 1920, h: 1080 };
  applyLayout(q, LAYOUTS[n][0]);
  P = q;
  await ensureImages();
  const img = firstImage();
  if (img) { P.bg.kind = 'magic'; P.bg.magic = 'mesh'; P.bg.palette = paletteFrom(img); }
  return true;
}

async function start() {
  await Promise.all([
    document.fonts.load('800 40px "Hubot Sans"'),
    document.fonts.load('500 20px "Inter Tight"'),
    document.fonts.load('600 20px "Inter Tight"')
  ]).catch(() => {});
  buildStatic();
  loadUrl('__pvlogo', 'icons/icon128.png');
  const imported = await importFromSimulator();
  if (!imported) {
    const saved = await getKV('project').catch(() => null);
    if (saved && saved.items?.length) P = migrate(saved);
    await ensureImages();
  }
  sel = 0;
  const font = FONTS.find((x) => x.id === P.text?.font);
  if (font) await document.fonts.load(`700 40px ${font.family}`).catch(() => {});
  buildLayoutButtons();
  afterChange();
  if (imported) toast('Screens imported from the simulator.');
}
start();

// Exposed for automated checks.
window.__studio = { get P() { return P; }, set: (fn) => change(fn), setSel: (i) => { sel = i; syncUI(); scheduleThumbs(); requestRender(); } };
