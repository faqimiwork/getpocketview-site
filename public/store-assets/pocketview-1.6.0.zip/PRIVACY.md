# PocketView Privacy Policy

Last updated: 18 November 2026

PocketView ("the extension") is a browser extension for previewing websites in simulated device screens.

## Data we collect
The free extension collects nothing. It does not collect, store on any server, sell or share personal data, browsing history, website content or usage analytics.

## PocketView Pro
If you buy PocketView Pro or sign in to it:
- Your email address and plan (monthly or yearly, status, renewal date) are kept on getpocketview.com so Pro works on your computers.
- The extension stores a licence key on this computer and checks it against getpocketview.com about once a day. Only a hashed copy of the key is kept on the server.
- Payments are processed by Stripe; card details never reach us. Sign-in code emails are sent through Resend.
- We do not sell or share this data and do not use it for advertising. Full policy: https://getpocketview.com/privacy

## Data stored on your device
The extension saves your settings (selected devices, custom devices, orientation, zoom and view options), Studio projects and, for Pro, your licence key using Chrome's local extension storage and IndexedDB. This data stays in your browser and is removed when you uninstall the extension.

## Network and permissions
- Websites you open in the simulator are loaded directly from those websites by your browser, the same as visiting them normally.
- While a simulator tab is open, the extension changes request and response headers for frames inside that tab only (mobile User-Agent, frame headers). These rules are deleted when the simulator closes.
- Screenshots, recordings and Studio mockups are created locally and saved to your Downloads folder. They are never uploaded.
- Full-page screenshots, QR codes and form sync work inside your browser only. QR codes are generated in the extension, and form sync copies field values between the simulator's own device frames. Passwords are never copied, and nothing is sent anywhere.
- On getpocketview.com only, a small script lets the website pass your Pro licence to the extension after checkout or sign-in.

## Contact
For questions about this policy, email hello@getpocketview.com.
