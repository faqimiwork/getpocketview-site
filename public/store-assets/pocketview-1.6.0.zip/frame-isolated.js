// Runs in an isolated world, only inside PocketView device frames.
// Mobile look (hidden scrollbars, touch cursor), drag to scroll, color scheme emulation,
// URL reporting, sync scroll and touch reporting for recordings.
(() => {
  if (window === window.top) return;
  const anc = location.ancestorOrigins;
  const me = 'chrome-extension://' + chrome.runtime.id;
  if (!anc || !anc.length || anc[anc.length - 1] !== me) return;
  const raw = window.name || '';
  if (!raw.startsWith('__pv__:')) return;

  let cfg;
  try { cfg = JSON.parse(raw.slice(7)); } catch (e) { return; }
  const view = cfg.view;
  let dragOn = !!cfg.dragScroll;

  function send(msg) {
    try { chrome.runtime.sendMessage(Object.assign({ view }, msg)).catch(() => {}); } catch (e) { /* extension reloaded */ }
  }

  // ---------- mobile look ----------
  const TOUCH_CURSOR = 'url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2728%27 height=%2728%27%3E%3Ccircle cx=%2714%27 cy=%2714%27 r=%2711%27 fill=%27rgba(120,120,120,0.35)%27 stroke=%27rgba(255,255,255,0.9)%27 stroke-width=%272%27/%3E%3C/svg%3E") 14 14, pointer';
  const style = document.createElement('style');
  style.id = '__pocketview_style';

  function renderStyle(opts) {
    let css = '';
    if (opts.hideScrollbars) {
      css += 'html, body, * { scrollbar-width: none !important; }\n';
      css += '::-webkit-scrollbar { width: 0 !important; height: 0 !important; background: transparent !important; }\n';
    }
    if (opts.touchCursor) css += `html, html * { cursor: ${TOUCH_CURSOR} !important; }\n`;
    css += 'html.__pv_dragging, html.__pv_dragging * { user-select: none !important; -webkit-user-select: none !important; }\n';
    style.textContent = css;
  }
  renderStyle(cfg);

  function mountStyle() {
    const root = document.documentElement;
    if (root && !style.isConnected) root.appendChild(style);
  }
  mountStyle();
  document.addEventListener('DOMContentLoaded', mountStyle, { once: true });

  // ---------- color scheme + display-mode emulation (CSS side) ----------
  const scheme = cfg.scheme === 'dark' || cfg.scheme === 'light' ? cfg.scheme : null;
  const mode = cfg.displayMode && cfg.displayMode !== 'browser' ? cfg.displayMode : null;
  if (scheme || mode) {
    const TEST = /\(\s*(prefers-color-scheme|display-mode)\s*:/i;
    const YES = '(min-width: 0px)';
    const NO = '(max-width: 0.001px)';
    const rewrite = (t) => {
      if (scheme) t = t.replace(/\(\s*prefers-color-scheme\s*:\s*(dark|light)\s*\)/gi, (m, s) => (s.toLowerCase() === scheme ? YES : NO));
      if (mode) t = t.replace(/\(\s*display-mode\s*:\s*([a-z-]+)\s*\)/gi, (m, s) => (s.toLowerCase() === mode ? YES : NO));
      return t;
    };
    const done = new WeakSet();

    const walk = (rules) => {
      for (const r of rules) {
        try {
          if (r.media && r.media.mediaText && TEST.test(r.media.mediaText)) r.media.mediaText = rewrite(r.media.mediaText);
          if (r.cssRules) walk(r.cssRules);
          if (r.styleSheet) sheet(r.styleSheet);
        } catch (e) { /* ignore */ }
      }
    };
    const sheet = (s) => {
      if (!s || done.has(s)) return;
      let rules;
      try { rules = s.cssRules; } catch (e) { return; } // cross-origin sheet without CORS
      if (!rules) return;
      done.add(s);
      walk(rules);
    };
    const run = () => {
      document.querySelectorAll('link[media], style[media], source[media]').forEach((n) => {
        const m = n.getAttribute('media');
        if (m && TEST.test(m)) n.setAttribute('media', rewrite(m));
      });
      for (const s of document.styleSheets) sheet(s);
    };
    let t = 0;
    const soon = () => { clearTimeout(t); t = setTimeout(run, 30); };
    document.addEventListener('DOMContentLoaded', run);
    window.addEventListener('load', run);
    document.addEventListener('load', (e) => { if (e.target && /^(LINK|STYLE)$/.test(e.target.tagName)) soon(); }, true);
    new MutationObserver(soon).observe(document, { childList: true, subtree: true });
    if (scheme) {
      const root = () => { if (document.documentElement) document.documentElement.style.colorScheme = scheme; };
      root();
      document.addEventListener('DOMContentLoaded', root, { once: true });
    }
  }

  // ---------- web app info (manifest, theme color, icon) for App mode ----------
  async function reportApp() {
    try {
      const meta = (sel) => { const n = document.querySelector(sel); return n ? n.getAttribute('content') : null; };
      let themeColor = null;
      for (const m of document.querySelectorAll('meta[name="theme-color"]')) {
        const media = m.getAttribute('media');
        if (!media || window.matchMedia(media).matches) { themeColor = m.getAttribute('content'); break; }
      }
      const info = {
        name: meta('meta[name="apple-mobile-web-app-title"]') || meta('meta[name="application-name"]') || null,
        themeColor,
        bgColor: null,
        icon: null,
        statusStyle: meta('meta[name="apple-mobile-web-app-status-bar-style"]')
      };
      const touch = document.querySelector('link[rel="apple-touch-icon"], link[rel="apple-touch-icon-precomposed"]');
      if (touch) info.icon = new URL(touch.getAttribute('href'), location.href).href;
      const link = document.querySelector('link[rel="manifest"]');
      if (link) {
        try {
          const url = new URL(link.getAttribute('href'), location.href);
          const res = await fetch(url, { credentials: link.crossOrigin === 'use-credentials' ? 'include' : 'same-origin' });
          if (res.ok) {
            const m = await res.json();
            info.name = info.name || m.short_name || m.name || null;
            info.themeColor = info.themeColor || m.theme_color || null;
            info.bgColor = m.background_color || null;
            const icons = (m.icons || []).filter((i) => i && i.src && !/monochrome/.test(i.purpose || ''));
            const size = (i) => Math.max(...String(i.sizes || '0x0').split(/\s+/).map((s) => parseInt(s, 10) || 0));
            icons.sort((a, b) => size(b) - size(a));
            const best = icons.find((i) => size(i) <= 512) || icons[0];
            if (best) info.icon = new URL(best.src, url).href;
          }
        } catch (e) { /* manifest blocked or invalid */ }
      }
      if (!info.icon) {
        const fav = document.querySelector('link[rel~="icon"]');
        if (fav) info.icon = new URL(fav.getAttribute('href'), location.href).href;
      }
      info.name = info.name || document.title || location.hostname;
      send(Object.assign({ type: 'pv:frame:app' }, info));
    } catch (e) { /* ignore */ }
  }
  document.addEventListener('DOMContentLoaded', reportApp, { once: true });

  // ---------- URL / title reporting ----------
  let lastUrl = '';
  let lastTitle = '';
  function reportNav() {
    if (location.href === lastUrl && document.title === lastTitle) return;
    lastUrl = location.href;
    lastTitle = document.title;
    send({ type: 'pv:frame:nav', url: location.href, title: document.title });
  }
  window.addEventListener('load', () => { reportNav(); send({ type: 'pv:frame:loaded' }); });
  window.addEventListener('popstate', reportNav);
  window.addEventListener('hashchange', reportNav);
  document.addEventListener('DOMContentLoaded', reportNav, { once: true });
  setInterval(reportNav, 1000); // catches pushState navigations in SPAs

  // ---------- sync scroll ----------
  let ignoreUntil = 0;
  let pending = false;
  function scroller() { return document.scrollingElement || document.documentElement; }

  window.addEventListener('scroll', () => {
    if (pending) return;
    pending = true;
    requestAnimationFrame(() => {
      pending = false;
      const s = scroller();
      const maxY = Math.max(1, s.scrollHeight - window.innerHeight);
      const maxX = Math.max(1, s.scrollWidth - window.innerWidth);
      send({ type: 'pv:frame:scroll', y: s.scrollTop / maxY, x: s.scrollLeft / maxX, echo: Date.now() < ignoreUntil });
    });
  }, { passive: true });

  // ---------- drag to scroll (mouse acts like a finger) ----------
  const SKIP = 'input, textarea, select, option, button[draggable="true"], [contenteditable=""], [contenteditable="true"], [draggable="true"], video, audio, iframe, embed, object';
  let drag = null;
  let suppressClick = false;
  let momentum = 0;

  function scrollableParent(el) {
    for (let n = el; n && n.nodeType === 1 && n !== document.body && n !== document.documentElement; n = n.parentElement) {
      const cs = getComputedStyle(n);
      const oy = /(auto|scroll|overlay)/.test(cs.overflowY) && n.scrollHeight > n.clientHeight + 1;
      const ox = /(auto|scroll|overlay)/.test(cs.overflowX) && n.scrollWidth > n.clientWidth + 1;
      if (oy || ox) return n;
    }
    return scroller();
  }
  function stopMomentum() { if (momentum) cancelAnimationFrame(momentum); momentum = 0; }
  function glide(el, vx, vy) {
    let last = performance.now();
    const step = (now) => {
      const dt = Math.min(32, now - last);
      last = now;
      vx *= Math.pow(0.95, dt / 16);
      vy *= Math.pow(0.95, dt / 16);
      if (Math.abs(vx) < 0.02 && Math.abs(vy) < 0.02) { momentum = 0; return; }
      el.scrollBy(vx * dt, vy * dt);
      momentum = requestAnimationFrame(step);
    };
    momentum = requestAnimationFrame(step);
  }

  window.addEventListener('mousedown', (e) => {
    stopMomentum();
    if (!dragOn || e.button !== 0 || e.defaultPrevented) return;
    if (e.target && e.target.closest && e.target.closest(SKIP)) return;
    drag = { x: e.clientX, y: e.clientY, lx: e.clientX, ly: e.clientY, t: performance.now(), el: scrollableParent(e.target), moved: false, vx: 0, vy: 0 };
  }, true);

  window.addEventListener('mousemove', (e) => {
    if (!drag) return;
    if (!(e.buttons & 1)) { drag = null; document.documentElement.classList.remove('__pv_dragging'); return; }
    if (!drag.moved && Math.hypot(e.clientX - drag.x, e.clientY - drag.y) < 6) return;
    if (!drag.moved) {
      drag.moved = true;
      document.documentElement.classList.add('__pv_dragging');
      const sel = window.getSelection && window.getSelection();
      if (sel) sel.removeAllRanges();
    }
    e.preventDefault();
    const dx = e.clientX - drag.lx;
    const dy = e.clientY - drag.ly;
    const now = performance.now();
    const dt = Math.max(1, now - drag.t);
    drag.el.scrollBy(-dx, -dy);
    drag.vx = 0.7 * (-dx / dt) + 0.3 * drag.vx;
    drag.vy = 0.7 * (-dy / dt) + 0.3 * drag.vy;
    drag.lx = e.clientX; drag.ly = e.clientY; drag.t = now;
  }, true);

  window.addEventListener('mouseup', () => {
    if (!drag) return;
    const d = drag;
    drag = null;
    document.documentElement.classList.remove('__pv_dragging');
    if (d.moved) {
      suppressClick = true;
      setTimeout(() => { suppressClick = false; }, 60);
      if (performance.now() - d.t < 80) glide(d.el, d.vx, d.vy);
    }
  }, true);

  window.addEventListener('click', (e) => {
    if (suppressClick) { e.preventDefault(); e.stopPropagation(); suppressClick = false; }
  }, true);
  window.addEventListener('dragstart', (e) => {
    if (dragOn && drag && !(e.target.closest && e.target.closest('[draggable="true"]'))) e.preventDefault();
  }, true);
  window.addEventListener('wheel', stopMomentum, { passive: true, capture: true });

  // ---------- touch reporting while recording ----------
  let rec = false;
  let ptrPending = null;
  let ptrRaf = 0;
  function sendPtr(e, kind) {
    send({ type: 'pv:frame:pointer', x: e.clientX, y: e.clientY, down: (e.buttons & 1) === 1 || kind === 'down', kind });
  }
  window.addEventListener('pointermove', (e) => {
    if (!rec) return;
    ptrPending = e;
    if (!ptrRaf) ptrRaf = requestAnimationFrame(() => { ptrRaf = 0; sendPtr(ptrPending, 'move'); });
  }, { capture: true, passive: true });
  window.addEventListener('pointerdown', (e) => { if (rec) sendPtr(e, 'down'); }, { capture: true, passive: true });
  window.addEventListener('pointerup', (e) => { if (rec) sendPtr(e, 'up'); }, { capture: true, passive: true });

  // ---------- sync form typing (Pro) ----------
  // Text, choices and ticks typed in one device are copied to the same field in the others.
  // Passwords and file pickers are never copied.
  let formSync = !!cfg.formSync;
  const FIELD = 'input, textarea, select';
  const SKIP_TYPES = /^(password|file|hidden|submit|button|reset|image)$/i;
  const esc = (s) => (window.CSS && CSS.escape ? CSS.escape(s) : s.replace(/[^\w-]/g, '\\$&'));
  function uniqueId(n) {
    return n.id && document.querySelectorAll('#' + esc(n.id)).length === 1;
  }
  function pathOf(el) {
    if (uniqueId(el)) return '#' + esc(el.id);
    const parts = [];
    for (let n = el; n && n.nodeType === 1 && n !== document.documentElement; n = n.parentElement) {
      if (n !== el && uniqueId(n)) { parts.unshift('#' + esc(n.id)); break; }
      let i = 1;
      for (let s = n.previousElementSibling; s; s = s.previousElementSibling) if (s.tagName === n.tagName) i++;
      parts.unshift(`${n.tagName.toLowerCase()}:nth-of-type(${i})`);
    }
    return parts.join(' > ');
  }
  function describe(el) {
    const name = el.getAttribute('name') || '';
    const same = name ? [...document.querySelectorAll(`${el.tagName.toLowerCase()}[name="${esc(name)}"]`)] : [];
    return { path: pathOf(el), tag: el.tagName, kind: (el.type || '').toLowerCase(), name, nth: Math.max(0, same.indexOf(el)) };
  }
  function findField(d) {
    let el = null;
    try { el = document.querySelector(d.path); } catch (e) { /* invalid selector */ }
    const fits = (n) => n && n.tagName === d.tag && (n.type || '').toLowerCase() === d.kind && (n.getAttribute('name') || '') === d.name;
    if (fits(el)) return el;
    if (d.name) {
      const list = document.querySelectorAll(`${d.tag.toLowerCase()}[name="${esc(d.name)}"]`);
      if (fits(list[d.nth])) return list[d.nth];
    }
    return null;
  }
  function onField(e) {
    if (!formSync || !e.isTrusted) return;
    const el = e.target;
    if (!el || !el.matches || !el.matches(FIELD) || SKIP_TYPES.test(el.type || '')) return;
    const choice = /^(checkbox|radio)$/i.test(el.type || '');
    if (choice && e.type !== 'change') return;
    const d = describe(el);
    if (choice) d.checked = !!el.checked;
    else d.value = String(el.value).slice(0, 5000);
    send(Object.assign({ type: 'pv:frame:input' }, d));
  }
  document.addEventListener('input', onField, true);
  document.addEventListener('change', onField, true);
  function applyField(d) {
    const el = findField(d);
    if (!el || SKIP_TYPES.test(el.type || '')) return;
    if ('checked' in d && /^(checkbox|radio)$/i.test(el.type || '')) {
      if (el.checked !== d.checked) el.click();
      return;
    }
    if (el.value === d.value) return;
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype
      : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, d.value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // ---------- full-page capture ----------
  // The simulator scrolls the page one screen at a time and stitches the shots together.
  // Fixed and sticky bars are hidden after the first screen so they show only once.
  let hidden = null;
  function hideFixed() {
    if (hidden) return;
    hidden = [];
    for (const n of document.body ? document.body.querySelectorAll('*') : []) {
      const p = getComputedStyle(n).position;
      if (p === 'fixed' || p === 'sticky') {
        hidden.push([n, n.style.getPropertyValue('visibility'), n.style.getPropertyPriority('visibility')]);
        n.style.setProperty('visibility', 'hidden', 'important');
      }
    }
  }
  function showFixed() {
    if (!hidden) return;
    for (const [n, v, p] of hidden) {
      if (v) n.style.setProperty('visibility', v, p); else n.style.removeProperty('visibility');
    }
    hidden = null;
  }
  const settle = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(r, 60))));
  function metrics() {
    const s = scroller();
    return { h: s.scrollHeight, vh: window.innerHeight, w: window.innerWidth, y: s.scrollTop };
  }

  // ---------- commands from the simulator ----------
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (!msg || typeof msg.type !== 'string') return;
    if (msg.type.startsWith('pv:sim:page:')) {
      if (msg.view !== view) return;
      ignoreUntil = Date.now() + 1500;
      if (msg.type === 'pv:sim:page:metrics') { reply(metrics()); return; }
      if (msg.type === 'pv:sim:page:scrollTo') {
        stopMomentum();
        if (msg.hideFixed) hideFixed();
        scroller().scrollTo({ top: msg.y, left: 0, behavior: 'instant' });
        settle().then(() => reply(metrics()));
        return true;
      }
      if (msg.type === 'pv:sim:page:restore') {
        showFixed();
        scroller().scrollTo({ top: msg.y || 0, left: 0, behavior: 'instant' });
        settle().then(() => reply(metrics()));
        return true;
      }
      return;
    }
    if (msg.type === 'pv:sim:input') {
      if (msg.from !== view) applyField(msg);
      return;
    }
    if (msg.type === 'pv:sim:scroll' && msg.from !== view) {
      const s = scroller();
      ignoreUntil = Date.now() + 250;
      s.scrollTo({
        top: msg.y * Math.max(0, s.scrollHeight - window.innerHeight),
        left: msg.x * Math.max(0, s.scrollWidth - window.innerWidth),
        behavior: 'instant'
      });
    } else if (msg.type === 'pv:sim:style') {
      if (msg.views && !msg.views.includes(view)) return;
      renderStyle(msg);
      mountStyle();
      if ('dragScroll' in msg) dragOn = !!msg.dragScroll;
      if ('formSync' in msg) formSync = !!msg.formSync;
    } else if (msg.type === 'pv:sim:rec') {
      rec = !!msg.on;
    }
  });
})();
