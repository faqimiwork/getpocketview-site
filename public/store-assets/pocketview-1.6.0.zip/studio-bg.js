// PocketView Studio background library and painters.
// Solid, Gradient, Mesh and Wallpaper presets partly come from Shotcandy (MIT); the
// Cosmic, Mystic, Abstract, Radiant and Texture sets are drawn procedurally here.

import { SC_BACKGROUNDS } from './studio-sc-presets.js';

export const BG_CATEGORIES = [
  { id: 'solid', name: 'Solid' },
  { id: 'gradient', name: 'Gradient' },
  { id: 'mesh', name: 'Mesh' },
  { id: 'wallpaper', name: 'Wallpaper' },
  { id: 'cosmic', name: 'Cosmic' },
  { id: 'mystic', name: 'Mystic' },
  { id: 'abstract', name: 'Abstract' },
  { id: 'radiant', name: 'Radiant' },
  { id: 'texture', name: 'Texture' }
];

const OWN = [
  // PocketView brand first
  { id: 'pv-pocket', cat: 'gradient', name: 'PocketView', kind: 'radial', at: [0.72, 0.28], radius: 1, stops: [[0, '#3f5410'], [0.38, '#161d0c'], [0.72, '#0d1016']] },
  { id: 'pv-lime', cat: 'gradient', name: 'Lime', kind: 'linear', angle: 160, stops: [[0, '#d8ff5c'], [1, '#a6e01f']] },
  { id: 'pv-aurora', cat: 'gradient', name: 'Aurora', kind: 'linear', angle: 135, stops: [[0, '#1e3c72'], [0.55, '#7c5cff'], [1, '#ff6ec4']] },
  { id: 'pv-blaze', cat: 'gradient', name: 'Blaze', kind: 'linear', angle: 120, stops: [[0, '#f97316'], [0.5, '#ec4899'], [1, '#7c3aed']] },
  { id: 'pv-ocean', cat: 'gradient', name: 'Ocean', kind: 'linear', angle: 135, stops: [[0, '#00c6ff'], [1, '#0072ff']] },
  { id: 'pv-forest', cat: 'gradient', name: 'Forest', kind: 'linear', angle: 135, stops: [[0, '#134e5e'], [1, '#71b280']] },
  { id: 'pv-midnight', cat: 'gradient', name: 'Midnight', kind: 'radial', at: [0.3, 0.2], radius: 1, stops: [[0, '#2b3245'], [0.7, '#0b0d12']] },
  { id: 'pv-steel', cat: 'gradient', name: 'Steel', kind: 'linear', angle: 160, stops: [[0, '#e6e9f0'], [1, '#c3cad6']] },
  { id: 'pv-ink', cat: 'solid', name: 'Ink', kind: 'solid', color: '#0d1016' },
  { id: 'pv-limesolid', cat: 'solid', name: 'Lime', kind: 'solid', color: '#c6f432' },
  { id: 'pv-white', cat: 'solid', name: 'White', kind: 'solid', color: '#ffffff' },

  // Cosmic: dark space with coloured glows and a sprinkle of stars
  { id: 'co-nebula', cat: 'cosmic', name: 'Nebula', kind: 'cosmic', base: '#07060f', glows: [[0.2, 0.85, 0.75, '#7b2cff', 0.9], [0.85, 0.2, 0.6, '#ff3d8b', 0.7], [0.6, 0.65, 0.45, '#2b6bff', 0.5]], stars: 1 },
  { id: 'co-dawn', cat: 'cosmic', name: 'Dawn', kind: 'cosmic', base: '#0a0812', glows: [[0.5, 1.1, 0.9, '#ff8a3d', 0.9], [0.5, 1.15, 0.55, '#ffd36b', 0.8], [0.15, 0.2, 0.5, '#5a2cff', 0.45]], stars: 1 },
  { id: 'co-violet', cat: 'cosmic', name: 'Violet', kind: 'cosmic', base: '#0b0716', glows: [[0.8, 0.9, 0.8, '#b06bff', 0.85], [0.1, 0.1, 0.55, '#4b2cff', 0.6]], stars: 1 },
  { id: 'co-lime', cat: 'cosmic', name: 'Lime glow', kind: 'cosmic', base: '#080a06', glows: [[0.75, 0.25, 0.7, '#9fdc1f', 0.6], [0.2, 0.9, 0.5, '#2b5d10', 0.7]], stars: 1 },
  { id: 'co-ice', cat: 'cosmic', name: 'Ice', kind: 'cosmic', base: '#050a12', glows: [[0.5, 0.0, 0.85, '#36c5ff', 0.7], [0.9, 0.8, 0.5, '#7c5cff', 0.5]], stars: 1 },
  { id: 'co-ember', cat: 'cosmic', name: 'Ember', kind: 'cosmic', base: '#0d0605', glows: [[0.0, 1.0, 0.85, '#ff4d2d', 0.8], [1.0, 0.0, 0.6, '#ff9a3c', 0.55]], stars: 0 },

  // Mystic: glowing arcs over a horizon
  { id: 'my-halo', cat: 'mystic', name: 'Halo', kind: 'arc', base: ['#eceef6', '#ffffff'], arcs: ['#4b5bff', '#8f9bff'], y: 1.05 },
  { id: 'my-blush', cat: 'mystic', name: 'Blush', kind: 'arc', base: ['#f6eef4', '#ffffff'], arcs: ['#a64bff', '#ff7fd1'], y: 1.05 },
  { id: 'my-deep', cat: 'mystic', name: 'Deep', kind: 'arc', base: ['#0b0b1a', '#141230'], arcs: ['#6d5cff', '#c08bff'], y: 1.08 },
  { id: 'my-sun', cat: 'mystic', name: 'Sun', kind: 'arc', base: ['#1a0c08', '#2a1208'], arcs: ['#ff6a2d', '#ffc36b'], y: 1.1 },
  { id: 'my-lime', cat: 'mystic', name: 'Signal', kind: 'arc', base: ['#0d1016', '#141a12'], arcs: ['#7fb317', '#c6f432'], y: 1.08 },
  { id: 'my-sea', cat: 'mystic', name: 'Sea', kind: 'arc', base: ['#eef7f6', '#ffffff'], arcs: ['#0fb5a6', '#6be3d3'], y: 1.05 },

  // Abstract: layered paper waves
  { id: 'ab-dusk', cat: 'abstract', name: 'Dusk waves', kind: 'waves', base: '#2a1b5c', colors: ['#4b2ca0', '#7a3fd1', '#c45cd6', '#ff8fb1'], seed: 3 },
  { id: 'ab-sunset', cat: 'abstract', name: 'Sunset waves', kind: 'waves', base: '#ffb36b', colors: ['#ff8a5c', '#ff5f6d', '#d63a6a', '#7a1f4f'], seed: 7 },
  { id: 'ab-ocean', cat: 'abstract', name: 'Ocean waves', kind: 'waves', base: '#bfe8ff', colors: ['#7cc8f2', '#3a95d6', '#1f5fa8', '#0d2f66'], seed: 11 },
  { id: 'ab-lime', cat: 'abstract', name: 'Lime waves', kind: 'waves', base: '#0d1016', colors: ['#1d2a10', '#3f5410', '#7fb317', '#c6f432'], seed: 5 },
  { id: 'ab-sand', cat: 'abstract', name: 'Dunes', kind: 'waves', base: '#f6e3c8', colors: ['#efcf9f', '#e2b07a', '#cf8f5c', '#a86a43'], seed: 9 },
  { id: 'ab-mint', cat: 'abstract', name: 'Mint waves', kind: 'waves', base: '#e8fbf3', colors: ['#bdf2dc', '#7fe0bd', '#3cc49a', '#14866a'], seed: 2 },

  // Radiant: big soft light blooms
  { id: 'ra-pearl', cat: 'radiant', name: 'Pearl', kind: 'mesh', base: '#f1eef8', points: [[0.5, 0.5, '#ffffff', 0.55], [0.1, 0.1, '#d9d0ff', 0.6], [0.9, 0.9, '#ffd6e8', 0.6]] },
  { id: 'ra-rose', cat: 'radiant', name: 'Rose', kind: 'mesh', base: '#ffdfe6', points: [[0.5, 0.45, '#ffffff', 0.5], [0.05, 0.95, '#ff7a9c', 0.65], [0.95, 0.1, '#ffb38a', 0.55]] },
  { id: 'ra-azure', cat: 'radiant', name: 'Azure', kind: 'mesh', base: '#dfe9ff', points: [[0.5, 0.5, '#ffffff', 0.5], [0.0, 0.0, '#6c8dff', 0.6], [1, 1, '#9be7ff', 0.6]] },
  { id: 'ra-flame', cat: 'radiant', name: 'Flame', kind: 'mesh', base: '#2a0f0a', points: [[0.5, 0.55, '#ff7a2d', 0.5], [0.5, 0.6, '#ffd36b', 0.25], [0.1, 0.1, '#5a1a2a', 0.6]] },
  { id: 'ra-orchid', cat: 'radiant', name: 'Orchid', kind: 'mesh', base: '#1a0f2a', points: [[0.5, 0.5, '#c86bff', 0.5], [0.5, 0.5, '#ffd0ff', 0.2], [0.95, 0.95, '#3d2cff', 0.6]] },
  { id: 'ra-lime', cat: 'radiant', name: 'Glow', kind: 'mesh', base: '#0d1016', points: [[0.5, 0.5, '#c6f432', 0.45], [0.5, 0.5, '#f4ffd0', 0.18], [0.0, 1.0, '#1d2a10', 0.6]] },

  // Texture: quiet patterns
  { id: 'tx-dots', cat: 'texture', name: 'Dots', kind: 'pattern', type: 'dots', base: '#f4f1ea', ink: '#1b1b1b' },
  { id: 'tx-grid', cat: 'texture', name: 'Grid', kind: 'pattern', type: 'grid', base: '#f7f8fb', ink: '#1d2333' },
  { id: 'tx-dark-dots', cat: 'texture', name: 'Night dots', kind: 'pattern', type: 'dots', base: '#0d1016', ink: '#ffffff' },
  { id: 'tx-blueprint', cat: 'texture', name: 'Blueprint', kind: 'pattern', type: 'grid', base: '#123a7a', ink: '#ffffff' },
  { id: 'tx-lines', cat: 'texture', name: 'Lines', kind: 'pattern', type: 'lines', base: '#efe9ff', ink: '#3b2a8a' },
  { id: 'tx-grain', cat: 'texture', name: 'Grain', kind: 'pattern', type: 'grain', base: '#d9c7b0', ink: '#000000' }
];

export const BACKGROUNDS = [...OWN.filter((b) => b.cat === 'gradient' || b.cat === 'solid'), ...SC_BACKGROUNDS, ...OWN.filter((b) => b.cat !== 'gradient' && b.cat !== 'solid')];
const BYID = new Map(BACKGROUNDS.map((b) => [b.id, b]));
export const bgById = (id) => BYID.get(id) || null;
export const wallpaperUrl = (file, thumb) => `backgrounds/${thumb ? 'thumbs/' : ''}${file}.webp`;

// ---------- helpers ----------
function rgb(hex) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h.slice(0, 6), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
const rgba = (hex, a) => { const [r, g, b] = rgb(hex); return `rgba(${r},${g},${b},${a})`; };
function rand(seed) {
  let t = seed >>> 0;
  return () => { t += 0x6d2b79f5; let r = Math.imul(t ^ (t >>> 15), 1 | t); r ^= r + Math.imul(r ^ (r >>> 7), 61 | r); return ((r ^ (r >>> 14)) >>> 0) / 4294967296; };
}
function offscreen(w, h) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); return c; }

// ---------- painters (all paint the full W x H area of ctx's current space) ----------
function linear(ctx, b, W, H) {
  const a = b.angle * Math.PI / 180;
  const dx = Math.sin(a), dy = -Math.cos(a);
  const len = Math.abs(W * dx) + Math.abs(H * dy);
  const g = ctx.createLinearGradient(W / 2 - dx * len / 2, H / 2 - dy * len / 2, W / 2 + dx * len / 2, H / 2 + dy * len / 2);
  b.stops.forEach(([o, c]) => g.addColorStop(o, c));
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
}
function radial(ctx, b, W, H) {
  const [ax, ay] = b.at;
  const r = Math.hypot(Math.max(ax, 1 - ax) * W, Math.max(ay, 1 - ay) * H) * (b.radius || 1);
  const g = ctx.createRadialGradient(ax * W, ay * H, 0, ax * W, ay * H, r);
  b.stops.forEach(([o, c]) => g.addColorStop(o, c));
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
}
function conic(ctx, b, W, H) {
  const g = ctx.createConicGradient((b.angle - 90) * Math.PI / 180, b.at[0] * W, b.at[1] * H);
  b.stops.forEach(([o, c]) => g.addColorStop(o, c));
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
}
// Soft blobs painted small, then scaled up: smooth and fast at any size.
function mesh(ctx, b, W, H) {
  const sw = 96, sh = Math.max(8, Math.round(96 * H / W));
  const c = offscreen(sw, sh), x = c.getContext('2d');
  x.fillStyle = b.base; x.fillRect(0, 0, sw, sh);
  const R = Math.max(sw, sh);
  for (const [px, py, col, rad] of b.points) {
    const g = x.createRadialGradient(px * sw, py * sh, 0, px * sw, py * sh, rad * R * 1.15);
    g.addColorStop(0, rgba(col, 1)); g.addColorStop(0.5, rgba(col, 0.55)); g.addColorStop(1, rgba(col, 0));
    x.fillStyle = g; x.fillRect(0, 0, sw, sh);
  }
  ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(c, 0, 0, W, H);
}
function cosmic(ctx, b, W, H, seed = 1) {
  ctx.fillStyle = b.base; ctx.fillRect(0, 0, W, H);
  const D = Math.max(W, H);
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const [x, y, r, col, a] of b.glows) {
    const g = ctx.createRadialGradient(x * W, y * H, 0, x * W, y * H, r * D);
    g.addColorStop(0, rgba(col, a)); g.addColorStop(0.45, rgba(col, a * 0.35)); g.addColorStop(1, rgba(col, 0));
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }
  ctx.restore();
  if (b.stars) {
    const r = rand(42 + seed);
    const n = Math.round(W * H / 9000);
    for (let i = 0; i < n; i++) {
      const s = r() < 0.92 ? D * 0.0008 : D * 0.0016;
      ctx.fillStyle = `rgba(255,255,255,${0.25 + r() * 0.6})`;
      ctx.beginPath(); ctx.arc(r() * W, r() * H, s, 0, Math.PI * 2); ctx.fill();
    }
  }
}
function arcs(ctx, b, W, H) {
  const g0 = ctx.createLinearGradient(0, 0, 0, H);
  g0.addColorStop(0, b.base[0]); g0.addColorStop(1, b.base[1]);
  ctx.fillStyle = g0; ctx.fillRect(0, 0, W, H);
  // Glow rings painted at low resolution so they come out soft.
  const sw = 160, sh = Math.max(8, Math.round(160 * H / W));
  const c = offscreen(sw, sh), x = c.getContext('2d');
  const cx = sw / 2, cy = sh * b.y;
  const R = Math.max(sw * 0.62, sh * 0.55);
  [[1.0, b.arcs[0], 0.95], [0.9, b.arcs[1], 0.8], [0.8, b.arcs[0], 0.55], [0.68, b.arcs[1], 0.35]].forEach(([k, col, a]) => {
    const r = R * k;
    const g = x.createRadialGradient(cx, cy, r * 0.82, cx, cy, r * 1.08);
    g.addColorStop(0, rgba(col, 0)); g.addColorStop(0.55, rgba(col, a)); g.addColorStop(0.75, rgba(col, a * 0.5)); g.addColorStop(1, rgba(col, 0));
    x.fillStyle = g; x.fillRect(0, 0, sw, sh);
  });
  ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(c, 0, 0, W, H);
}
function waves(ctx, b, W, H) {
  ctx.fillStyle = b.base; ctx.fillRect(0, 0, W, H);
  const r = rand(b.seed || 1);
  const n = b.colors.length;
  b.colors.forEach((col, i) => {
    const top = H * (0.25 + (i / n) * 0.6);
    const amp = H * (0.05 + r() * 0.05);
    const f1 = 1 + r() * 1.5, f2 = 2 + r() * 2, ph = r() * Math.PI * 2;
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,.22)';
    ctx.shadowBlur = H * 0.03;
    ctx.shadowOffsetY = -H * 0.006;
    ctx.beginPath();
    ctx.moveTo(0, H);
    for (let s = 0; s <= 64; s++) {
      const t = s / 64;
      ctx.lineTo(t * W, top + Math.sin(t * Math.PI * f1 + ph) * amp + Math.sin(t * Math.PI * f2 + ph * 1.7) * amp * 0.4);
    }
    ctx.lineTo(W, H); ctx.closePath();
    ctx.fillStyle = col; ctx.fill();
    ctx.restore();
  });
}
function pattern(ctx, b, W, H) {
  ctx.fillStyle = b.base; ctx.fillRect(0, 0, W, H);
  const u = Math.max(W, H) / 60;
  ctx.save();
  if (b.type === 'dots') {
    ctx.fillStyle = rgba(b.ink, 0.16);
    for (let y = u / 2; y < H; y += u) for (let x = u / 2; x < W; x += u) { ctx.beginPath(); ctx.arc(x, y, u * 0.09, 0, Math.PI * 2); ctx.fill(); }
  } else if (b.type === 'grid') {
    ctx.strokeStyle = rgba(b.ink, 0.1); ctx.lineWidth = Math.max(1, u * 0.04);
    ctx.beginPath();
    for (let x = 0; x <= W; x += u * 1.5) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
    for (let y = 0; y <= H; y += u * 1.5) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
    ctx.stroke();
  } else if (b.type === 'lines') {
    ctx.strokeStyle = rgba(b.ink, 0.12); ctx.lineWidth = Math.max(1, u * 0.08);
    ctx.beginPath();
    for (let x = -H; x < W; x += u * 0.9) { ctx.moveTo(x, H); ctx.lineTo(x + H, 0); }
    ctx.stroke();
  } else if (b.type === 'grain') {
    ctx.globalAlpha = 0.18;
    ctx.globalCompositeOperation = 'multiply';
    ctx.fillStyle = ctx.createPattern(noiseTile(), 'repeat');
    ctx.fillRect(0, 0, W, H);
  }
  ctx.restore();
  const g = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.hypot(W, H) / 2);
  g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, rgba(b.ink, 0.06));
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
}

let noise = null;
export function noiseTile() {
  if (noise) return noise;
  const c = offscreen(192, 192), x = c.getContext('2d');
  const d = x.createImageData(192, 192);
  const r = rand(7);
  for (let i = 0; i < d.data.length; i += 4) { const v = r() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; }
  x.putImageData(d, 0, 0);
  noise = c;
  return c;
}

function cover(ctx, img, W, H) {
  const s = Math.max(W / img.width, H / img.height);
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, (W - img.width * s) / 2, (H - img.height * s) / 2, img.width * s, img.height * s);
}

// Paints a preset. assets: Map of loaded images (wallpapers keyed "wp:<file>").
export function paintPreset(ctx, b, W, H, assets) {
  switch (b.kind) {
    case 'solid': ctx.fillStyle = b.color; ctx.fillRect(0, 0, W, H); break;
    case 'linear': linear(ctx, b, W, H); break;
    case 'radial': radial(ctx, b, W, H); break;
    case 'conic': conic(ctx, b, W, H); break;
    case 'mesh': mesh(ctx, b, W, H); break;
    case 'cosmic': cosmic(ctx, b, W, H); break;
    case 'arc': arcs(ctx, b, W, H); break;
    case 'waves': waves(ctx, b, W, H); break;
    case 'pattern': pattern(ctx, b, W, H); break;
    case 'wallpaper': {
      const img = assets && (assets.get(`wp:${b.file}`) || assets.get(`wpt:${b.file}`));
      if (img) cover(ctx, img, W, H);
      else { ctx.fillStyle = '#1e2330'; ctx.fillRect(0, 0, W, H); }
      break;
    }
    default: ctx.fillStyle = '#222'; ctx.fillRect(0, 0, W, H);
  }
}

// "Magic": backgrounds built from the colours of the user's screenshot.
export const MAGIC_STYLES = [
  { id: 'mesh', name: 'Mesh' }, { id: 'linear', name: 'Gradient' }, { id: 'soft', name: 'Soft' }, { id: 'glow', name: 'Glow' }
];
export function magicPreset(style, pal) {
  const p = pal && pal.length ? pal : ['#1f2a44', '#6d4aff', '#0e7c86', '#c6f432'];
  const [a, b, c, d] = [p[0], p[1] || p[0], p[2] || p[1] || p[0], p[3] || p[0]];
  if (style === 'linear') return { kind: 'linear', angle: 135, stops: [[0, b], [0.5, c], [1, a]] };
  if (style === 'soft') return { kind: 'mesh', base: '#f5f5f7', points: [[0.15, 0.2, b, 0.55], [0.9, 0.85, c, 0.6], [0.85, 0.1, d, 0.45]] };
  if (style === 'glow') return { kind: 'cosmic', base: '#07080c', glows: [[0.2, 0.9, 0.75, b, 0.8], [0.85, 0.15, 0.6, c, 0.6], [0.5, 0.5, 0.4, d, 0.35]], stars: 0 };
  return { kind: 'mesh', base: a, points: [[0.12, 0.15, b, 0.6], [0.9, 0.2, c, 0.55], [0.8, 0.95, d, 0.65], [0.1, 0.95, b, 0.5]] };
}

export function toneOf(b) {
  // Rough average colour, for picking readable text.
  if (!b) return '#222222';
  const cols = b.kind === 'solid' ? [b.color]
    : b.stops ? b.stops.map((s) => s[1])
      : b.kind === 'mesh' ? [b.base, b.base, ...b.points.map((p) => p[2])]
        : b.kind === 'cosmic' ? [b.base, b.base, b.base]
          : b.kind === 'arc' ? [...b.base, b.base[0]]
            : b.kind === 'waves' ? [b.base, ...b.colors.slice(0, 2)]
              : b.kind === 'pattern' ? [b.base]
                : b.kind === 'wallpaper' ? [({ 'ember-night': '#2a1d1a', 'grape-aurora': '#2b1d4a', 'midnight-bloom': '#1d1d3a', 'fern-mist': '#24352c' })[b.file] || '#e8d8d0'] : ['#222222'];
  let r = 0, g = 0, bl = 0;
  for (const c of cols) { const [x, y, z] = rgb(c); r += x; g += y; bl += z; }
  const n = cols.length;
  return '#' + [r / n, g / n, bl / n].map((v) => Math.round(v).toString(16).padStart(2, '0')).join('');
}
