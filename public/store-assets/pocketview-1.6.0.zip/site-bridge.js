// Runs on getpocketview.com only. Lets the website hand a Pro licence to this extension
// after checkout or sign-in, so customers never copy a key by hand.
(() => {
  document.documentElement.setAttribute('data-pocketview', chrome.runtime.getManifest().version);
  window.addEventListener('message', (e) => {
    if (e.source !== window || e.origin !== location.origin) return;
    const d = e.data;
    if (!d || d.type !== 'pocketview:license' || typeof d.token !== 'string') return;
    chrome.runtime.sendMessage({ type: 'pv:license:set', token: d.token }, (res) => {
      void chrome.runtime.lastError;
      window.postMessage({ type: res && res.ok ? 'pocketview:license:ok' : 'pocketview:license:error' }, location.origin);
    });
  });
})();
