// Small IndexedDB store shared by the simulator and Studio (same extension origin).
// images: id -> Blob, kv: key -> any JSON value.

const DB_NAME = 'pocketview-studio';
let dbp = null;

function db() {
  if (dbp) return dbp;
  dbp = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const d = req.result;
      if (!d.objectStoreNames.contains('images')) d.createObjectStore('images');
      if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv');
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbp;
}

async function tx(store, mode, fn) {
  const d = await db();
  return new Promise((resolve, reject) => {
    const t = d.transaction(store, mode);
    const s = t.objectStore(store);
    const r = fn(s);
    t.oncomplete = () => resolve(r && 'result' in r ? r.result : undefined);
    t.onerror = () => reject(t.error);
  });
}

const uid = () => `img_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;

export async function putImage(blob, id = uid()) { await tx('images', 'readwrite', (s) => s.put(blob, id)); return id; }
export function getImage(id) { return tx('images', 'readonly', (s) => s.get(id)); }
export function deleteImage(id) { return tx('images', 'readwrite', (s) => s.delete(id)); }
export function allImageIds() { return tx('images', 'readonly', (s) => s.getAllKeys()); }
export function setKV(key, value) { return tx('kv', 'readwrite', (s) => s.put(value, key)); }
export function getKV(key) { return tx('kv', 'readonly', (s) => s.get(key)); }
export function delKV(key) { return tx('kv', 'readwrite', (s) => s.delete(key)); }
