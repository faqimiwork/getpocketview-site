// Runs in the page's own JS world, only inside PocketView device frames.
// Makes navigator.* match the simulated device so JS-based mobile detection works,
// and emulates prefers-color-scheme for matchMedia when dark/light mode is forced.
(() => {
  try {
    if (window === window.top) return;
    const anc = location.ancestorOrigins;
    if (!anc || !anc.length || !anc[anc.length - 1].startsWith('chrome-extension://')) return;
    const raw = window.name || '';
    if (!raw.startsWith('__pv__:')) return;
    const cfg = JSON.parse(raw.slice(7));

    const def = (obj, key, value) => {
      try { Object.defineProperty(obj, key, { get: () => value, configurable: true }); } catch (e) { /* ignore */ }
    };

    // ----- color scheme and display-mode emulation (JS side) -----
    const scheme = cfg.scheme === 'dark' || cfg.scheme === 'light' ? cfg.scheme : null;
    const mode = cfg.displayMode && cfg.displayMode !== 'browser' ? cfg.displayMode : null;
    if (scheme || mode) {
      const YES = '(min-width: 0px)';
      const NO = '(max-width: 0.001px)';
      const rewrite = (q) => {
        let t = String(q);
        if (scheme) t = t.replace(/\(\s*prefers-color-scheme\s*:\s*(dark|light)\s*\)/gi, (m, s) => (s.toLowerCase() === scheme ? YES : NO));
        if (mode) t = t.replace(/\(\s*display-mode\s*:\s*([a-z-]+)\s*\)/gi, (m, s) => (s.toLowerCase() === mode ? YES : NO));
        return t;
      };
      const orig = window.matchMedia.bind(window);
      const patched = function matchMedia(q) { return orig(rewrite(q)); };
      try { Object.defineProperty(window, 'matchMedia', { value: patched, configurable: true, writable: true }); } catch (e) { /* ignore */ }
    }

    const nav = Navigator.prototype;
    const isIOS = cfg.os === 'ios' || cfg.os === 'ipados';
    if (mode && isIOS) def(nav, 'standalone', true);
    if (!cfg.ua) return;
    const platform = cfg.os === 'ios' ? 'iPhone' : cfg.os === 'ipados' ? 'MacIntel' : 'Linux armv81';

    def(nav, 'userAgent', cfg.ua);
    def(nav, 'appVersion', cfg.ua.replace(/^Mozilla\//, ''));
    def(nav, 'platform', platform);
    def(nav, 'maxTouchPoints', 5);
    if (isIOS) def(nav, 'vendor', 'Apple Computer, Inc.');
    if (cfg.dpr) def(window, 'devicePixelRatio', cfg.dpr);

    if ('userAgentData' in navigator && !isIOS) {
      const real = navigator.userAgentData;
      const mobile = /Mobile/.test(cfg.ua);
      const fake = {
        brands: real.brands,
        mobile,
        platform: 'Android',
        getHighEntropyValues: (hints) => real.getHighEntropyValues(hints).then((v) => Object.assign(v, { mobile, platform: 'Android', model: '' })),
        toJSON: () => ({ brands: real.brands, mobile, platform: 'Android' })
      };
      def(nav, 'userAgentData', fake);
    } else if (isIOS) {
      def(nav, 'userAgentData', undefined);
    }

    // Touch capability detection ("ontouchstart" in window).
    if (!('ontouchstart' in window)) window.ontouchstart = null;
  } catch (e) { /* never break the page */ }
})();
