# PocketView: Mobile Simulator & Responsive Viewer

Chrome extension (Manifest V3) untuk preview mana-mana website dalam frame iPhone, Android, iPad dan desktop, side by side.

## Cara install (mode developer)

1. Unzip `pocketview.zip` ke satu folder.
2. Buka `chrome://extensions` di Chrome.
3. Hidupkan **Developer mode** (penjuru kanan atas).
4. Klik **Load unpacked**, pilih folder `pocketview`.
5. Pin ikon PocketView di toolbar.

## Cara guna

- Buka mana-mana website, klik ikon PocketView (atau tekan `Alt + Shift + M`). Tab tu akan bertukar jadi simulator.
- Klik ikon sekali lagi (atau butang X) untuk keluar dan kembali ke page asal.
- Klik kanan pada link: **Open link in PocketView** untuk buka terus dalam tab baru.

### Shortcut dalam simulator

| Kekunci | Fungsi |
|---|---|
| `R` | Rotate semua device |
| `S` | Screenshot PNG |
| `F` | Fold/unfold semua foldable |
| `M` | Buka/tutup Mockup Studio |
| `/` | Fokus URL bar |
| `Esc` | Tutup menu |

## Features (v1.2)

**Device & paparan**
- 95 device: Responsive (drag saiz bebas + ruler breakpoint sm/md/lg/xl/2xl), foldable terkini (iPhone Duo, Galaxy Z Fold8 / Fold8 Ultra / Flip8, Xiaomi 18 Fold), iPhone 18 Pro sampai iPhone 5, Galaxy S26 Ultra, Pixel 11 Pro, Xiaomi 17, Motorola, Zebra rugged, iPad, laptop, desktop, plus custom device
- Versi free: 2 device serentak, rakaman 15 saat, export Studio 1x dengan badge. Pro: 6 device, rakaman tanpa had, export sehingga 4x tanpa badge. Had semua dalam `LIMITS` di `license.js`; lesen disemak melalui getpocketview.com/api (lihat `license.js`, `account-ui.js`, `site-bridge.js`). Quick sets semua dalam pasangan: iPhone + Android, Phone + Tablet, Foldables, Small vs Large, Mobile + Desktop, Responsive
- Device picker baru: kad dengan bentuk skrin sebenar, tab kategori, carian, tray device yang sedang dipaparkan
- Butang Fold/Unfold untuk foldable, lengkap dengan garis lipatan. iPhone Duo bertutup ada lajur kawalan Safari di kanan (viewport 382px, ikut WebKit), engsel di kiri. Galaxy Z Fold8 dan Xiaomi 18 Fold jenis "wide": skrin dalam landskap bila dibuka. Fold8 dan Fold8 Ultra bucu kecil hampir segi empat (Ultra dibuka 954×860); Z Flip8 clamshell dengan skrin luar FlexWindow penuh (dua kamera di bucu bawah kiri) dan punch-hole bila dibuka; Xiaomi 18 Fold bucu kiri bersegi dan kanan bulat (ikut rekaan sebenar)
- **Display mode**: Browser / App (macam PWA dah di-install: tiada browser bar, status bar ikut theme-color, `display-mode: standalone`, `navigator.standalone`) / Fullscreen (edge-to-edge bawah notch, `display-mode: fullscreen`)
- Launch splash untuk App mode guna ikon, nama dan background_color dari manifest site
- Warna frame global (Midnight, Silver, Titanium, Desert, Cream, Lavender, Blue, Orange dan lain-lain) + warna rasmi per device untuk foldable: iPhone Duo (Star White, Night Sky), Xiaomi 18 Fold (Rose, Cream, Graphite, Red), Z Fold8 (Lavender, Cream, Graphite, Pistachio), Z Fold8 Ultra (Violet Shadow, Cream, Graphite, Violet Green), Z Flip8 (Pink, Cream, Graphite, Mint). Klik titik warna di header device untuk tukar, screen glare, animasi rotate/fold
- **Ambient light**: cahaya lembut di belakang setiap device ikut warna kandungan skrin, status bar ikut warna header site

**Capture**
- Screenshot PNG (transparent atau dengan background)
- **Rakam video MP4** (atau WebM) 30 fps sampai 3 minit, dan **GIF** 10 fps sampai 20 saat. Hanya kawasan device dirakam, klik keluar sebagai touch ripple
- **Mockup Studio**: background Ambient (auto dari warna site) + 11 gradient/solid + custom, saiz siap (1080×1080, 1080×1350, Story 1080×1920, 1920×1080, Chrome Web Store 1280×800, OG 1200×630), headline boleh edit, tilt 3D, shadow, padding. Screenshot dan video ikut kanvas ni tepat

**Developer**
- Responsive device dengan drag handle + ruler breakpoint
- Force dark mode (`prefers-color-scheme: dark`)
- Drag to scroll dengan momentum (rasa macam jari)
- Sync scroll & klik antara semua device
- User agent sebenar per device (header + JS), touch cursor, scrollbar tersembunyi
- Copy setup link: kongsi URL + set device + orientasi + mode kepada team/client

Tiada data dikumpul, tiada server, semua jalan dalam browser.

## Cara ia berfungsi (teknikal)

- `simulator.html` ialah page extension yang embed website dalam `<iframe>`.
- `background.js` pasang rule `declarativeNetRequest` **hanya untuk tab simulator**: buang header `X-Frame-Options` / `Content-Security-Policy` pada sub-frame (supaya site boleh di-embed) dan set header `User-Agent` mobile. Rule dibuang automatik bila tab ditutup atau keluar dari simulator.
- Rakaman guna `getDisplayMedia` (tab semasa, Chrome minta izin sekali), crop ke kawasan device dalam canvas, encode dengan MediaRecorder (MP4/WebM) atau gifenc (GIF, lesen MIT, dalam `vendor/`).
- Ambient light guna `captureVisibleTab` (jarang, bila page berubah) untuk sample warna skrin.
- `frame-main.js` dan `frame-isolated.js` didaftar secara dinamik hanya bila ada simulator terbuka. Ia cuma aktif dalam iframe yang parent-nya PocketView (semak `location.ancestorOrigins` + `window.name`).

## Had yang diketahui

- Site yang cuba ambil alih tab (frame-busting) dikesan automatik: tab dibawa balik ke simulator dan site tu dimuat dalam mod contained (sandbox). Senarai site ni diingat dalam storage extension.

- Saiz iPhone Duo ikut angka WebKit (Safari 27.1). Saiz foldable Android dianggarkan dari resolusi panel; semak dengan device sebenar bila ada.

- Ini simulator viewport + user agent, bukan engine Safari sebenar. Rendering tetap guna Chromium. Untuk validasi akhir, test di phone sebenar.
- Sesetengah site yang guna proteksi tambahan (contoh: halaman login Google/bank) mungkin masih tak boleh dipaparkan dalam iframe.
- Bila campur iPhone + Android dalam satu view, header HTTP guna UA device pertama; JS UA setiap frame tetap betul.
- CSS media query `(pointer: coarse)` / `(hover: none)` tak berubah (had Chrome tanpa DevTools protocol).
- Dark mode bergantung pada site sokong `prefers-color-scheme`. Network throttling tak disediakan sebab perlukan permission `debugger` yang menakutkan pengguna dan reviewer Web Store.
- Kualiti screenshot Mockup bergantung pada skrin: di skrin Retina tajam, di monitor 1080p ia di-upscale sedikit.

## Struktur fail

```
manifest.json        Konfigurasi MV3
background.js        Service worker: rules header, context menu, toggle
simulator.html/css/js  UI simulator
recorder.js          Rakaman video/GIF
ambient.js           Sampling warna untuk ambient light
vendor/gifenc.js     Encoder GIF (MIT)
devices.js           Senarai device + preset (edit sini untuk tambah device)
frame-main.js        Override navigator.* dalam frame
frame-isolated.js    Gaya mobile, sync scroll, laporan URL
icons/               Ikon 16/32/48/128
STORE_LISTING.md     Draf listing Chrome Web Store (SEO)
PRIVACY.md           Privacy policy untuk Web Store
```

## Publish ke Chrome Web Store

1. Daftar akaun developer (yuran sekali USD 5): https://chrome.google.com/webstore/devconsole
2. Zip kandungan folder (bukan folder induk), upload.
3. Copy teks dari `STORE_LISTING.md`, upload 5 screenshot 1280x800 dan promo tile 440x280.
4. Justifikasi permission (`<all_urls>`, `declarativeNetRequestWithHostAccess`, `scripting`) ada dalam `STORE_LISTING.md`. Ini penting supaya review lulus.
5. Host `PRIVACY.md` di website (contoh: domain-anda.com/pocketview-privacy) dan letak link dalam listing.

## Credits

PocketView Studio uses background presets, shadow presets and twelve wallpapers from
[Shotcandy](https://github.com/btahir/shotcandy) by Bilal Tahir, released under the MIT License.
The licence text ships in `backgrounds/LICENSE-shotcandy.txt`.
