// PocketView Pro licence: stored on this computer, checked against getpocketview.com about
// once a day. Shared by the simulator, Studio and the service worker.
export const SITE = 'https://getpocketview.com';
const KEY = 'pvLicense';
const CHECK_MS = 20 * 60 * 60 * 1000; // re-check about once a day
const GRACE_MS = 7 * 24 * 60 * 60 * 1000; // stay Pro offline for a week after the last good check
const ALLOWED_API = /^https:\/\/(getpocketview\.com|[a-z0-9-]+--getpocketview\.netlify\.app)$/;

export const LIMITS = {
  free: { devices: 2, recordSec: 15, exportScale: 1, watermark: true },
  pro: { devices: 6, recordSec: 0, exportScale: 4, watermark: false },
};

async function read() {
  const o = await chrome.storage.local.get(KEY);
  return o[KEY] || {};
}
async function write(rec) {
  await chrome.storage.local.set({ [KEY]: rec });
  return rec;
}
const apiOf = (rec) => (rec.api && ALLOWED_API.test(rec.api) ? rec.api : SITE) + '/api';

export function isPro(rec) {
  if (!rec || !rec.token || !rec.plan || !rec.plan.pro) return false;
  return Date.now() - (rec.okAt || 0) < GRACE_MS;
}
export const limitsOf = (rec) => (isPro(rec) ? LIMITS.pro : LIMITS.free);

async function call(rec, path, { method = 'POST', body, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth && rec.token) headers.Authorization = `Bearer ${rec.token}`;
  const res = await fetch(apiOf(rec) + path, { method, headers, body: body ? JSON.stringify(body) : undefined, cache: 'no-store' });
  let data = {};
  try { data = await res.json(); } catch {}
  return { status: res.status, data };
}

// Returns the stored licence, refreshing it in the background when it is due.
export async function getLicense({ refresh = 'auto' } = {}) {
  const rec = await read();
  if (rec.token && (refresh === true || (refresh === 'auto' && Date.now() - (rec.checkedAt || 0) > CHECK_MS))) {
    const p = refreshLicense(rec);
    if (refresh === true) return p;
  }
  return rec;
}

let inflight = null;
export function refreshLicense(rec0) {
  if (inflight) return inflight;
  inflight = (async () => {
    const rec = rec0 || (await read());
    if (!rec.token) return rec;
    // Only save if the licence was not replaced or signed out while the check was running.
    const save = async (next) => { const now = await read(); return now.token === rec.token ? write(next) : now; };
    try {
      const { status, data } = await call(rec, '/license?fresh=1', { method: 'GET' });
      if (status === 401) return save({ api: rec.api });
      if (status !== 200) return save({ ...rec, checkedAt: Date.now() });
      return save({ ...rec, plan: data, checkedAt: Date.now(), okAt: Date.now() });
    } catch {
      return save({ ...rec, checkedAt: Date.now() }); // offline: keep the grace period running
    } finally {
      setTimeout(() => { inflight = null; }, 0);
    }
  })();
  return inflight;
}

export async function setToken(token, api) {
  if (!/^pvl_[A-Za-z0-9_-]{20,64}$/.test(token || '')) throw new Error('Invalid licence');
  const rec = { token, api: api && ALLOWED_API.test(api) ? api : undefined };
  await write(rec);
  return refreshLicense(rec);
}

export async function startSignIn(email) {
  const rec = await read();
  const { data } = await call(rec, '/login/start', { body: { email }, auth: false });
  if (data.error) throw new Error(data.error);
  return data;
}
export async function finishSignIn(email, code) {
  const rec = await read();
  const { data } = await call(rec, '/login/verify', { body: { email, code, label: 'extension' }, auth: false });
  if (!data.token) throw new Error(data.error || 'That code did not work.');
  return write({ api: rec.api, token: data.token, plan: data, checkedAt: Date.now(), okAt: Date.now() });
}
export async function signOut() {
  const rec = await read();
  if (rec.token) call(rec, '/license', { method: 'DELETE' }).catch(() => {});
  return write({ api: rec.api });
}
export async function checkoutUrl(plan) {
  const rec = await read();
  const { data } = await call(rec, '/checkout', { body: { plan, source: 'extension' }, auth: false });
  if (!data.url) throw new Error(data.error || 'Could not open checkout.');
  return data.url;
}
export async function portalUrl() {
  const rec = await read();
  const { status, data } = await call(rec, '/portal');
  if (status === 401) { await write({ api: rec.api }); throw new Error('Please sign in again.'); }
  if (!data.url) throw new Error(data.error || 'Could not open billing.');
  return data.url;
}

export function onLicenseChange(cb) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[KEY]) cb(changes[KEY].newValue || {});
  });
}
