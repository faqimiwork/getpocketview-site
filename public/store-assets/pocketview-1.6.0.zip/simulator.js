import { DEVICES, PRESETS, customDevice } from './devices.js';
import { Recorder, pickVideoMime } from './recorder.js';
import { captureTab, sample, luminance, hexToRgb, mix, toHex } from './ambient.js';
import { putImage, setKV } from './studio-store.js';
import { getLicense, limitsOf, isPro, onLicenseChange } from './license.js';
import { openAccount, wirePlanButton } from './account-ui.js';
import { qrSvg } from './qr.js';

// ---------- constants ----------
const DEFAULTS = {
  selected: ['iphone-16'],
  orient: {},
  open: {},
  devFinish: {},
  zoom: 'fit',
  frame: true,
  finish: 'midnight',
  ambient: true,
  glare: false,
  statusBar: true,
  browserBar: false,
  display: 'browser',
  splash: true,
  dragScroll: true,
  touchCursor: true,
  hideScrollbars: true,
  darkScheme: false,
  sync: true,
  formSync: true,
  transparentShot: true,
  custom: [],
  resp: { w: 390, h: 844 },
  mock: {
    on: false,
    bg: 'ambient',
    color: '#5b8cff',
    size: '1080x1350',
    headline: true,
    title: 'Looks great on every screen',
    sub: 'Built mobile first. Previewed with PocketView.',
    tilt: 'none',
    shadow: 'soft',
    pad: 72
  }
};
// Plan limits: Free shows 2 devices at a time, Pro up to 6 (see license.js).
let LIC = await getLicense();
let LIM = limitsOf(LIC);
let MAX_VIEWS = LIM.devices;
const limitMsg = () => (isPro(LIC)
  ? `You can show ${MAX_VIEWS} devices at a time. Remove one to add another.`
  : `The free version shows ${MAX_VIEWS} devices at a time. Pro shows up to 6.`);
function hitDeviceLimit() {
  if (isPro(LIC)) { toast(limitMsg(), 3800); flashTray(); return; }
  flashTray();
  openAccount({ reason: `Free shows ${MAX_VIEWS} devices at a time. Pro shows up to 6 side by side.` });
}
const SIDE = { devices: '#devicesPop', view: '#viewPop' };
let sidePanel = null;
let reserveW = 0;
const GAP = 40;

const FINISHES = [
  ['midnight', '#2b2f37', 'Midnight'], ['silver', '#e3e5e9', 'Silver'], ['titanium', '#9a9792', 'Titanium'],
  ['desert', '#cdb497', 'Desert'], ['cream', '#ece4d6', 'Cream'], ['lavender', '#c9bfe0', 'Lavender'],
  ['rose', '#e7c3ba', 'Rose'], ['graphite', '#45474c', 'Graphite'], ['red', '#b3182e', 'Red'],
  ['starwhite', '#ececea', 'Star White'], ['nightsky', '#2b3a55', 'Night Sky'],
  ['violetshadow', '#4a4458', 'Violet Shadow'], ['violetgreen', '#2f4a3e', 'Violet Green'],
  ['pistachio', '#cfe3d6', 'Pistachio'], ['pink', '#f0c6d4', 'Pink'], ['mint', '#cdeedd', 'Mint'], ['blue', '#4d6a9a', 'Blue'], ['orange', '#e2793a', 'Orange']
];

const BACKGROUNDS = [
  { id: 'ambient', name: 'Ambient (from the site)' },
  { id: 'pocket', name: 'PocketView dark', css: 'radial-gradient(circle at 72% 28%, #3f5410 0%, #161d0c 38%, #0d1016 72%)', ink: '#fff' },
  { id: 'lime', name: 'Lime', css: '#c6f432', ink: '#0d1016' },
  { id: 'aurora', css: 'linear-gradient(135deg, #1e3c72 0%, #7c5cff 55%, #ff6ec4 100%)', ink: '#fff' },
  { id: 'sunset', css: 'linear-gradient(135deg, #ff7e5f 0%, #feb47b 100%)', ink: '#2a1408' },
  { id: 'ocean', css: 'linear-gradient(135deg, #00c6ff 0%, #0072ff 100%)', ink: '#fff' },
  { id: 'forest', css: 'linear-gradient(135deg, #134e5e 0%, #71b280 100%)', ink: '#fff' },
  { id: 'grape', css: 'linear-gradient(135deg, #41295a 0%, #2f0743 100%)', ink: '#fff' },
  { id: 'peach', css: 'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)', ink: '#3a1d12' },
  { id: 'mint', css: 'linear-gradient(135deg, #d4fc79 0%, #96e6a1 100%)', ink: '#0f2a14' },
  { id: 'cotton', css: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)', ink: '#1d2333' },
  { id: 'midnight', css: 'radial-gradient(circle at 30% 20%, #2b3245 0%, #0b0d12 70%)', ink: '#fff' },
  { id: 'paper', css: '#f4f1ea', ink: '#1b1b1b' },
  { id: 'black', css: '#0a0a0a', ink: '#fff' }
];

const BREAKPOINTS = [
  { n: 'sm', w: 640 }, { n: 'md', w: 768 }, { n: 'lg', w: 1024 }, { n: 'xl', w: 1280 }, { n: '2xl', w: 1536 }
];
const WIDTH_CHIPS = [360, 390, 768, 1024, 1280, 1440];

// ---------- state ----------
let S;
let tabId;
let currentUrl = '';
let registeredUA;
let lastScale = 1;
let resizing = false;
let capturing = false;
let recorder = null;
let ambientPalette = null;
const views = new Map();
const touches = new Map();
// Sites that tried to take over the tab. Only these get a sandboxed frame.
const CONTAIN_SANDBOX = 'allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-presentation';
let containHosts = new Set();

const $ = (sel) => document.querySelector(sel);
const el = (tag, cls, html) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (html != null) n.innerHTML = html;
  return n;
};
const nextFrame = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const broadcast = (msg) => chrome.tabs.sendMessage(tabId, msg).catch(() => {});

// ---------- settings ----------
function allDevices() { return [...DEVICES, ...S.custom.map(customDevice)]; }
function byId(id) { return allDevices().find((d) => d.id === id); }

async function loadSettings() {
  const { pvSettings: saved = {} } = await chrome.storage.local.get('pvSettings');
  S = Object.assign({}, DEFAULTS, saved);
  S.orient = S.orient || {};
  S.open = S.open || {};
  S.devFinish = S.devFinish || {};
  S.custom = S.custom || [];
  S.resp = Object.assign({}, DEFAULTS.resp, saved.resp || {});
  S.mock = Object.assign({}, DEFAULTS.mock, saved.mock || {});
  if (!saved.finish && saved.darkBezel === false) S.finish = 'silver';
  delete S.darkBezel;
  S.selected = (S.selected || []).filter((id) => byId(id)).slice(0, MAX_VIEWS);
  if (!S.selected.length) S.selected = [...DEFAULTS.selected];
}
let saveTimer;
function saveSettings() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => chrome.storage.local.set({ pvSettings: S }), 150);
}

// ---------- helpers ----------
function normalizeUrl(input) {
  let v = (input || '').trim();
  if (!v) return '';
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) {
    if (!/^https?:\/\//i.test(v)) return null;
  } else {
    const local = /^(localhost|127\.|10\.|192\.168\.|\d+\.\d+\.\d+\.\d+)/i.test(v);
    v = (local ? 'http://' : 'https://') + v;
  }
  try { return new URL(v).href; } catch (e) { return null; }
}

function hostOf(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch (e) { return url || ''; }
}

let toastTimer;
function toast(msg, ms = 2800) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, ms);
}

function download(blob, name) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 8000);
}
function fileStamp() { return new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19); }
function fileBase() { return `pocketview_${hostOf(currentUrl) || 'preview'}_${fileStamp()}`; }

function primaryUA() {
  const devs = S.selected.map(byId).filter(Boolean);
  if (!devs.length) return null;
  if (devs[0].ua) return devs[0].ua;
  const mobile = devs.find((d) => d.ua);
  return mobile ? mobile.ua : null;
}

async function register(ua) {
  if (ua === registeredUA) return false;
  const res = await chrome.runtime.sendMessage({ type: 'pv:bg:register', ua });
  if (!res || !res.ok) console.warn('PocketView: could not set up frame rules', res);
  registeredUA = ua;
  return true;
}

// ---------- device geometry ----------
function isResp(dev) { return dev.id === 'responsive'; }
function orientation(id) { return S.orient[id] || 'portrait'; }
function isOpen(dev) {
  if (!dev.fold) return false;
  const v = S.open[dev.id];
  return v == null ? !!dev.fold.defaultOpen : !!v;
}
function screenOf(dev) {
  if (isResp(dev)) return { w: S.resp.w, h: S.resp.h, radius: 0 };
  return isOpen(dev) ? dev.fold : dev;
}
function sizeOf(dev) {
  const s = screenOf(dev);
  if (isResp(dev)) return { w: s.w, h: s.h };
  return orientation(dev.id) === 'landscape' ? { w: s.h, h: s.w } : { w: s.w, h: s.h };
}
function displayName(dev) {
  if (!dev.fold) return dev.name;
  return `${dev.name} (${isOpen(dev) ? 'open' : 'folded'})`;
}
function kindOf(dev) {
  if (isResp(dev)) return 'responsive';
  if (dev.group === 'Foldable') return 'phone';
  if (dev.group === 'Tablet') return 'tablet';
  if (dev.group === 'Desktop') return 'desktop';
  if (dev.group === 'Custom') return dev.w >= 1000 ? 'desktop' : dev.w >= 700 ? 'tablet' : 'phone';
  return 'phone';
}
function isTouchy(dev) { const k = kindOf(dev); return k === 'phone' || k === 'tablet'; }
function frameOptions(dev) {
  const t = isTouchy(dev);
  return {
    touchCursor: S.touchCursor && t,
    hideScrollbars: S.hideScrollbars && t,
    dragScroll: S.dragScroll && t,
    formSync: !!(S.formSync && isPro(LIC))
  };
}
function frameConfig(dev) {
  return '__pv__:' + JSON.stringify(Object.assign({
    view: dev.id,
    ua: dev.ua,
    os: dev.os,
    dpr: dev.dpr,
    scheme: S.darkScheme ? 'dark' : null,
    displayMode: isResp(dev) ? 'browser' : ({ browser: 'browser', app: 'standalone', immersive: 'fullscreen' })[S.display] || 'browser'
  }, frameOptions(dev)));
}
function activeBreakpoint(w) {
  let a = null;
  for (const b of BREAKPOINTS) if (w >= b.w) a = b;
  return a;
}

// ---------- icons ----------
const ICON_ROTATE = '<svg class="ico" viewBox="0 0 24 24"><path d="M16.5 3.5 14 1v2.1A9 9 0 0 0 3 12h2a7 7 0 0 1 9-6.7V7.5l2.5-2.5V3.5ZM9 9h10a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Zm0 2v8h10v-8H9Z"/></svg>';
const ICON_FOLD = '<svg class="ico" viewBox="0 0 24 24"><path d="M4 4h7v16H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Zm1 2v12h4V6H5Zm8-2h7a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-7V4Zm2 2v12h4V6h-4Z"/></svg>';
const ICON_CLOSE = '<svg class="ico" viewBox="0 0 24 24"><path d="m6.4 5 5.6 5.6L17.6 5 19 6.4 13.4 12l5.6 5.6-1.4 1.4-5.6-5.6L6.4 19 5 17.6l5.6-5.6L5 6.4 6.4 5Z"/></svg>';
const STATUS_ICONS = `
  <svg viewBox="0 0 18 12"><rect x="0" y="8" width="3" height="4" rx="1"/><rect x="5" y="5.5" width="3" height="6.5" rx="1"/><rect x="10" y="3" width="3" height="9" rx="1"/><rect x="15" y="0" width="3" height="12" rx="1"/></svg>
  <svg viewBox="0 0 16 12"><path d="M8 2.6c2.4 0 4.6.9 6.2 2.5l1.3-1.4A10.6 10.6 0 0 0 8 .6 10.6 10.6 0 0 0 .5 3.7l1.3 1.4A8.7 8.7 0 0 1 8 2.6Zm0 3.7c1.4 0 2.7.5 3.6 1.4l1.4-1.4A7 7 0 0 0 8 4.3a7 7 0 0 0-5 2l1.4 1.4c1-.9 2.2-1.4 3.6-1.4Zm0 3.5c-.6 0-1.1.2-1.5.6L8 12l1.5-1.6c-.4-.4-.9-.6-1.5-.6Z"/></svg>
  <span class="batt"></span>`;
const DUO_COL = `
  <span class="duo-cam"></span>
  <span class="duo-time">9:41</span>
  <span class="duo-sig"><svg viewBox="0 0 16 12"><path d="M8 2.6c2.4 0 4.6.9 6.2 2.5l1.3-1.4A10.6 10.6 0 0 0 8 .6 10.6 10.6 0 0 0 .5 3.7l1.3 1.4A8.7 8.7 0 0 1 8 2.6Zm0 3.7c1.4 0 2.7.5 3.6 1.4l1.4-1.4A7 7 0 0 0 8 4.3a7 7 0 0 0-5 2l1.4 1.4c1-.9 2.2-1.4 3.6-1.4Zm0 3.5c-.6 0-1.1.2-1.5.6L8 12l1.5-1.6c-.4-.4-.9-.6-1.5-.6Z"/></svg><span class="batt"></span></span>
  <span class="duo-btns top">
    <i class="cbtn"><svg viewBox="0 0 24 24"><path d="m14.7 5.3 1.4 1.4L10.8 12l5.3 5.3-1.4 1.4L8 12l6.7-6.7Z"/></svg></i>
    <i class="cbtn"><svg viewBox="0 0 24 24"><path d="M5 4h6a3 3 0 0 1 1 .2A3 3 0 0 1 13 4h6v15h-6a2 2 0 0 0-1 .3 2 2 0 0 0-1-.3H5V4Zm2 2v11h4l.1.1V6.9a1 1 0 0 0-1-.9H7Zm10 0h-3a1 1 0 0 0-1 .9v10.2l.1-.1H17V6Z"/></svg></i>
  </span>
  <span class="duo-btns bottom">
    <i class="cbtn"><svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6V5Z"/></svg></i>
    <i class="cbtn"><svg viewBox="0 0 24 24"><path d="M8 3h11a2 2 0 0 1 2 2v11h-2V5H8V3ZM5 7h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Zm0 2v10h10V9H5Z"/></svg></i>
  </span>`;
const LOCK = '<svg viewBox="0 0 24 24"><path d="M17 9h-1V7a4 4 0 1 0-8 0v2H7a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2Zm-7-2a2 2 0 1 1 4 0v2h-4V7Z"/></svg>';

// ---------- device views ----------
function createView(dev) {
  const resp = isResp(dev);
  const slot = el('div', 'slot');
  slot.dataset.id = dev.id;
  const head = el('div', 'slot-head');
  head.innerHTML = `<span class="title"></span><span class="dims"></span><span class="bp"></span>
    ${resp ? WIDTH_CHIPS.map((w) => `<button class="wchip" data-w="${w}" title="Set width to ${w}px">${w}</button>`).join('') : ''}
    ${dev.colors ? '<button class="finish-dot" title="Change color"></button>' : ''}
    ${dev.fold ? `<button class="fold" title="Fold / unfold (F)">${ICON_FOLD}</button>` : ''}
    <button class="rot" title="Rotate">${ICON_ROTATE}</button>
    <button class="rm" title="Remove">${ICON_CLOSE}</button>`;

  const scaler = el('div', 'scaler');
  const glow = el('div', 'glow');
  const device = el('div', 'device');
  device.innerHTML = `
    <span class="deco btn-power"></span><span class="deco btn-vol1"></span><span class="deco btn-vol2"></span>
    <span class="speaker"></span><span class="home-btn"></span>
    <span class="fold-back"></span><span class="hinge"></span>
    <span class="hinge-mark top"></span><span class="hinge-mark bottom"></span>
    <div class="ruler"></div>
    <div class="screen">
      <div class="statusbar"><span class="time">9:41</span><span class="icons">${STATUS_ICONS}</span></div>
      <div class="browserbar top"><div class="addr">${LOCK}<span class="host"></span></div></div>
      <div class="viewport"><div class="loading">Loading…</div></div>
      <div class="splash"></div>
      <div class="browserbar bottom"><div class="addr">${LOCK}<span class="host"></span></div></div>
      <span class="cutout"></span>
      <span class="crease"></span>
      <span class="flip-cams"><i></i><i></i><b></b></span>
      <span class="glare"></span>
      <span class="home-indicator"></span>
      <div class="duo-col">${DUO_COL}</div>
    </div>
    <span class="rz rz-e" title="Drag to resize width"></span>
    <span class="rz rz-s" title="Drag to resize height"></span>
    <span class="rz rz-se" title="Drag to resize"></span>
    <div class="laptop-base"></div>`;

  const viewportEl = device.querySelector('.viewport');

  scaler.append(glow, device);
  slot.append(head, scaler);

  const v = {
    dev, slot, scaler, glow, device, iframe: null, viewportEl,
    screen: device.querySelector('.screen'),
    statusbar: device.querySelector('.statusbar'),
    duoCol: device.querySelector('.duo-col'),
    splash: device.querySelector('.splash'),
    app: null, splashAt: 0,
    ruler: device.querySelector('.ruler'),
    dimsEl: head.querySelector('.dims'),
    bpEl: head.querySelector('.bp'),
    titleEl: head.querySelector('.title'),
    hosts: device.querySelectorAll('.host'),
    url: '', reported: null, commandedAt: 0, scale: 1, topColor: null
  };

  head.querySelector('.rot').addEventListener('click', () => {
    if (resp) { S.resp = { w: S.resp.h, h: S.resp.w }; }
    else S.orient[dev.id] = orientation(dev.id) === 'portrait' ? 'landscape' : 'portrait';
    saveSettings();
    applyLayout(v);
    relayout();
    scheduleAmbient(600);
  });
  head.querySelector('.fold')?.addEventListener('click', () => toggleFold(v));
  head.querySelector('.finish-dot')?.addEventListener('click', () => {
    const list = dev.colors;
    const cur = list.indexOf(finishOf(dev));
    S.devFinish[dev.id] = list[(cur + 1) % list.length];
    saveSettings();
    applyLayout(v);
  });
  head.querySelector('.rm').addEventListener('click', () => {
    if (S.selected.length <= 1) { toast('Keep at least one device.'); return; }
    S.selected = S.selected.filter((id) => id !== dev.id);
    saveSettings();
    syncViews();
  });
  head.querySelectorAll('.wchip').forEach((b) => b.addEventListener('click', () => {
    S.resp.w = Number(b.dataset.w);
    saveSettings();
    applyLayout(v);
    relayout();
    scheduleAmbient(600);
  }));
  if (resp) wireResize(v);

  mountFrame(v);
  applyLayout(v);
  return v;
}

// A frame's config travels in window.name, which Chrome only hands to the page when the
// iframe is created. Config changes that need a reload therefore rebuild the iframe.
function mountFrame(v) {
  const iframe = document.createElement('iframe');
  iframe.setAttribute('allow', 'fullscreen; clipboard-write; autoplay; encrypted-media; picture-in-picture');
  iframe.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
  iframe.name = frameConfig(v.dev);
  iframe.style.colorScheme = S.darkScheme ? 'dark' : 'light';
  iframe.addEventListener('load', () => {
    v.viewportEl.classList.add('loaded');
    setTimeout(() => hideSplash(v), 1400);
  });
  if (v.iframe) v.iframe.replaceWith(iframe);
  else v.viewportEl.appendChild(iframe);
  v.iframe = iframe;
}
function rebuildAll() {
  for (const v of views.values()) {
    const url = v.url;
    mountFrame(v);
    if (url) loadView(v, url);
  }
}

function wireResize(v) {
  v.device.querySelectorAll('.rz').forEach((h) => {
    h.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      h.setPointerCapture(e.pointerId);
      h.classList.add('active');
      resizing = true;
      document.body.classList.add('resizing', 'no-anim');
      const dir = h.classList.contains('rz-e') ? 'e' : h.classList.contains('rz-s') ? 's' : 'se';
      const start = { x: e.clientX, y: e.clientY, w: S.resp.w, h: S.resp.h };
      const centered = $('#devices').scrollWidth <= $('#stage').clientWidth - reserveW + 1 && !(S.mock.on && S.mock.size !== 'free');
      const fx = centered ? 2 : 1;
      const s = v.scale * mockFit();
      const move = (ev) => {
        if (dir !== 's') S.resp.w = clamp(Math.round(start.w + fx * (ev.clientX - start.x) / s), 240, 2560);
        if (dir !== 'e') S.resp.h = clamp(Math.round(start.h + (ev.clientY - start.y) / s), 240, 2560);
        applyLayout(v);
        relayout();
      };
      const up = () => {
        h.removeEventListener('pointermove', move);
        h.classList.remove('active');
        resizing = false;
        document.body.classList.remove('resizing', 'no-anim');
        saveSettings();
        relayout();
        scheduleAmbient(400);
      };
      h.addEventListener('pointermove', move);
      h.addEventListener('pointerup', up, { once: true });
      h.addEventListener('pointercancel', up, { once: true });
    });
  });
}

function renderRuler(v) {
  const w = S.resp.w;
  let html = '';
  for (const t of [320, 375, 414, 480]) if (t < w - 30) html += `<div class="tick" style="left:${t}px">${t === 375 ? '<span>375</span>' : ''}</div>`;
  for (const b of BREAKPOINTS) if (b.w <= w) html += `<div class="tick bp" style="left:${b.w}px"><span>${b.n} ${b.w}</span></div>`;
  v.ruler.innerHTML = html;
}

function parseColor(str) {
  if (!str) return null;
  const ctx = parseColor.ctx || (parseColor.ctx = document.createElement('canvas').getContext('2d'));
  ctx.fillStyle = '#010203';
  ctx.fillStyle = String(str);
  const v = ctx.fillStyle;
  if (v === '#010203' && !/^#?010203$/i.test(String(str).trim())) return null;
  if (v.startsWith('#')) return hexToRgb(v);
  const m = v.match(/\d+(\.\d+)?/g);
  return m ? { r: +m[0], g: +m[1], b: +m[2] } : null;
}

function paintStatus(v) {
  paintBar(v);
  const sb = v.statusbar;
  v.duoCol.style.background = sb.style.background && sb.style.background !== 'transparent' ? sb.style.background : '';
  v.duoCol.style.color = sb.style.color || '';
}
function paintBar(v) {
  const ink = (c) => (luminance(c) > 0.42 ? '#000' : '#fff');
  if (S.display === 'immersive' && !isResp(v.dev)) {
    v.statusbar.style.background = 'transparent';
    v.statusbar.style.color = v.topColor ? ink(v.topColor) : '#000';
    return;
  }
  if (S.display === 'app' && !isResp(v.dev)) {
    const t = parseColor(v.app && v.app.themeColor) || (S.ambient && v.topColor) || null;
    if (t) {
      v.statusbar.style.background = `rgb(${t.r | 0}, ${t.g | 0}, ${t.b | 0})`;
      v.statusbar.style.color = ink(t);
      return;
    }
  }
  const c = S.ambient && v.topColor;
  if (c) {
    v.statusbar.style.background = `rgb(${c.r | 0}, ${c.g | 0}, ${c.b | 0})`;
    v.statusbar.style.color = luminance(c) > 0.42 ? '#000' : '#fff';
  } else {
    v.statusbar.style.background = '';
    v.statusbar.style.color = '';
  }
}

// ---------- launch splash (App modes) ----------
function splashWanted(v) { return S.splash && S.display !== 'browser' && !isResp(v.dev) && kindOf(v.dev) !== 'desktop'; }
function renderSplash(v) {
  const a = v.app || {};
  const host = hostOf(v.url);
  const bg = parseColor(a.bgColor) || parseColor(a.themeColor) || { r: 255, g: 255, b: 255 };
  v.splash.style.background = `rgb(${bg.r | 0}, ${bg.g | 0}, ${bg.b | 0})`;
  v.splash.style.color = luminance(bg) > 0.45 ? '#111' : '#fff';
  v.splash.innerHTML = '';
  if (a.icon) {
    const img = document.createElement('img');
    img.className = 'app-icon';
    img.alt = '';
    img.referrerPolicy = 'no-referrer';
    img.src = a.icon;
    img.onerror = () => { img.replaceWith(letterIcon(a.name || host)); };
    v.splash.appendChild(img);
  } else {
    v.splash.appendChild(letterIcon(a.name || host));
  }
  const name = el('div', 'app-name');
  name.textContent = a.name || host;
  v.splash.appendChild(name);
}
function letterIcon(text) {
  const d = el('div', 'app-letter');
  d.textContent = (String(text || '?').trim()[0] || '?').toUpperCase();
  return d;
}
function showSplash(v) {
  if (!splashWanted(v)) { v.splash.classList.remove('show'); return; }
  renderSplash(v);
  v.splashAt = performance.now();
  v.splash.classList.add('show');
}
function hideSplash(v) {
  if (!v.splash.classList.contains('show')) return;
  const left = 1100 - (performance.now() - v.splashAt);
  setTimeout(() => v.splash.classList.remove('show'), Math.max(0, left));
}

function applyLayout(v) {
  const { dev, device, screen } = v;
  const kind = kindOf(dev);
  const land = !isResp(dev) && orientation(dev.id) === 'landscape';
  const { w, h } = sizeOf(dev);

  device.className = [
    'device', kind, `notch-${isOpen(dev) && dev.fold.notch ? dev.fold.notch : dev.notch}`, `os-${dev.os}`,
    land ? 'landscape' : 'portrait',
    S.frame || kind === 'responsive' ? '' : 'noframe',
    `finish-${finishOf(dev)}`,
    dev.fold ? `foldable fold-${dev.fold.style || 'wide'} ${isOpen(dev) ? 'unfolded' : 'folded'}` : '',
    S.statusBar ? 'show-status' : '',
    S.browserBar && S.display === 'browser' ? 'show-browser' : '',
    kind === 'responsive' ? '' : `mode-${S.display}`,
    S.glare && S.frame ? 'show-glare' : ''
  ].filter(Boolean).join(' ');

  v.titleEl.textContent = displayName(dev);
  const dot = v.slot.querySelector('.finish-dot');
  if (dot) {
    const f = FINISHES.find((x) => x[0] === finishOf(dev));
    dot.style.background = f ? f[1] : '#888';
    dot.title = `Color: ${f ? f[2] : finishOf(dev)} (click to change)`;
  }
  const r = kind === 'desktop' ? 4 : screenOf(dev).radius;
  device.style.setProperty('--r', `${r}px`);
  screen.style.width = `${w}px`;
  screen.style.height = `${h}px`;

  let bx = 0, by = 0, extra = 0;
  if (kind === 'responsive') { extra = 28; }
  else if (S.frame) {
    if (dev.notch === 'home') { bx = land ? 72 : 14; by = land ? 14 : 72; }
    else if (kind === 'tablet') { bx = by = 18; }
    else if (kind === 'desktop') { bx = by = 14; extra = 16; }
    else bx = by = foldBezel(dev) || 12;
  }
  const folded = dev.fold && !isOpen(dev);
  const fb = foldBezel(dev);
  if (S.frame && fb) device.style.setProperty('--bezel', `${fb}px`);
  else device.style.removeProperty('--bezel');
  if (folded && dev.fold.coverCorner != null) device.style.setProperty('--rl', `${dev.fold.coverCorner}px`);
  else device.style.removeProperty('--rl');
  if (S.frame && dev.fold && isOpen(dev) && dev.fold.openCorner != null) device.style.setProperty('--rad', `${dev.fold.openCorner}px`);
  else device.style.removeProperty('--rad');
  v.outerW = w + bx * 2;
  v.outerH = h + by * 2 + extra;
  v.hosts.forEach((n) => { n.textContent = hostOf(v.url); });

  if (kind === 'responsive') {
    renderRuler(v);
    const bp = activeBreakpoint(w);
    v.bpEl.textContent = bp ? bp.n : 'xs';
  } else {
    v.bpEl.textContent = '';
  }
  paintStatus(v);

  v.dimsEl.textContent = `${w} × ${h}`;
  requestAnimationFrame(() => {
    v.dimsEl.title = `Web viewport: ${v.viewportEl.clientWidth} × ${v.viewportEl.clientHeight} px, pixel ratio ${dev.dpr}`;
  });
}

function finishOf(dev) {
  const own = S.devFinish[dev.id];
  if (own && (!dev.colors || dev.colors.includes(own))) return own;
  if (dev.colors && !dev.colors.includes(S.finish)) return dev.colors[0];
  return S.finish;
}

function foldBezel(dev) {
  if (!dev.fold) return 0;
  return (isOpen(dev) ? dev.fold.openBezel : dev.fold.coverBezel) || 0;
}

// ---------- layout and scaling ----------
function mockSize() {
  if (!S.mock.on || S.mock.size === 'free') return null;
  const [w, h] = S.mock.size.split('x').map(Number);
  return { w, h };
}
let currentMockFit = 1;
function mockFit() { return mockSize() ? currentMockFit : 1; }
function headlineHeight() {
  if (!S.mock.on || !S.mock.headline) return 0;
  return $('#mockText').offsetHeight + 48;
}

function computeScale() {
  const list = [...views.values()];
  if (!list.length) return 1;
  const gap = S.mock.on ? 48 : GAP;
  const gaps = gap * (list.length - 1);
  const totalW = list.reduce((sum, v) => sum + v.outerW, 0);
  const maxH = Math.max(...list.map((v) => v.outerH));
  const m = mockSize();
  if (m) {
    const pad = S.mock.pad;
    const availW = m.w - pad * 2 - 40;
    const availH = m.h - pad * 2 - headlineHeight() - 30;
    return clamp(Math.min(availH / maxH, (availW - gaps) / totalW), 0.08, 2.5);
  }
  if (S.zoom !== 'fit') return Number(S.zoom) || 1;
  const stage = $('#stage');
  let availH = stage.clientHeight - 22 - 40 - 36;
  let availW = stage.clientWidth - reserveW - 56;
  if (S.mock.on) {
    availH = stage.clientHeight - 56 - S.mock.pad * 2 - headlineHeight();
    availW = stage.clientWidth - reserveW - 12 - S.mock.pad * 2;
  }
  let s = Math.min(...list.map((v) => availH / v.outerH));
  if (totalW * s + gaps > availW) s = Math.max(Math.min(s, (availW - gaps) / totalW), 0.22);
  return Math.min(1, s);
}

function relayout() {
  layoutMock(false);
  const s = resizing ? lastScale : computeScale();
  lastScale = s;
  for (const v of views.values()) {
    v.scaler.style.width = `${Math.round(v.outerW * s)}px`;
    v.scaler.style.height = `${Math.round(v.outerH * s)}px`;
    v.device.style.transform = `scale(${s})`;
    v.device.style.setProperty('--inv', String(1 / s));
    v.scale = s;
  }
  layoutMock(true);
}

function resolveBackground() {
  const k = S.mock.bg;
  if (k === 'custom') {
    const c = hexToRgb(S.mock.color);
    return { css: S.mock.color, ink: luminance(c) > 0.45 ? '#141414' : '#fff' };
  }
  if (k === 'ambient') return ambientBackground();
  const b = BACKGROUNDS.find((x) => x.id === k) || BACKGROUNDS[1];
  return { css: b.css, ink: b.ink };
}

function ambientBackground() {
  const p = ambientPalette || { avg: { r: 40, g: 50, b: 90 }, colors: [hexToRgb('#5b8cff'), hexToRgb('#7c5cff'), hexToRgb('#ff6ec4')] };
  const vivid = (c) => {
    const max = Math.max(c.r, c.g, c.b), min = Math.min(c.r, c.g, c.b);
    return max - min < 25 ? mix(c, { r: 91, g: 140, b: 255 }, 0.35) : c;
  };
  const [a, b, c] = p.colors.map(vivid);
  const base = mix(p.avg, { r: 8, g: 10, b: 16 }, 0.62);
  return {
    css: `radial-gradient(at 15% 18%, ${toHex(a)} 0, transparent 55%), radial-gradient(at 85% 25%, ${toHex(b)} 0, transparent 52%), radial-gradient(at 55% 95%, ${toHex(c)} 0, transparent 60%), ${toHex(base)}`,
    ink: '#fff'
  };
}

function layoutMock(afterScale) {
  const body = document.body;
  const devicesEl = $('#devices');
  const scalerEl = $('#mockScaler');
  const m = mockSize();
  body.classList.toggle('mock-on', S.mock.on);
  body.classList.toggle('mock-fixed', !!m);
  body.classList.toggle('mock-headline', S.mock.on && S.mock.headline);
  devicesEl.classList.remove('shadow-none', 'shadow-soft', 'shadow-strong', 'tilt-left', 'tilt-right', 'tilt-none');
  devicesEl.classList.add(`shadow-${S.mock.on ? S.mock.shadow : 'soft'}`);
  if (S.mock.on) devicesEl.classList.add(`tilt-${S.mock.tilt}`);
  $('#mockBtn').classList.toggle('on', S.mock.on);
  renderSide();

  if (!S.mock.on) {
    scalerEl.removeAttribute('style');
    devicesEl.style.transform = '';
    devicesEl.style.removeProperty('--mock-bg');
    return;
  }
  const bg = resolveBackground();
  devicesEl.style.setProperty('--mock-bg', bg.css);
  devicesEl.style.setProperty('--mock-ink', bg.ink);
  devicesEl.style.setProperty('--mock-pad', `${S.mock.pad}px`);
  devicesEl.style.setProperty('--mock-h1', `${m ? Math.round(Math.min(m.w * 0.056, m.h * 0.066)) : 44}px`);
  devicesEl.style.setProperty('--mock-p', `${m ? Math.round(Math.min(m.w * 0.024, m.h * 0.03)) : 19}px`);

  if (!m) {
    scalerEl.removeAttribute('style');
    devicesEl.style.transform = '';
    return;
  }
  devicesEl.style.setProperty('--mock-w', `${m.w}px`);
  devicesEl.style.setProperty('--mock-h', `${m.h}px`);
  if (!afterScale) return;
  const full = body.classList.contains('capture-full');
  const stage = $('#stage');
  const availW = full ? window.innerWidth : stage.clientWidth - reserveW - 32;
  const availH = full ? window.innerHeight : stage.clientHeight - 48;
  const fit = Math.min(availW / m.w, availH / m.h, full ? 4 : 1);
  currentMockFit = fit;
  scalerEl.style.width = `${Math.floor(m.w * fit)}px`;
  scalerEl.style.height = `${Math.floor(m.h * fit)}px`;
  scalerEl.style.marginTop = full ? '0px' : `${Math.max(24, (stage.clientHeight - m.h * fit) / 2)}px`;
  scalerEl.style.marginLeft = full ? '0px' : `${Math.max(20, (stage.clientWidth - reserveW - m.w * fit) / 2)}px`;
  devicesEl.style.transform = `scale(${fit})`;
}

// ---------- views lifecycle ----------
async function syncViews() {
  const ua = primaryUA();
  const uaChanged = await register(ua);
  const container = $('#devices');

  for (const [id, v] of views) {
    if (!S.selected.includes(id)) { v.slot.remove(); views.delete(id); touches.delete(id); }
  }
  for (const id of S.selected) {
    if (views.has(id)) continue;
    const dev = byId(id);
    if (!dev) continue;
    const v = createView(dev);
    views.set(id, v);
    container.appendChild(v.slot);
    if (currentUrl) loadView(v, currentUrl);
  }
  if (uaChanged && currentUrl) {
    for (const v of views.values()) if (v.url) loadView(v, v.url);
  }
  $('#deviceCount').textContent = String(views.size);
  renderDeviceList();
  relayout();
  scheduleAmbient(1200);
}

function loadView(v, url) {
  v.url = url;
  v.reported = null;
  v.commandedAt = Date.now();
  v.viewportEl.classList.remove('loaded');
  v.hosts.forEach((n) => { n.textContent = hostOf(url); });
  if (hostOf(url) !== hostOf(v.appHost || '')) v.app = null;
  v.appHost = url;
  showSplash(v);
  let host = '';
  try { host = new URL(url).hostname; } catch (e) { /* ignore */ }
  if (containHosts.has(host)) v.iframe.setAttribute('sandbox', CONTAIN_SANDBOX);
  else v.iframe.removeAttribute('sandbox');
  reportHosts(true);
  v.iframe.src = url;
}

function navigateAll(url) {
  currentUrl = url;
  $('#urlInput').value = url;
  history.replaceState(null, '', `?url=${encodeURIComponent(url)}`);
  document.title = `PocketView | ${hostOf(url)}`;
  $('#empty').hidden = true;
  $('#mockScaler').hidden = false;
  for (const v of views.values()) loadView(v, url);
  relayout();
}

let hostsTimer;
function reportHosts(now) {
  clearTimeout(hostsTimer);
  const send = () => {
    const hosts = new Set();
    for (const v of views.values()) { try { hosts.add(new URL(v.url).hostname); } catch (e) { /* ignore */ } }
    chrome.runtime.sendMessage({ type: 'pv:bg:hosts', hosts: [...hosts] }).catch(() => {});
  };
  if (now) send(); else hostsTimer = setTimeout(send, 200);
}

function reloadAll() { for (const v of views.values()) if (v.url) loadView(v, v.url); }

function pushFrameStyles() {
  for (const v of views.values()) sendStyle(v);
}
function sendStyle(v) {
  broadcast(Object.assign({ type: 'pv:sim:style', views: [v.dev.id] }, frameOptions(v.dev)));
}

// ---------- messages from device frames ----------
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || !sender.tab || sender.tab.id !== tabId) return;
  const v = views.get(msg.view);
  if (!v) return;

  if (msg.type === 'pv:frame:nav') {
    const first = v.reported == null;
    v.reported = msg.url;
    v.url = msg.url;
    sendStyle(v);
    reportHosts();
    v.hosts.forEach((n) => { n.textContent = hostOf(msg.url); });
    const lead = views.values().next().value;
    if (v === lead) {
      currentUrl = msg.url;
      if (document.activeElement !== $('#urlInput')) $('#urlInput').value = msg.url;
      history.replaceState(null, '', `?url=${encodeURIComponent(msg.url)}`);
      document.title = `PocketView | ${msg.title || hostOf(msg.url)}`;
    }
    const settled = Date.now() - v.commandedAt > 2000;
    if (S.sync && !first && settled && views.size > 1) {
      for (const w of views.values()) if (w !== v && w.url !== msg.url) loadView(w, msg.url);
      currentUrl = msg.url;
    }
    scheduleAmbient(900);
  } else if (msg.type === 'pv:frame:loaded') {
    hideSplash(v);
    scheduleAmbient(500);
  } else if (msg.type === 'pv:frame:app') {
    v.app = { name: msg.name, themeColor: msg.themeColor, bgColor: msg.bgColor, icon: msg.icon };
    if (v.splash.classList.contains('show')) renderSplash(v);
    paintStatus(v);
  } else if (msg.type === 'pv:frame:scroll') {
    if (!msg.echo && S.sync && views.size > 1) broadcast({ type: 'pv:sim:scroll', from: msg.view, x: msg.x, y: msg.y });
    scheduleAmbient(450);
  } else if (msg.type === 'pv:frame:input') {
    if (S.sync && S.formSync && isPro(LIC) && views.size > 1) {
      const { path, tag, kind, name, nth } = msg;
      const out = { type: 'pv:sim:input', from: msg.view, path, tag, kind, name, nth };
      if ('checked' in msg) out.checked = !!msg.checked; else out.value = String(msg.value ?? '');
      broadcast(out);
    }
  } else if (msg.type === 'pv:frame:pointer') {
    const r = v.iframe.getBoundingClientRect();
    const sx = r.width / Math.max(1, v.iframe.clientWidth);
    const sy = r.height / Math.max(1, v.iframe.clientHeight);
    const t = touches.get(msg.view) || {};
    t.x = r.left + msg.x * sx;
    t.y = r.top + msg.y * sy;
    if (msg.kind === 'down') { t.down = true; t.downAt = performance.now(); }
    else if (msg.kind === 'up') t.down = false;
    else t.down = !!msg.down;
    touches.set(msg.view, t);
  }
});

// ---------- ambient light ----------
let ambTimer = 0;
let ambBusy = false;
let lastAmb = 0;
function ambientWanted() { return S.ambient || (S.mock.on && S.mock.bg === 'ambient'); }
function scheduleAmbient(ms = 600) {
  if (!ambientWanted()) return;
  clearTimeout(ambTimer);
  ambTimer = setTimeout(runAmbient, ms);
}
function anyPopoverOpen() { return [...document.querySelectorAll('.popover')].some((p) => !p.hidden); }

async function runAmbient() {
  if (ambBusy || recorder || capturing || resizing || !currentUrl || !views.size) return;
  if (anyPopoverOpen()) { scheduleAmbient(1200); return; }
  const since = Date.now() - lastAmb;
  if (since < 700) { scheduleAmbient(700 - since); return; }
  ambBusy = true;
  lastAmb = Date.now();
  try {
    const img = await captureTab('jpeg');
    if (!img) return;
    const k = img.naturalWidth / window.innerWidth;
    let first = null;
    for (const v of views.values()) {
      const r = v.viewportEl.getBoundingClientRect();
      const x = Math.max(0, r.left), y = Math.max(0, r.top);
      const w = Math.min(window.innerWidth, r.right) - x;
      const h = Math.min(window.innerHeight, r.bottom) - y;
      if (w < 8 || h < 8) continue;
      const res = sample(img, { x, y, w, h }, k);
      v.glow.style.backgroundImage = `url(${res.url})`;
      v.glow.classList.add('ready');
      const top = sample(img, { x, y, w, h: Math.max(2, Math.min(6 * v.scale, h)) }, k);
      v.topColor = top.avg;
      paintStatus(v);
      if (!first) first = res;
    }
    if (first) {
      ambientPalette = first;
      const c = first.colors[0];
      document.documentElement.style.setProperty('--amb', `${c.r | 0}, ${c.g | 0}, ${c.b | 0}`);
      if (S.mock.on && S.mock.bg === 'ambient') layoutMock(true);
      renderSwatches();
    }
  } finally {
    ambBusy = false;
  }
}
setInterval(() => { if (ambientWanted() && document.visibilityState === 'visible') scheduleAmbient(0); }, 4000);

// ---------- device picker ----------
function renderPresets() {
  const box = $('#presets');
  box.innerHTML = '';
  for (const p of PRESETS) {
    const c = el('button', 'chip');
    c.type = 'button';
    c.textContent = p.name;
    c.addEventListener('click', () => {
      S.selected = p.ids.filter((id) => byId(id)).slice(0, MAX_VIEWS);
      saveSettings();
      syncViews();
    });
    box.appendChild(c);
  }
}

const TABS = [
  ['all', 'All'], ['Foldable', 'Foldable'], ['iPhone', 'iPhone'], ['Android', 'Android'],
  ['Tablet', 'Tablet'], ['Desktop', 'Desktop'], ['Custom', 'Custom']
];
let pickerTab = 'all';
const NEW_IDS = new Set(['iphone-duo', 'galaxy-z-fold8', 'galaxy-z-fold8-ultra', 'xiaomi-18-fold', 'galaxy-z-flip8', 'iphone-18-pro-max', 'iphone-18-pro', 'iphone-17-pro-max', 'iphone-17-pro', 'iphone-air', 'iphone-17', 'galaxy-s26-ultra', 'pixel-11-pro-xl', 'pixel-11-pro', 'pixel-10-pro', 'pixel-10', 'pixel-10-pro-fold', 'xiaomi-17-ultra', 'xiaomi-17t-pro', 'xiaomi-17t', 'xiaomi-17', 'redmi-note-17', 'moto-razr-70-ultra', 'moto-g87', 'infinix-hot-70', 'galaxy-a17']);

function silhouette(w, h, cls, H = 60, maxW = 104) {
  let sh = H, sw = Math.round(H * w / h);
  if (sw > maxW) { sw = maxW; sh = Math.round(maxW * h / w); }
  sw = Math.max(sw, 20);
  const s = el('span', `sil ${cls || ''}`);
  s.style.width = `${sw}px`;
  s.style.height = `${sh}px`;
  s.style.borderRadius = cls && cls.includes('desk') ? '4px' : `${Math.max(4, Math.round(sw * 0.16))}px`;
  return s;
}

function toggleDevice(id) {
  if (S.selected.includes(id)) {
    if (S.selected.length <= 1) { toast('Keep at least one device.'); return; }
    S.selected = S.selected.filter((x) => x !== id);
  } else {
    if (S.selected.length >= MAX_VIEWS) { hitDeviceLimit(); return; }
    S.selected.push(id);
  }
  saveSettings();
  syncViews();
}

function flashTray() {
  const t = $('.dp-tray');
  if (!t) return;
  t.classList.remove('flash');
  void t.offsetWidth;
  t.classList.add('flash');
}

function renderTray() {
  const tray = $('#tray');
  if (!tray) return;
  tray.innerHTML = '';
  $('#trayCount').textContent = `${S.selected.length}/${MAX_VIEWS}`;
  for (const id of S.selected) {
    const d = byId(id);
    if (!d) continue;
    const c = el('span', 'tchip');
    c.append(document.createTextNode(d.name));
    const x = el('button', '', '✕');
    x.type = 'button';
    x.title = `Remove ${d.name}`;
    x.addEventListener('click', () => toggleDevice(id));
    c.appendChild(x);
    tray.appendChild(c);
  }
}

function renderTabs(list) {
  const box = $('#deviceTabs');
  box.innerHTML = '';
  for (const [id, label] of TABS) {
    const n = id === 'all' ? list.length : list.filter((d) => d.group === id).length;
    if (id === 'Custom' && !n) continue;
    const b = el('button', `dp-tab${pickerTab === id ? ' on' : ''}`, `${label}<small>${n}</small>`);
    b.type = 'button';
    b.addEventListener('click', () => { pickerTab = id; renderDeviceList(); });
    box.appendChild(b);
  }
}

function renderDeviceList() {
  renderTray();
  const q = ($('#deviceSearch').value || '').toLowerCase().trim();
  const all = allDevices();
  renderTabs(all);
  const box = $('#deviceList');
  box.innerHTML = '';
  const order = ['Responsive', 'Foldable', 'iPhone', 'Android', 'Tablet', 'Desktop', 'Custom'];
  const list = all
    .filter((d) => pickerTab === 'all' || d.group === pickerTab)
    .filter((d) => !q || d.name.toLowerCase().includes(q) || d.group.toLowerCase().includes(q) || `${d.w}x${d.h}`.includes(q) || String(d.w).startsWith(q))
    .sort((a, b) => order.indexOf(a.group) - order.indexOf(b.group));
  if (!list.length) { box.appendChild(el('div', 'dp-empty', 'No device matches. Add a custom size below.')); return; }

  for (const d of list) {
    const on = S.selected.includes(d.id);
    const card = el('div', `dcard${on ? ' on' : ''}`);
    card.tabIndex = 0;
    card.setAttribute('role', 'button');
    card.setAttribute('aria-pressed', String(on));
    const wrap = el('div', 'sil-wrap');
    const kind = kindOf(d);
    if (isResp(d)) wrap.appendChild(silhouette(58, 60, 'resp'));
    else if (kind === 'desktop') wrap.appendChild(silhouette(d.w, d.h, 'desk'));
    else {
      const notch = d.notch === 'home' ? 'home' : d.notch === 'punch' ? 'punch' : (d.notch === 'island' || d.notch === 'notch') ? 'island' : '';
      // Foldables show cover and inner screen side by side, so draw both a bit smaller.
      wrap.appendChild(d.fold ? silhouette(d.w, d.h, notch, 50, 36) : silhouette(d.w, d.h, notch));
      if (d.fold) wrap.appendChild(silhouette(d.fold.w, d.fold.h, 'open', 50, 64));
    }
    card.appendChild(wrap);
    const nm = el('div', 'nm');
    nm.textContent = d.name;
    const dm = el('div', 'dm', isResp(d) ? 'any size, drag edges' : d.fold ? `${d.w}×${d.h} · open ${d.fold.w}×${d.fold.h}` : `${d.w} × ${d.h}`);
    card.append(nm, dm, el('span', 'check', '✓'));
    if (NEW_IDS.has(d.id)) card.appendChild(el('span', 'badge', 'New'));
    if (d.custom) {
      const del = el('button', 'del', '✕');
      del.type = 'button';
      del.title = 'Delete custom device';
      del.addEventListener('click', (e) => {
        e.stopPropagation();
        S.custom = S.custom.filter((c) => c.id !== d.id);
        S.selected = S.selected.filter((id) => id !== d.id);
        if (!S.selected.length) S.selected = [...DEFAULTS.selected];
        saveSettings();
        syncViews();
      });
      card.appendChild(del);
    }
    card.addEventListener('click', () => toggleDevice(d.id));
    card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleDevice(d.id); } });
    box.appendChild(card);
  }
}

$('#customForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const f = new FormData(e.target);
  const w = Math.round(Number(f.get('w')));
  const h = Math.round(Number(f.get('h')));
  if (!(w >= 200 && h >= 200)) { toast('Width and height must be at least 200 px.'); return; }
  const c = { id: `custom-${Date.now()}`, name: String(f.get('name')).trim().slice(0, 40), w, h, os: String(f.get('os')) };
  S.custom.push(c);
  if (S.selected.length < MAX_VIEWS) S.selected.push(c.id);
  else toast(`Saved ${c.name}. ${limitMsg()}`, 4000);
  saveSettings();
  e.target.reset();
  syncViews();
  if (S.selected.includes(c.id)) toast(`Saved ${c.name}.`);
});

// ---------- popovers ----------
function togglePop(id) {
  const pop = $(id);
  const show = pop.hidden;
  closePops();
  pop.hidden = !show;
}
function closePops() { document.querySelectorAll('.popover').forEach((p) => { p.hidden = true; }); }

// ---------- side panels (slide in from the right, like Mockup studio) ----------

function sideWidth() {
  const body = document.body;
  if (body.classList.contains('capture-full')) return 0;
  const el = sidePanel ? $(SIDE[sidePanel]) : (S.mock.on ? $('#mockPanel') : null);
  if (!el) return 0;
  const w = el.offsetWidth + 28;
  // Narrow windows: the panel floats over the devices instead of pushing them.
  return window.innerWidth - w < 480 ? 0 : w;
}

function renderSide() {
  const full = document.body.classList.contains('capture-full');
  for (const [k, sel] of Object.entries(SIDE)) {
    const open = sidePanel === k && !full;
    $(sel).classList.toggle('open', open);
    $(sel).inert = !open;
  }
  const mockOpen = S.mock.on && !sidePanel && !full;
  $('#mockPanel').classList.toggle('open', mockOpen);
  $('#mockPanel').inert = !mockOpen;
  $('#devicesBtn').classList.toggle('on', sidePanel === 'devices');
  $('#viewBtn').classList.toggle('on', sidePanel === 'view');
  $('#devicesBtn').setAttribute('aria-expanded', String(sidePanel === 'devices'));
  $('#viewBtn').setAttribute('aria-expanded', String(sidePanel === 'view'));
  reserveW = sideWidth();
  $('#stage').style.setProperty('--reserve', `${reserveW}px`);
}

function setSide(name) {
  sidePanel = name && sidePanel !== name ? name : null;
  closePops();
  relayout();
  if (sidePanel === 'devices') setTimeout(() => $('#deviceSearch').focus({ preventScroll: true }), 60);
  scheduleAmbient(500);
}

$('#devicesBtn').addEventListener('click', (e) => { e.stopPropagation(); setSide('devices'); });
$('#viewBtn').addEventListener('click', (e) => { e.stopPropagation(); setSide('view'); });
document.querySelectorAll('[data-close-side]').forEach((b) => b.addEventListener('click', () => setSide(null)));
$('#recBtn').addEventListener('click', (e) => { e.stopPropagation(); togglePop('#recPop'); });
document.querySelectorAll('.popover').forEach((p) => p.addEventListener('click', (e) => e.stopPropagation()));
document.addEventListener('click', closePops);
$('#deviceSearch').addEventListener('input', renderDeviceList);

// ---------- view options ----------
const MODE_HINTS = {
  browser: 'Normal website in Safari or Chrome, with optional browser bar.',
  app: 'As if the site was added to the home screen: no browser bar, status bar uses the site theme color, display-mode: standalone is on.',
  immersive: 'Edge to edge fullscreen app: content runs under the status bar and notch, display-mode: fullscreen is on.'
};
function renderToggles() {
  document.querySelectorAll('[data-setting]').forEach((cb) => {
    let val = !!S[cb.dataset.setting];
    if (cb.dataset.setting === 'formSync') val = val && isPro(LIC);
    cb.checked = cb.dataset.invert ? !val : val;
  });
  document.querySelectorAll('.pro-tag').forEach((t) => { t.hidden = isPro(LIC); });
  document.body.classList.toggle('ambient-on', !!S.ambient);
  document.querySelectorAll('#modeSeg button').forEach((b) => b.classList.toggle('on', b.dataset.mode === S.display));
  $('#modeHint').textContent = MODE_HINTS[S.display] || '';
  $('#browserTile').classList.toggle('disabled', S.display !== 'browser');
  $('#splashTile').classList.toggle('disabled', S.display === 'browser');
  renderFinishes();
}
function renderFinishes() {
  const row = $('#finishRow');
  row.innerHTML = '';
  for (const [id, color, label] of FINISHES) {
    const b = el('button', `finish${S.finish === id ? ' on' : ''}`);
    b.type = 'button';
    b.title = `${label} frame`;
    b.style.background = color;
    b.addEventListener('click', () => {
      S.finish = id;
      S.devFinish = {};
      if (!S.frame) S.frame = true;
      saveSettings();
      renderToggles();
      for (const v of views.values()) applyLayout(v);
      relayout();
    });
    row.appendChild(b);
  }
}

document.querySelectorAll('[data-setting]').forEach((cb) => {
  cb.addEventListener('change', () => {
    const key = cb.dataset.setting;
    if (key === 'formSync' && cb.checked && !isPro(LIC)) {
      cb.checked = false;
      openAccount({ reason: 'Form sync is part of Pro. Type in one device and every other device fills in the same field.' });
      return;
    }
    S[key] = cb.dataset.invert ? !cb.checked : cb.checked;
    renderToggles();
    saveSettings();
    if (key === 'touchCursor' || key === 'hideScrollbars' || key === 'dragScroll' || key === 'formSync') pushFrameStyles();
    if (key === 'darkScheme') {
      rebuildAll();
      toast(S.darkScheme ? 'Dark mode forced. Works on sites that support prefers-color-scheme.' : 'Dark mode off.');
    }
    if (key === 'ambient') {
      document.body.classList.toggle('ambient-on', S.ambient);
      if (S.ambient) scheduleAmbient(0);
    }
    for (const v of views.values()) applyLayout(v);
    relayout();
  });
});

document.querySelectorAll('#modeSeg button').forEach((b) => b.addEventListener('click', () => {
  if (S.display === b.dataset.mode) return;
  S.display = b.dataset.mode;
  saveSettings();
  renderToggles();
  for (const v of views.values()) applyLayout(v);
  relayout();
  rebuildAll();
}));

$('#zoomSelect').addEventListener('change', (e) => {
  S.zoom = e.target.value;
  saveSettings();
  relayout();
  scheduleAmbient(600);
});

function toggleFold(v) {
  S.open[v.dev.id] = !isOpen(v.dev);
  saveSettings();
  applyLayout(v);
  relayout();
  scheduleAmbient(700);
}
function foldAll() {
  const folds = [...views.values()].filter((v) => v.dev.fold);
  if (!folds.length) { toast('No foldable on screen. Try the Foldables preset.'); return; }
  const anyClosed = folds.some((v) => !isOpen(v.dev));
  for (const v of folds) { S.open[v.dev.id] = anyClosed; applyLayout(v); }
  saveSettings();
  relayout();
  scheduleAmbient(700);
}
function rotateAll() {
  const ids = [...views.keys()].filter((id) => id !== 'responsive');
  const anyPortrait = ids.some((id) => orientation(id) === 'portrait');
  for (const id of ids) S.orient[id] = anyPortrait ? 'landscape' : 'portrait';
  saveSettings();
  for (const v of views.values()) applyLayout(v);
  relayout();
  scheduleAmbient(700);
}
$('#rotateAllBtn').addEventListener('click', rotateAll);

// ---------- share setup link ----------
function setupLink() {
  const u = new URL(chrome.runtime.getURL('simulator.html'));
  if (currentUrl) u.searchParams.set('url', currentUrl);
  u.searchParams.set('devices', S.selected.join(','));
  const land = S.selected.filter((id) => orientation(id) === 'landscape');
  if (land.length) u.searchParams.set('landscape', land.join(','));
  const open = S.selected.filter((id) => byId(id) && isOpen(byId(id)));
  if (open.length) u.searchParams.set('open', open.join(','));
  if (S.selected.includes('responsive')) u.searchParams.set('size', `${S.resp.w}x${S.resp.h}`);
  if (S.darkScheme) u.searchParams.set('dark', '1');
  if (S.display !== 'browser') u.searchParams.set('mode', S.display);
  return u.href;
}
$('#shareBtn').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(setupLink());
    toast('Setup link copied. It opens this exact setup for anyone with PocketView installed.', 3800);
  } catch (e) {
    toast('Could not copy the link.');
  }
  closePops();
});

function applyLinkParams(params) {
  const devs = (params.get('devices') || '').split(',').filter((id) => byId(id)).slice(0, MAX_VIEWS);
  if (!devs.length) return;
  S.selected = devs;
  for (const id of (params.get('landscape') || '').split(',')) if (byId(id)) S.orient[id] = 'landscape';
  for (const id of devs) if (!(params.get('landscape') || '').split(',').includes(id)) S.orient[id] = 'portrait';
  S.open = {};
  for (const id of (params.get('open') || '').split(',')) if (byId(id)) S.open[id] = true;
  const size = /^(\d+)x(\d+)$/.exec(params.get('size') || '');
  if (size) S.resp = { w: clamp(+size[1], 240, 2560), h: clamp(+size[2], 240, 2560) };
  if (params.has('dark')) S.darkScheme = params.get('dark') === '1';
  if (['browser', 'app', 'immersive'].includes(params.get('mode'))) S.display = params.get('mode');
  saveSettings();
}

// ---------- mockup studio ----------
function renderSwatches() {
  const box = $('#swatches');
  if (!box) return;
  box.innerHTML = '';
  for (const b of BACKGROUNDS) {
    const s = el('button', `swatch${b.id === 'ambient' ? ' ambient' : ''}${S.mock.bg === b.id ? ' on' : ''}`);
    s.type = 'button';
    s.title = b.name || b.id;
    s.style.background = b.id === 'ambient' ? ambientBackground().css : b.css;
    s.addEventListener('click', () => {
      S.mock.bg = b.id;
      saveSettings();
      renderSwatches();
      relayout();
      if (b.id === 'ambient') scheduleAmbient(0);
    });
    box.appendChild(s);
  }
}

function renderMockPanel() {
  renderSwatches();
  $('#mockColor').value = S.mock.color;
  $('#mockSize').value = S.mock.size;
  $('#mockHeadline').checked = S.mock.headline;
  $('#mockPad').value = S.mock.pad;
  $('#mockPadVal').textContent = `${S.mock.pad}px`;
  document.querySelectorAll('#mockTilt button').forEach((b) => b.classList.toggle('on', b.dataset.v === S.mock.tilt));
  document.querySelectorAll('#mockShadow button').forEach((b) => b.classList.toggle('on', b.dataset.v === S.mock.shadow));
}

function setMock(on) {
  S.mock.on = on;
  if (on) sidePanel = null;
  saveSettings();
  closePops();
  renderMockPanel();
  relayout();
  scheduleAmbient(400);
}
$('#mockBtn').addEventListener('click', () => setMock(!S.mock.on));
$('#mockClose').addEventListener('click', () => setMock(false));
$('#mockColor').addEventListener('input', (e) => {
  S.mock.color = e.target.value;
  S.mock.bg = 'custom';
  saveSettings();
  renderSwatches();
  relayout();
});
$('#mockSize').addEventListener('change', (e) => { S.mock.size = e.target.value; saveSettings(); relayout(); });
$('#mockHeadline').addEventListener('change', (e) => { S.mock.headline = e.target.checked; saveSettings(); relayout(); });
$('#mockPad').addEventListener('input', (e) => {
  S.mock.pad = Number(e.target.value);
  $('#mockPadVal').textContent = `${S.mock.pad}px`;
  saveSettings();
  relayout();
});
document.querySelectorAll('#mockTilt button').forEach((b) => b.addEventListener('click', () => {
  S.mock.tilt = b.dataset.v; saveSettings(); renderMockPanel(); relayout();
}));
document.querySelectorAll('#mockShadow button').forEach((b) => b.addEventListener('click', () => {
  S.mock.shadow = b.dataset.v; saveSettings(); renderMockPanel(); relayout();
}));
let textTimer;
for (const [id, key] of [['#mockTitle', 'title'], ['#mockSub', 'sub']]) {
  $(id).addEventListener('input', (e) => {
    S.mock[key] = e.target.textContent;
    saveSettings();
    clearTimeout(textTimer);
    textTimer = setTimeout(relayout, 250);
  });
}

// ---------- navigation ----------
function submitUrl(value) {
  const url = normalizeUrl(value);
  if (url === null) { toast('Only http and https pages can be simulated.'); return; }
  if (!url) return;
  navigateAll(url);
}
$('#urlForm').addEventListener('submit', (e) => { e.preventDefault(); submitUrl($('#urlInput').value); $('#urlInput').blur(); });
$('#emptyForm').addEventListener('submit', (e) => { e.preventDefault(); submitUrl($('#emptyInput').value); });
$('#reloadBtn').addEventListener('click', reloadAll);
$('#exitBtn').addEventListener('click', async () => {
  if (recorder) await stopRecording();
  await chrome.runtime.sendMessage({ type: 'pv:bg:exit' }).catch(() => {});
  if (currentUrl) location.href = currentUrl;
  else history.back();
});

// ---------- screenshot ----------
function allVisible() {
  const vw = window.innerWidth, vh = window.innerHeight;
  return [...views.values()].every((v) => {
    const r = v.device.getBoundingClientRect();
    return r.left >= 0 && r.top >= 0 && r.right <= vw && r.bottom + 20 <= vh;
  });
}

async function enterCapture(full) {
  capturing = true;
  closePops();
  document.body.classList.add('capturing', 'no-anim');
  if (full) document.body.classList.add('capture-full');
  relayout();
  await nextFrame();
}
function exitCapture() {
  document.body.classList.remove('capturing', 'capture-full', 'no-anim');
  capturing = false;
  relayout();
}

async function screenshot() {
  if (!currentUrl) { toast('Load a website first.'); return; }
  if (recorder) { toast('Stop the recording first.'); return; }
  const mock = S.mock.on;
  const prevZoom = S.zoom;
  let switched = false;
  let blob;
  try {
    await enterCapture(mock);
    if (!mock && !allVisible()) { S.zoom = 'fit'; switched = true; relayout(); await nextFrame(); }
    await sleep(80);
    blob = mock ? await captureMockup() : await captureDevices();
  } catch (e) {
    toast('Screenshot failed: ' + (e.message || e));
    return;
  } finally {
    if (switched) S.zoom = prevZoom;
    exitCapture();
  }
  if (!blob) { toast('Screenshot failed. Keep this tab visible and try again.'); return; }
  download(blob, `${fileBase()}.png`);
  toast('Screenshot saved to your Downloads.');
  noteWin();
}

async function captureMockup() {
  const r = $('#devices').getBoundingClientRect();
  const img = await captureTab('png');
  if (!img) return null;
  const k = img.naturalWidth / window.innerWidth;
  const m = mockSize();
  const canvas = document.createElement('canvas');
  canvas.width = m ? m.w : Math.round(r.width * k);
  canvas.height = m ? m.h : Math.round(r.height * k);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, r.left * k, r.top * k, r.width * k, r.height * k, 0, 0, canvas.width, canvas.height);
  return new Promise((res) => canvas.toBlob(res, 'image/png'));
}

async function captureDevices() {
  const shapes = [];
  for (const v of views.values()) {
    const s = v.scale || 1;
    const plain = isResp(v.dev) || !S.frame;
    const target = plain ? v.screen : v.device;
    const r = target.getBoundingClientRect();
    const ring = plain ? 0 : 3 * s;
    const cs = getComputedStyle(target);
    const radii = ['borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomRightRadius', 'borderBottomLeftRadius']
      .map((k) => (parseFloat(cs[k]) || 0) * s + ring);
    shapes.push({ x: r.left - ring, y: r.top - ring, w: r.width + ring * 2, h: r.height + ring * 2, r: radii });
    const back = v.device.querySelector('.fold-back');
    if (!plain && back && getComputedStyle(back).display !== 'none') {
      const b = back.getBoundingClientRect();
      const bs = getComputedStyle(back);
      shapes.push({ x: b.left, y: b.top, w: b.width, h: b.height, r: ['borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomRightRadius', 'borderBottomLeftRadius'].map((k) => (parseFloat(bs[k]) || 0) * s) });
    }
    const base = v.device.querySelector('.laptop-base');
    if (!plain && base && getComputedStyle(base).display !== 'none') {
      const b = base.getBoundingClientRect();
      shapes.push({ x: b.left, y: b.top, w: b.width, h: b.height, r: [0, 0, 14 * s, 14 * s] });
    }
  }
  const img = await captureTab('png');
  if (!img) return null;
  const transparent = !!S.transparentShot;
  const k = img.naturalWidth / window.innerWidth;
  const pad = transparent ? 0 : 32;
  const ux = Math.max(0, Math.min(...shapes.map((p) => p.x)) - pad);
  const uy = Math.max(0, Math.min(...shapes.map((p) => p.y)) - pad);
  const ur = Math.min(window.innerWidth, Math.max(...shapes.map((p) => p.x + p.w)) + pad);
  const ub = Math.min(window.innerHeight, Math.max(...shapes.map((p) => p.y + p.h)) + pad);

  const canvas = document.createElement('canvas');
  canvas.width = Math.round((ur - ux) * k);
  canvas.height = Math.round((ub - uy) * k);
  const ctx = canvas.getContext('2d');
  const src = [ux * k, uy * k, (ur - ux) * k, (ub - uy) * k];
  if (transparent) {
    for (const p of shapes) {
      ctx.save();
      ctx.beginPath();
      const rad = Array.isArray(p.r) ? p.r.map((n) => n * k) : p.r * k;
      ctx.roundRect((p.x - ux) * k, (p.y - uy) * k, p.w * k, p.h * k, rad);
      ctx.clip();
      ctx.drawImage(img, ...src, 0, 0, canvas.width, canvas.height);
      ctx.restore();
    }
  } else {
    ctx.drawImage(img, ...src, 0, 0, canvas.width, canvas.height);
  }
  return new Promise((res) => canvas.toBlob(res, 'image/png'));
}
$('#shotBtn').addEventListener('click', screenshot);

// ---------- full-page screenshot ----------
// Scrolls each device one screen at a time and stitches the shots into one tall PNG.
const askFrame = (v, msg) => chrome.tabs.sendMessage(tabId, Object.assign({ view: v.dev.id }, msg)).catch(() => null);
const MAX_SHOT_PX = 30000; // keeps the canvas inside Chrome's size limit
let fpRunning = false;
let fpCancel = false;
function fpStatus(text) {
  const n = $('#fpProgress');
  n.hidden = !text;
  if (text) n.querySelector('span').textContent = text;
}
// The status pill must never end up in a shot: hide it for the moment of each capture.
async function captureClean() {
  const n = $('#fpProgress');
  const was = n.hidden;
  n.style.visibility = 'hidden';
  await nextFrame();
  const img = await captureTab('png');
  n.style.visibility = '';
  n.hidden = was;
  return img;
}

async function fullPageShot() {
  if (!currentUrl) { toast('Load a website first.'); return; }
  if (recorder) { toast('Stop the recording first.'); return; }
  if (fpRunning) return;
  fpRunning = true;
  fpCancel = false;
  const wasMock = S.mock.on;
  const prevZoom = S.zoom;
  const files = [];
  const list = [...views.values()];
  let trimmed = false;
  let failed = false;
  let lastShot = 0;
  try {
    if (wasMock) { S.mock.on = false; renderMockPanel(); }
    await enterCapture(true);
    document.body.classList.add('capture-screens', 'capture-clean');
    for (const [n, v] of list.entries()) {
      const who = list.length > 1 ? `${v.dev.name} (${n + 1} of ${list.length})` : v.dev.name;
      fpStatus(`Full-page screenshot: ${who}, loading the page`);
      // Only the page area has to be on screen, so use the largest zoom (up to 100%)
      // that fits the page area in the window. Bigger zoom = sharper result.
      S.zoom = 1;
      relayout();
      await nextFrame();
      const pageH = v.iframe.getBoundingClientRect().height / (v.scale || 1);
      const pageW = v.iframe.getBoundingClientRect().width / (v.scale || 1);
      S.zoom = Math.max(0.2, Math.min(1, (window.innerHeight - 16) / pageH, (window.innerWidth - 16) / pageW));
      relayout();
      await nextFrame();
      v.iframe.scrollIntoView({ block: 'center', inline: 'center' });
      await nextFrame();

      const m = await askFrame(v, { type: 'pv:sim:page:metrics' });
      if (!m || !m.vh) { failed = true; continue; }
      const startY = m.y;
      // Walk the page once so lazy images load before the real pass.
      for (let y = m.vh; y < m.h; y += m.vh) {
        if (fpCancel) throw new Error('cancel');
        await askFrame(v, { type: 'pv:sim:page:scrollTo', y });
        await sleep(70);
      }
      const top = await askFrame(v, { type: 'pv:sim:page:scrollTo', y: 0 });
      await sleep(300);

      const r = v.iframe.getBoundingClientRect();
      let canvas = null, ctx = null, perCss = 1, total = 0, k = 1;
      for (let i = 0, y = 0; ; i++) {
        const at = i === 0 ? top : await askFrame(v, { type: 'pv:sim:page:scrollTo', y, hideFixed: true });
        if (!at) throw new Error('scroll');
        if (fpCancel) throw new Error('cancel');
        const parts = Math.max(1, Math.ceil(Math.min(at.h, MAX_SHOT_PX) / at.vh));
        fpStatus(`Full-page screenshot: ${who}, part ${Math.min(i + 1, parts)} of ${parts}`);
        await sleep(Math.max(0, 520 - (Date.now() - lastShot)));
        const img = await captureClean();
        lastShot = Date.now();
        if (!img) throw new Error('capture');
        if (!canvas) {
          k = img.naturalWidth / window.innerWidth;
          perCss = (r.height * k) / at.vh;
          total = at.h;
          if (total * perCss > MAX_SHOT_PX) { total = Math.floor(MAX_SHOT_PX / perCss); trimmed = true; }
          canvas = document.createElement('canvas');
          canvas.width = Math.round(r.width * k);
          canvas.height = Math.round(total * perCss);
          ctx = canvas.getContext('2d');
          ctx.imageSmoothingQuality = 'high';
        }
        ctx.drawImage(img, r.left * k, r.top * k, r.width * k, r.height * k, 0, Math.round(at.y * perCss), canvas.width, Math.round(r.height * k));
        const next = at.y + at.vh;
        if (next >= total || at.y + 1 < y) break; // reached the end, or the page stopped scrolling
        y = Math.min(next, total - at.vh);
      }
      await askFrame(v, { type: 'pv:sim:page:restore', y: startY });
      const blob = await new Promise((res) => canvas.toBlob(res, 'image/png'));
      if (blob) files.push([blob, `${fileBase()}_${v.dev.id}_full-page.png`]);
    }
  } catch (e) {
    failed = e.message !== 'cancel';
    for (const v of views.values()) askFrame(v, { type: 'pv:sim:page:restore', y: 0 });
  } finally {
    fpRunning = false;
    fpStatus('');
    document.body.classList.remove('capture-screens', 'capture-clean');
    S.zoom = prevZoom;
    if (wasMock) { S.mock.on = true; renderMockPanel(); }
    exitCapture();
  }
  if (fpCancel) { toast('Full-page screenshot cancelled.'); return; }
  for (const [blob, name] of files) { download(blob, name); await sleep(250); }
  if (!files.length) { toast('Full-page screenshot failed. Keep this tab visible and try again.'); return; }
  const note = trimmed ? ' Very long pages are cut at the bottom.' : failed ? ' Some devices could not be captured.' : '';
  toast(`${files.length === 1 ? 'Full-page screenshot' : `${files.length} full-page screenshots`} saved to your Downloads.${note}`, 4200);
  noteWin();
}
$('#shotMore').addEventListener('click', (e) => { e.stopPropagation(); togglePop('#shotPop'); });
$('#shotVisible').addEventListener('click', () => { closePops(); screenshot(); });
$('#shotFull').addEventListener('click', () => { closePops(); fullPageShot(); });

// ---------- open on your phone (QR code) ----------
const LOCAL_HOST = /^(localhost|127\.|0\.0\.0\.0|\[::1\])|\.local$|\.localhost$/i;
function renderQr() {
  const url = $('#qrUrl').value.trim();
  const box = $('#qrCode');
  let host = '';
  try { host = new URL(url).hostname; } catch (e) { /* not a URL yet */ }
  if (!host) { box.innerHTML = ''; $('#qrNote').textContent = 'Type a full address, for example https://example.com'; return; }
  try { box.innerHTML = qrSvg(url, { ecl: 'M', margin: 2, dark: '#0d1016', light: '#ffffff' }); }
  catch (e) { box.innerHTML = ''; $('#qrNote').textContent = 'This address is too long for a QR code.'; return; }
  $('#qrNote').textContent = LOCAL_HOST.test(host)
    ? 'This is a local address, so your phone cannot open it as is. Put your phone on the same Wi-Fi and replace the host with your computer’s network IP, for example 192.168.1.20.'
    : 'Point your phone camera at the code to open this page on a real device.';
}
$('#qrBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  const willOpen = $('#qrPop').hidden;
  togglePop('#qrPop');
  if (!willOpen) return;
  $('#qrUrl').value = currentUrl || $('#urlInput').value || '';
  renderQr();
});
$('#qrUrl').addEventListener('input', renderQr);
$('#qrCopy').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText($('#qrUrl').value.trim()); toast('Link copied.'); } catch (e) { toast('Could not copy the link.'); }
});

// ---------- rating prompt ----------
// Asks once, after a few successful captures, for a Chrome Web Store rating. "Not now" asks again
// at most once, three weeks later.
const REVIEW_URL = 'https://chromewebstore.google.com/detail/hdfdpaakiopndhcdillcikbmddgchako/reviews';
async function noteWin() {
  const { pvRate = {} } = await chrome.storage.local.get('pvRate');
  pvRate.wins = (pvRate.wins || 0) + 1;
  pvRate.first = pvRate.first || Date.now();
  await chrome.storage.local.set({ pvRate });
  const day = 864e5;
  const due = !pvRate.done && pvRate.wins >= 3 && Date.now() - pvRate.first > 2 * day
    && (!pvRate.later || Date.now() - pvRate.later > 21 * day);
  if (due) setTimeout(showRatePrompt, 1500);
}
function showRatePrompt() {
  if (recorder || capturing || !$('#rateCard').hidden) return;
  $('#rateCard').hidden = false;
}
async function closeRate(rated) {
  $('#rateCard').hidden = true;
  const { pvRate = {} } = await chrome.storage.local.get('pvRate');
  if (rated || pvRate.later) pvRate.done = true;
  else pvRate.later = Date.now();
  await chrome.storage.local.set({ pvRate });
}
$('#rateGo').addEventListener('click', () => { window.open(REVIEW_URL, '_blank', 'noopener'); closeRate(true); });
$('#rateLater').addEventListener('click', () => closeRate(false));

// ---------- Studio hand-off ----------
// Captures each device's screen as an image and opens the full editor with them.
function studioDeviceFor(dev) {
  if (!isResp(dev)) return dev.id;
  const w = S.resp.w;
  return w >= 1000 ? 'laptop-1280' : w >= 700 ? 'ipad-air' : 'iphone-17-pro';
}
async function openStudio() {
  if (!currentUrl) { toast('Load a website first.'); return; }
  if (recorder) { toast('Stop the recording first.'); return; }
  const wasMock = S.mock.on;
  const prevZoom = S.zoom;
  let switched = false;
  const items = [];
  let lastShot = 0;
  try {
    if (wasMock) { S.mock.on = false; renderMockPanel(); }
    await enterCapture(false);
    document.body.classList.add('capture-screens');
    switched = true;
    for (const v of [...views.values()].slice(0, 3)) {
      // Capture each device on its own at the largest zoom (up to 100%) that fits the
      // stage height, so Studio gets the sharpest screen we can get from the tab.
      S.zoom = 1;
      relayout();
      await nextFrame();
      const stageH = $('#stage').clientHeight;
      const devH = v.device.getBoundingClientRect().height / (v.scale || 1);
      S.zoom = Math.max(0.2, Math.min(1, (stageH - 24) / (devH + 8)));
      relayout();
      await nextFrame();
      v.slot.scrollIntoView({ block: 'center', inline: 'center' });
      await nextFrame();
      await sleep(140);
      // Chrome allows about two tab captures per second.
      await sleep(Math.max(0, 520 - (Date.now() - lastShot)));
      const img = await captureTab('png');
      lastShot = Date.now();
      if (!img) throw new Error('capture');
      const k = img.naturalWidth / window.innerWidth;
      const crop = (src, r) => {
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(r.width * k));
        c.height = Math.max(1, Math.round(r.height * k));
        c.getContext('2d').drawImage(src, r.left * k, r.top * k, r.width * k, r.height * k, 0, 0, c.width, c.height);
        return c;
      };
      // Full screen (status bar, Duo column, home indicator) for the Device frame.
      const c = crop(img, v.screen.getBoundingClientRect());
      const id = await putImage(await new Promise((res) => c.toBlob(res, 'image/png')));
      // Web page only for the Browser and Screenshot frames. The home indicator sits on
      // top of the page, so hide it and take a second shot when the device shows one.
      const vp = v.screen.querySelector('.viewport');
      let clean = img;
      const hi = v.screen.querySelector('.home-indicator');
      if (hi && getComputedStyle(hi).display !== 'none') {
        document.body.classList.add('capture-clean');
        await nextFrame();
        await sleep(520);
        clean = (await captureTab('png')) || img;
        lastShot = Date.now();
        document.body.classList.remove('capture-clean');
      }
      const cc = crop(clean, vp.getBoundingClientRect());
      const cid = await putImage(await new Promise((res) => cc.toBlob(res, 'image/png')));
      items.push({
        device: studioDeviceFor(v.dev),
        finish: finishOf(v.dev),
        landscape: !isResp(v.dev) && orientation(v.dev.id) === 'landscape',
        open: isOpen(v.dev),
        image: id, iw: c.width, ih: c.height,
        clean: cid, cw: cc.width, ch: cc.height,
        host: hostOf(currentUrl)
      });
    }
  } catch (e) {
    toast('Could not capture the screens. Keep this tab visible and try again.');
    return;
  } finally {
    document.body.classList.remove('capture-screens', 'capture-clean');
    if (switched) S.zoom = prevZoom;
    if (wasMock) { S.mock.on = true; renderMockPanel(); }
    exitCapture();
  }
  await setKV('import', { items, host: hostOf(currentUrl), at: Date.now() });
  window.open(chrome.runtime.getURL('studio.html'), '_blank');
  noteWin();
}
$('#studioBtn').addEventListener('click', openStudio);
wirePlanButton($('#proBtn'), (rec) => {
  LIC = rec;
  LIM = limitsOf(rec);
  if (S) { renderToggles(); pushFrameStyles(); }
  if (MAX_VIEWS === LIM.devices) return;
  MAX_VIEWS = LIM.devices;
  if (S.selected.length > MAX_VIEWS) { S.selected = S.selected.slice(0, MAX_VIEWS); saveSettings(); syncViews(); }
  renderTray();
});
$('#mockStudioBtn').addEventListener('click', openStudio);

// ---------- recording ----------
function recordRect() {
  if (S.mock.on) {
    const r = $('#devices').getBoundingClientRect();
    return { x: r.left, y: r.top, w: r.width, h: r.height };
  }
  let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
  for (const v of views.values()) {
    const r = v.scaler.getBoundingClientRect();
    x1 = Math.min(x1, r.left); y1 = Math.min(y1, r.top); x2 = Math.max(x2, r.right); y2 = Math.max(y2, r.bottom);
  }
  const pad = 28;
  x1 = Math.max(0, x1 - pad); y1 = Math.max(0, y1 - pad);
  x2 = Math.min(window.innerWidth, x2 + pad); y2 = Math.min(window.innerHeight, y2 + pad);
  return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
}

let recClock = 0;
async function startRecording(format) {
  closePops();
  if (!currentUrl) { toast('Load a website first.'); return; }
  if (recorder) return;
  if (!S.mock.on && !allVisible()) { S.zoom = 'fit'; $('#zoomSelect').value = 'fit'; relayout(); await nextFrame(); }
  const r0 = recordRect();
  const cap = format === 'gif' ? 720 : 1920;
  const m = mockSize();
  let w = m ? m.w : r0.w * window.devicePixelRatio;
  let h = m ? m.h : r0.h * window.devicePixelRatio;
  const f = Math.min(1, cap / Math.max(w, h));
  w *= f; h *= f;

  const rec = new Recorder({
    format,
    getRect: recordRect,
    size: { w, h },
    getTouches: () => [...touches.values()],
    fill: S.mock.on ? '#000' : '#0d1016',
    onStop: () => finishRecording(rec)
  });
  recorder = rec;
  try {
    await rec.start();
  } catch (e) {
    recorder = null;
    toast(e && e.name === 'NotAllowedError' ? 'Recording cancelled.' : 'Could not start recording: ' + (e.message || e), 4000);
    return;
  }
  touches.clear();
  broadcast({ type: 'pv:sim:rec', on: true });
  $('#recLive').hidden = false;
  document.querySelector('.capture').hidden = true;
  const recCap = LIM.recordSec;
  const tick = () => {
    const s = Math.floor(rec.elapsed() / 1000);
    $('#recTime').textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}${recCap ? ` / 0:${String(recCap).padStart(2, '0')}` : ''}`;
    // Free recordings stop at the cap; the file is still saved.
    if (recCap && rec.elapsed() >= recCap * 1000 && recorder === rec && !rec.capped) {
      rec.capped = true;
      stopRecording().then(() => openAccount({ reason: `Free recordings stop at ${recCap} seconds. Your clip was saved. Pro records as long as you need.` }));
    }
  };
  tick();
  recClock = setInterval(tick, 500);
  document.body.classList.add('recording');
  $('#toast').hidden = true;
}

async function finishRecording(rec) {
  clearInterval(recClock);
  document.body.classList.remove('recording');
  broadcast({ type: 'pv:sim:rec', on: false });
  $('#recLive').hidden = true;
  document.querySelector('.capture').hidden = false;
  toast(rec.format === 'gif' ? 'Encoding GIF…' : 'Saving video…', 6000);
  try {
    const { blob, ext } = await rec.result;
    download(blob, `${fileBase()}.${ext}`);
    toast(`${ext.toUpperCase()} saved to your Downloads.`);
    noteWin();
  } catch (e) {
    toast('Recording failed: ' + (e.message || e));
  }
  if (recorder === rec) recorder = null;
  touches.clear();
}

async function stopRecording() {
  if (!recorder) return;
  const rec = recorder;
  await rec.stop();
  await rec.result;
}

document.querySelectorAll('[data-rec]').forEach((b) => b.addEventListener('click', () => startRecording(b.dataset.rec)));
$('#recStop').addEventListener('click', stopRecording);
{
  const pick = pickVideoMime();
  $('#videoFmt').textContent = pick ? `${pick.ext.toUpperCase()}, 30 fps, up to 3 min` : 'Not supported in this browser';
}

// ---------- keyboard ----------
document.addEventListener('keydown', (e) => {
  if (fpRunning) { if (e.key === 'Escape') fpCancel = true; e.preventDefault(); return; }
  if (e.key === 'Escape') {
    if (anyPopoverOpen()) closePops();
    else if (sidePanel) setSide(null);
    return;
  }
  const a = document.activeElement;
  const typing = a && (/^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName) || a.isContentEditable);
  if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
  const k = e.key.toLowerCase();
  if (k === 'r') { e.preventDefault(); rotateAll(); }
  else if (k === 's') { e.preventDefault(); if (e.shiftKey) fullPageShot(); else screenshot(); }
  else if (k === 'f') { e.preventDefault(); foldAll(); }
  else if (k === 'm') { e.preventDefault(); setMock(!S.mock.on); }
  else if (k === '/') { e.preventDefault(); $('#urlInput').focus(); $('#urlInput').select(); }
});

let resizeTimer;
window.addEventListener('resize', () => {
  if (capturing) return;
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { relayout(); scheduleAmbient(600); }, 80);
});
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') scheduleAmbient(300); });

// ---------- start ----------
(async function init() {
  await loadSettings();
  const tab = await chrome.tabs.getCurrent();
  tabId = tab.id;

  const params = new URL(location.href).searchParams;
  applyLinkParams(params);
  const { pvContain = [] } = await chrome.storage.local.get('pvContain');
  containHosts = new Set(pvContain);
  const busted = params.get('contain');
  if (busted) {
    containHosts.add(busted);
    await chrome.storage.local.set({ pvContain: [...containHosts].slice(-200) });
    const clean = new URL(location.href);
    clean.searchParams.delete('contain');
    history.replaceState(null, '', clean.pathname + clean.search);
    setTimeout(() => toast(`${busted} tried to take over the tab. PocketView now keeps it contained.`, 4500), 600);
  }

  $('#mockTitle').textContent = S.mock.title;
  $('#mockSub').textContent = S.mock.sub;
  renderToggles();
  renderPresets();
  renderMockPanel();
  $('#zoomSelect').value = String(S.zoom);

  const param = params.get('url');
  const url = param ? normalizeUrl(param) : '';

  await syncViews();
  if (url) {
    navigateAll(url);
  } else {
    $('#mockScaler').hidden = true;
    $('#empty').hidden = false;
    $('#emptyInput').focus();
  }
})();
