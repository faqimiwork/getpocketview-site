// Upgrade and account dialog, shared by the simulator and Studio.
import {
  getLicense, isPro, refreshLicense, startSignIn, finishSignIn, signOut, checkoutUrl, portalUrl, onLicenseChange, LIMITS
} from './license.js';

const PRICES = { monthly: 6, yearly: 48 };
const CSS = `
.pva-back{position:fixed;inset:0;z-index:2147483000;background:rgba(5,7,10,.62);backdrop-filter:blur(4px);display:grid;place-items:center;opacity:0;transition:opacity .18s}
.pva-back.in{opacity:1}
.pva{width:min(440px,calc(100vw - 32px));max-height:calc(100vh - 40px);overflow:auto;background:#151922;color:#e8ebf1;border:1px solid #2a3040;border-radius:18px;padding:24px;box-shadow:0 30px 80px -20px rgba(0,0,0,.7);font:14px/1.5 Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;transform:translateY(8px);transition:transform .18s}
.pva-back.in .pva{transform:none}
.pva h2{margin:0 0 4px;font-size:22px;letter-spacing:-.3px;color:#fff;font-weight:700}
.pva .why{margin:0 0 14px;color:#c6f432;font-weight:500}
.pva p{margin:0 0 12px;color:#aab1bf}
.pva ul{list-style:none;padding:0;margin:4px 0 16px;display:grid;gap:7px}
.pva li{padding-left:22px;position:relative;color:#dfe3ea}
.pva li::before{content:"";position:absolute;left:2px;top:6px;width:10px;height:6px;border-left:2px solid #c6f432;border-bottom:2px solid #c6f432;transform:rotate(-45deg)}
.pva .plans{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:0 0 14px}
.pva .plan{border:1px solid #2f3646;background:#1b202b;border-radius:12px;padding:10px 12px;cursor:pointer;text-align:left;color:inherit;font:inherit}
.pva .plan b{display:block;font-size:20px;color:#fff}
.pva .plan small{color:#8d95a5}
.pva .plan.on{border-color:#c6f432;box-shadow:0 0 0 1px #c6f432 inset}
.pva .plan .tag{float:right;font-size:11px;font-weight:700;background:#c6f432;color:#0d1016;border-radius:99px;padding:2px 7px}
.pva .btnp{width:100%;height:42px;border:0;border-radius:10px;background:#c6f432;color:#0d1016;font:600 15px/1 inherit;font-family:inherit;cursor:pointer}
.pva .btnp:hover{background:#d4fb57}
.pva .btns{width:100%;height:40px;border:1px solid #2f3646;border-radius:10px;background:transparent;color:#e8ebf1;font:500 14px/1 inherit;font-family:inherit;cursor:pointer;margin-top:8px}
.pva .btns:hover{background:#1f2531}
.pva .btnp:disabled,.pva .btns:disabled{opacity:.55;cursor:default}
.pva .link{background:none;border:0;padding:0;color:#c6f432;font:inherit;cursor:pointer;text-decoration:underline}
.pva input{width:100%;height:42px;border-radius:10px;border:1px solid #2f3646;background:#0f131a;color:#fff;padding:0 12px;font:15px inherit;font-family:inherit;margin:0 0 10px}
.pva input:focus{outline:2px solid #c6f432;outline-offset:0}
.pva input.code{letter-spacing:8px;font-size:22px;font-weight:700;text-align:center}
.pva dl{display:grid;grid-template-columns:96px 1fr;gap:6px 10px;margin:8px 0 16px}
.pva dt{color:#8d95a5}.pva dd{margin:0;color:#fff;font-weight:500;word-break:break-all}
.pva .msg{min-height:20px;margin:10px 0 0;color:#aab1bf;font-size:13px}
.pva .msg.err{color:#ff8a80}
.pva .foot{margin:14px 0 0;font-size:12.5px;color:#7e8697;text-align:center}
.pva .x{float:right;margin:-8px -8px 0 0;width:30px;height:30px;border:0;background:none;color:#8d95a5;font-size:22px;line-height:1;cursor:pointer;border-radius:8px}
.pva .x:hover{background:#1f2531;color:#fff}
`;

let styled = false;
function style() {
  if (styled) return;
  styled = true;
  const s = document.createElement('style');
  s.textContent = CSS;
  document.head.appendChild(s);
}
const h = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstChild; };
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const date = (s) => (s ? new Date(s * 1000).toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' }) : '');

const FEATURES = [
  `Up to ${LIMITS.pro.devices} devices side by side`,
  'Unlimited MP4 and GIF recording',
  'Studio export up to 4x, no badge',
  'Use it on up to 5 computers',
];

let open = null;
export async function openAccount({ reason = '' } = {}) {
  style();
  if (open) open.close();
  const back = h('<div class="pva-back" role="dialog" aria-modal="true" aria-label="PocketView Pro"><div class="pva"></div></div>');
  const box = back.firstChild;
  document.body.appendChild(back);
  requestAnimationFrame(() => back.classList.add('in'));
  const close = () => { back.remove(); document.removeEventListener('keydown', onKey); if (open?.back === back) open = null; };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  back.addEventListener('mousedown', (e) => { if (e.target === back) close(); });
  open = { back, close };

  let plan = 'yearly';
  let email = '';
  const head = (title) => `<button class="x" aria-label="Close">×</button><h2>${title}</h2>`;
  const wire = () => box.querySelector('.x')?.addEventListener('click', close);
  const msg = (t, err) => { const m = box.querySelector('.msg'); if (m) { m.textContent = t; m.classList.toggle('err', !!err); } };

  function upgrade() {
    box.innerHTML = `${head('PocketView Pro')}
      ${reason ? `<p class="why">${esc(reason)}</p>` : '<p>The simulator stays free. Pro removes the limits.</p>'}
      <ul>${FEATURES.map((f) => `<li>${f}</li>`).join('')}</ul>
      <div class="plans">
        <button class="plan" data-plan="monthly"><small>Monthly</small><b>$${PRICES.monthly}</b><small>per month</small></button>
        <button class="plan" data-plan="yearly"><span class="tag">Save 33%</span><small>Yearly</small><b>$${PRICES.yearly}</b><small>$${PRICES.yearly / 12} a month</small></button>
      </div>
      <button class="btnp" id="pvaBuy">Upgrade to Pro</button>
      <p class="msg" role="status"></p>
      <p class="foot">Already Pro? <button class="link" id="pvaSignIn">Sign in</button> · Cancel any time · 14 day refund</p>`;
    wire();
    const sync = () => box.querySelectorAll('.plan').forEach((b) => b.classList.toggle('on', b.dataset.plan === plan));
    box.querySelectorAll('.plan').forEach((b) => b.addEventListener('click', () => { plan = b.dataset.plan; sync(); }));
    sync();
    box.querySelector('#pvaBuy').addEventListener('click', async (e) => {
      e.target.disabled = true;
      msg('Opening secure checkout…');
      try {
        const url = await checkoutUrl(plan);
        window.open(url, '_blank');
        msg('Finish paying in the new tab. Pro turns on here by itself when you are done.');
      } catch (err) { msg(err.message || 'Could not open checkout.', true); }
      e.target.disabled = false;
    });
    box.querySelector('#pvaSignIn').addEventListener('click', signInEmail);
  }

  function signInEmail() {
    box.innerHTML = `${head('Sign in to Pro')}
      <p>Enter the email you paid with. We will send you a 6 digit code.</p>
      <form id="pvaF"><input type="email" id="pvaEmail" required placeholder="you@example.com" autocomplete="email" value="${esc(email)}">
      <button class="btnp" type="submit">Email me a code</button></form>
      <p class="msg" role="status"></p>
      <p class="foot"><button class="link" id="pvaBack">Back</button></p>`;
    wire();
    box.querySelector('#pvaEmail').focus();
    box.querySelector('#pvaBack').addEventListener('click', upgrade);
    box.querySelector('#pvaF').addEventListener('submit', async (e) => {
      e.preventDefault();
      email = box.querySelector('#pvaEmail').value.trim();
      msg('Sending…');
      try { const r = await startSignIn(email); signInCode(r.wait); } catch (err) { msg(err.message || 'Could not send the code.', true); }
    });
  }

  function signInCode(wait) {
    box.innerHTML = `${head('Check your email')}
      <p>If <b>${esc(email)}</b> has a PocketView plan, a code is on its way. It expires in 10 minutes.</p>
      <form id="pvaF"><input class="code" id="pvaCode" inputmode="numeric" maxlength="6" autocomplete="one-time-code" required>
      <button class="btnp" type="submit">Sign in</button></form>
      <p class="msg" role="status">${wait ? `A code was sent a moment ago. You can ask again in ${wait} seconds.` : ''}</p>
      <p class="foot"><button class="link" id="pvaBack">Use another email</button></p>`;
    wire();
    box.querySelector('#pvaCode').focus();
    box.querySelector('#pvaBack').addEventListener('click', signInEmail);
    box.querySelector('#pvaF').addEventListener('submit', async (e) => {
      e.preventDefault();
      msg('Checking…');
      try {
        const rec = await finishSignIn(email, box.querySelector('#pvaCode').value);
        rec.plan?.pro ? account(rec) : noPlan(rec);
      } catch (err) { msg(err.message || 'That code did not work.', true); }
    });
  }

  function noPlan(rec) {
    box.innerHTML = `${head('No active plan')}
      <p>${esc(rec.plan?.email || email)} does not have an active Pro plan right now.</p>
      <button class="btnp" id="pvaUp">See Pro plans</button>
      <button class="btns" id="pvaOut">Sign out</button>`;
    wire();
    box.querySelector('#pvaUp').addEventListener('click', upgrade);
    box.querySelector('#pvaOut').addEventListener('click', async () => { await signOut(); upgrade(); });
  }

  function account(rec) {
    const p = rec.plan || {};
    const ends = p.cancelAtPeriodEnd || p.status === 'canceled';
    box.innerHTML = `${head('PocketView Pro')}
      <dl><dt>Email</dt><dd>${esc(p.email)}</dd><dt>Plan</dt><dd>Pro, ${p.plan === 'yearly' ? 'yearly' : 'monthly'}</dd>
      ${p.status === 'past_due' ? '<dt>Status</dt><dd>Payment due. Update your card.</dd>' : ''}
      ${p.periodEnd ? `<dt>${ends ? 'Ends' : 'Renews'}</dt><dd>${date(p.periodEnd)}</dd>` : ''}</dl>
      <button class="btnp" id="pvaPortal">Manage billing</button>
      <button class="btns" id="pvaOut">Sign out on this computer</button>
      <p class="msg" role="status"></p>`;
    wire();
    box.querySelector('#pvaPortal').addEventListener('click', async (e) => {
      e.target.disabled = true; msg('Opening billing…');
      try { window.open(await portalUrl(), '_blank'); msg(''); } catch (err) { msg(err.message, true); }
      e.target.disabled = false;
    });
    box.querySelector('#pvaOut').addEventListener('click', async () => { await signOut(); close(); });
  }

  const rec = await getLicense({ refresh: false });
  if (isPro(rec)) account(rec);
  else if (rec.token && rec.plan && !rec.plan.pro) noPlan(rec);
  else upgrade();
  if (rec.token) refreshLicense().then((r) => { if (open?.back === back && isPro(r) && !box.querySelector('form')) account(r); });
  return { close };
}

// Keeps a toolbar button in step with the plan: "Go Pro" on Free, "Pro" when active.
export function wirePlanButton(btn, onPlan) {
  const paint = (rec) => {
    const pro = isPro(rec);
    btn.classList.toggle('is-pro', pro);
    btn.querySelector('span') ? (btn.querySelector('span').textContent = pro ? 'Pro' : 'Go Pro') : (btn.textContent = pro ? 'Pro' : 'Go Pro');
    btn.title = pro ? 'PocketView Pro: your plan' : 'Upgrade to PocketView Pro';
    onPlan && onPlan(rec);
  };
  btn.addEventListener('click', () => openAccount());
  let wasPro = null;
  getLicense().then((rec) => { wasPro = isPro(rec); paint(rec); });
  onLicenseChange((rec) => {
    const pro = isPro(rec);
    paint(rec);
    // Only switch an open dialog to the account view when the plan just became Pro
    // (for example right after checkout). Routine licence checks must not reopen it.
    if (open && pro && wasPro === false) openAccount();
    wasPro = pro;
  });
}
