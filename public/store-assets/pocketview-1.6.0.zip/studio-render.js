// PocketView Studio renderer.
// Draws a whole mockup scene (background, effects, devices, text) on a 2D canvas at any
// scale, so the preview, the thumbnails and the exported file all come from one code path.

import { DEVICES } from './devices.js';
import { warp } from './studio-gl.js';
import { bgById, paintPreset, magicPreset, toneOf, noiseTile } from './studio-bg.js';
import { SC_SHADOWS } from './studio-sc-presets.js';
import { drawSceneShadow } from './studio-scene.js';

// ---------- data ----------
export const FINISHES = [
  ['midnight', '#2b2f37', 'Midnight'], ['silver', '#e3e5e9', 'Silver'], ['titanium', '#9a9792', 'Titanium'],
  ['desert', '#cdb497', 'Desert'], ['cream', '#ece4d6', 'Cream'], ['lavender', '#c9bfe0', 'Lavender'],
  ['rose', '#e7c3ba', 'Rose'], ['graphite', '#45474c', 'Graphite'], ['red', '#b3182e', 'Red'],
  ['starwhite', '#ececea', 'Star White'], ['nightsky', '#2b3a55', 'Night Sky'],
  ['violetshadow', '#4a4458', 'Violet Shadow'], ['violetgreen', '#2f4a3e', 'Violet Green'],
  ['pistachio', '#cfe3d6', 'Pistachio'], ['pink', '#f0c6d4', 'Pink'], ['mint', '#cdeedd', 'Mint'],
  ['blue', '#4d6a9a', 'Blue'], ['orange', '#e2793a', 'Orange']
];
const FINISH_HEX = Object.fromEntries(FINISHES.map(([id, hex]) => [id, hex]));

export const CANVAS_GROUPS = [
  { name: 'Ratio', items: [['r16-9', '16:9', 1920, 1080], ['r3-2', '3:2', 1920, 1280], ['r4-3', '4:3', 1920, 1440], ['r5-4', '5:4', 1920, 1536], ['r1-1', '1:1', 1920, 1920], ['r4-5', '4:5', 1536, 1920], ['r3-4', '3:4', 1440, 1920], ['r2-3', '2:3', 1280, 1920], ['r9-16', '9:16', 1080, 1920]] },
  { name: 'Instagram', items: [['portrait', 'Portrait', 1080, 1350], ['square', 'Post', 1080, 1080], ['story', 'Story', 1080, 1920]] },
  { name: 'X / Twitter', items: [['x-post', 'Post', 1600, 900], ['x-header', 'Header', 1500, 500]] },
  { name: 'LinkedIn', items: [['li-post', 'Post', 1200, 1200], ['li-wide', 'Wide', 1200, 627]] },
  { name: 'YouTube', items: [['yt-thumb', 'Thumbnail', 1280, 720], ['yt-banner', 'Banner', 2560, 1440]] },
  { name: 'Pinterest', items: [['pin', 'Optimal', 1000, 1500], ['pin-long', 'Long', 1000, 2100]] },
  { name: 'Dribbble', items: [['dribbble', 'Shot', 1600, 1200]] },
  { name: 'Web', items: [['og', 'Link preview', 1200, 630], ['cws', 'Chrome Web Store', 1280, 800], ['ph', 'Product Hunt', 1270, 760], ['mac', 'Mac 16:10', 2880, 1800]] },
  { name: 'App Store', items: [['appstore', 'iPhone 6.9"', 1290, 2796], ['as65', 'iPhone 6.5"', 1284, 2778], ['as55', 'iPhone 5.5"', 1242, 2208], ['ipad13', 'iPad 13"', 2064, 2752]] },
  { name: 'Google Play', items: [['gp-phone', 'Phone', 1080, 1920], ['gp-feature', 'Feature graphic', 1024, 500]] }
];
export const CANVAS_PRESETS = CANVAS_GROUPS.flatMap((g) => g.items.map(([id, name, w, h]) => ({ id, name, group: g.name, w, h })));

// Shadows: layers are [x, y, blur, spread, opacity] in 1/1000 of the device height.
// Shotcandy's layers (MIT) are tuned for light cards, so they get a little more weight here.
const boost = (layers, k) => layers.map(([x, y, b, s, o]) => [x, y, b, s, Math.min(1, o * k)]);
export const SHADOWS = [
  { id: 'none', name: 'None', layers: [] },
  { id: 'spread', name: 'Spread', layers: [[0, 14, 40, 0, 0.28], [0, 60, 160, -10, 0.42]] },
  { id: 'hug', name: 'Hug', layers: boost(SC_SHADOWS.hug, 2.2) },
  { id: 'soft', name: 'Soft', layers: boost(SC_SHADOWS.soft, 2) },
  { id: 'float', name: 'Float', layers: boost(SC_SHADOWS.float, 1.8) },
  { id: 'deep', name: 'Deep', layers: boost(SC_SHADOWS.deep, 1.6) },
  { id: 'adaptive', name: 'Adaptive', layers: [[0, 20, 70, 0, 0.55], [0, 70, 180, -20, 0.6]], adaptive: true },
  { id: 'glow', name: 'Glow', layers: SC_SHADOWS.glow, adaptive: true },
  { id: 'retro', name: 'Retro', layers: [[22, 22, 0, 0, 1]] }
];
const SHADOW_BY_ID = Object.fromEntries(SHADOWS.map((s) => [s.id, s]));

export const SCREEN_STYLES = [
  { id: 'default', name: 'Default' }, { id: 'glass-light', name: 'Glass Light' }, { id: 'glass-dark', name: 'Glass Dark' },
  { id: 'liquid', name: 'Liquid Glass' }, { id: 'inset-light', name: 'Inset Light' }, { id: 'inset-dark', name: 'Inset Dark' },
  { id: 'outline', name: 'Outline' }, { id: 'border', name: 'Border' }
];

const clampN = (v, a, b) => Math.max(a, Math.min(b, v));
const DEV = new Map(DEVICES.map((d) => [d.id, d]));
export function deviceById(id) { return DEV.get(id) || DEV.get('iphone-17-pro'); }

export function kindOf(dev) {
  if (dev.group === 'Tablet') return 'tablet';
  if (dev.group === 'Desktop' || dev.id === 'responsive') return 'laptop';
  if (dev.group === 'Custom') return dev.w >= 1000 ? 'laptop' : dev.w >= 700 ? 'tablet' : 'phone';
  return 'phone';
}

// ---------- colours ----------
export function hexToRgb(hex) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h.slice(0, 6), 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}
const rgba = (hex, a) => { const c = hexToRgb(hex); return `rgba(${c.r},${c.g},${c.b},${a})`; };
function shade(hex, amt) {
  const c = hexToRgb(hex);
  const f = (v) => Math.max(0, Math.min(255, Math.round(amt >= 0 ? v + (255 - v) * amt : v * (1 + amt))));
  return `rgb(${f(c.r)},${f(c.g)},${f(c.b)})`;
}
function lum(hex) {
  const c = hexToRgb(hex);
  const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
}

// The preset object a project's background resolves to.
export function resolveBg(bg) {
  if (!bg) return null;
  if (bg.kind === 'preset') return bgById(bg.id) || bgById('pv-pocket');
  if (bg.kind === 'color') return { kind: 'solid', color: bg.color };
  if (bg.kind === 'magic') return magicPreset(bg.magic || 'mesh', bg.palette);
  return null;
}
export function backgroundTone(bg) {
  if (bg.kind === 'transparent') return '#ffffff';
  if (bg.kind === 'image') return '#333333';
  return toneOf(resolveBg(bg));
}
export function autoInk(bg) { return lum(backgroundTone(bg)) > 0.4 ? '#0d1016' : '#ffffff'; }

// Picks a few strong colours from an image (for Magic backgrounds and adaptive shadows).
export function paletteFrom(img) {
  const c = document.createElement('canvas');
  c.width = 32; c.height = 32;
  const x = c.getContext('2d', { willReadFrequently: true });
  x.drawImage(img, 0, 0, 32, 32);
  const d = x.getImageData(0, 0, 32, 32).data;
  const buckets = new Map();
  for (let i = 0; i < d.length; i += 4) {
    const key = ((d[i] >> 5) << 6) | ((d[i + 1] >> 5) << 3) | (d[i + 2] >> 5);
    const b = buckets.get(key) || { n: 0, r: 0, g: 0, b: 0 };
    b.n++; b.r += d[i]; b.g += d[i + 1]; b.b += d[i + 2];
    buckets.set(key, b);
  }
  const cols = [...buckets.values()].map((b) => {
    const r = b.r / b.n, g = b.g / b.n, bl = b.b / b.n;
    const mx = Math.max(r, g, bl), mn = Math.min(r, g, bl);
    const sat = mx ? (mx - mn) / mx : 0;
    return { r, g, b: bl, n: b.n, score: b.n * (0.35 + sat) };
  }).sort((a, b) => b.score - a.score);
  const out = [];
  for (const c2 of cols) {
    if (out.every((o) => Math.hypot(o.r - c2.r, o.g - c2.g, o.b - c2.b) > 60)) out.push(c2);
    if (out.length === 4) break;
  }
  while (out.length < 4) out.push({ r: 30 + out.length * 20, g: 34, b: 44 + out.length * 30 });
  return out.map((c3) => '#' + [c3.r, c3.g, c3.b].map((v) => Math.round(v).toString(16).padStart(2, '0')).join(''));
}

// ---------- project defaults and migration ----------
export function styleOf(P) { return { ...P.style, ...((P.looks && P.looks[P.style.frame]) || {}) }; }
export function defaultsInto(P) {
  P.fx = Object.assign({ noise: 0, blur: 0, vignette: 0, leak: 0 }, P.fx || {});
  P.fx.wm = Object.assign({ on: false, text: 'getpocketview.com', logo: null, style: 'badge', tone: 'light', pos: 'br', size: 100, inset: 4, opacity: 100 }, P.fx.wm || {});
  if (P.text) P.text = Object.assign({ font: 'hubot', weight: 800, subFont: 'inter' }, P.text);
  P.scene = Object.assign({ kind: 'none', shadow: 'blinds', amount: 60, soft: 50, flip: false }, P.scene || {});
  if (P.scene.kind === 'blinds' || P.scene.kind === 'leaves') { P.scene.shadow = P.scene.kind; P.scene.kind = 'shadow'; }
  P.camera = Object.assign({ zoom: 1, fx: 0.5, fy: 0.5, rx: 0, ry: 0 }, P.camera || {});
  P.style = Object.assign({ frame: 'device', shadow: 'soft', shadowOpacity: 1, light: 90, lightDist: 1, glare: true, screenStyle: 'glass-light', radius: 4, dark: false, hideFrame: false }, P.style || {});
  // Each mockup type keeps its own look, so a Screenshot border never leaks into Browser or Device.
  if (!P.looks) {
    const sh = { shadow: P.style.shadow, shadowOpacity: P.style.shadowOpacity, light: P.style.light, lightDist: P.style.lightDist };
    P.looks = {
      device: { ...sh },
      browser: { ...sh, dark: !!P.style.dark, radius: 1.2 },
      screen: { ...sh, screenStyle: P.style.screenStyle, radius: P.style.radius }
    };
  }
  return P;
}
export function migrate(P) {
  if (!P) return P;
  if (P.v === 1) {
    const b = P.bg || {};
    const nb = { kind: 'preset', id: 'pv-pocket', color: b.color || '#0d1016', image: b.image || null, blur: b.blur ?? 30, palette: b.palette || [], magic: 'mesh' };
    if (b.type === 'gradient') nb.id = `pv-${b.gradient}`;
    else if (b.type === 'solid') nb.kind = 'color';
    else if (b.type === 'magic') nb.kind = 'magic';
    else if (b.type === 'image') nb.kind = 'image';
    else if (b.type === 'transparent') nb.kind = 'transparent';
    if (nb.kind === 'preset' && !bgById(nb.id)) nb.id = 'pv-pocket';
    P.bg = nb;
    defaultsInto(P);
    P.fx.noise = b.grain ? 30 : 0;
    const map = { none: 'default', 'glass-light': 'glass-light', 'glass-dark': 'glass-dark', outline: 'outline', solid: 'border' };
    P.style.screenStyle = map[P.style.border] || 'default';
    if (P.style.shadow === 'strong') P.style.shadow = 'deep';
    P.v = 2;
  }
  return defaultsInto(P);
}

// ---------- device geometry ----------
// Mirrors the simulator's CSS frames (simulator.css): same bezels, ring, corner radii,
// buttons, fold-back, hinges and cutouts, so a device looks the same in both places.
// Everything is in device units (CSS pixels of the device screen).
const RINGS = {
  midnight: ['#4a4f59', '#1f2228', '#6a707c', '#3b3f48'], silver: ['#d9dce1', '#9a9fa8', '#f6f7f9', '#c7cad0'],
  titanium: ['#8c8a86', '#5d5b58', '#b9b6b0', '#807d79'], desert: ['#c8ad8e', '#8f7559', '#e6d3bb', '#b39a7d'],
  cream: ['#e6dccb', '#b8ab95', '#f8f3ea', '#d8ccb8'], lavender: ['#cdc3e3', '#9a8fb8', '#e9e3f5', '#b9aed6'],
  rose: ['#e5bfb6', '#b48a80', '#f7ddd6', '#d6aca2'], graphite: ['#4b4d52', '#232428', '#707379', '#3e4045'],
  red: ['#b5192f', '#6a0c19', '#db475d', '#9e1427'], starwhite: ['#e2e2df', '#a3a4a2', '#fbfbf9', '#cfcfcc'],
  nightsky: ['#2f3f5c', '#121a29', '#536a94', '#28364f'], violetshadow: ['#4c4659', '#262130', '#726a85', '#3f394b'],
  violetgreen: ['#31503f', '#172a20', '#56786a', '#2a4436'], pistachio: ['#cde2d4', '#98b3a2', '#e9f4ed', '#b9d1c1'],
  pink: ['#efc4d2', '#c48fa1', '#fbe4ec', '#e0adbe'], mint: ['#cbeddb', '#93c2aa', '#e9f9f1', '#b3dcc6'],
  blue: ['#4d6a9a', '#26395c', '#7d9ccd', '#44608f'], orange: ['#e2793a', '#9c4718', '#f6a46c', '#cf6c31']
};
const ring = (f) => { const [a, b, c, btn] = RINGS[f] || RINGS.midnight; return { a, b, c, btn }; };
const DUO_COL = 84;

function screenPad(style, sw, sh) {
  const m = Math.min(sw, sh);
  switch (style.screenStyle) {
    case 'glass-light': case 'glass-dark': case 'liquid': return Math.round(m * 0.032);
    case 'inset-light': case 'inset-dark': return Math.round(m * 0.045);
    case 'border': return Math.round(m * 0.028);
    default: return 0;
  }
}
const four = (v) => (Array.isArray(v) ? v : [v, v, v, v]);
const addR = (v, d) => four(v).map((x) => Math.max(0, x + d));

// Captured screens carry two images: the full device screen (status bar, Duo column) for
// the Device frame, and the web page alone for the Browser and Screenshot frames.
export function mediaOf(item, style) {
  if (style && style.frame !== 'device' && item.clean) return { id: item.clean, iw: item.cw, ih: item.ch };
  return { id: item.image, iw: item.iw, ih: item.ih };
}

export function geometry(item, style) {
  const dev = deviceById(item.device);
  const open = !!(dev.fold && item.open);
  const folded = !!(dev.fold && !item.open);
  const scr = open ? dev.fold : dev;
  const land = !!item.landscape;
  let sw = scr.w, sh = scr.h;
  if (land) [sw, sh] = [sh, sw];
  const frame = style.frame;
  if (frame === 'browser' || frame === 'screen') {
    const m = mediaOf(item, style);
    const iw = m.iw || (frame === 'browser' ? 1440 : 1200);
    const ih = m.ih || (frame === 'browser' ? 900 : 800);
    sw = 1200;
    sh = Math.round(sw * clampN(ih / iw, 0.3, 2.4));
  }
  let kind = frame === 'device' ? kindOf(dev) : frame;
  if (frame === 'device' && style.hideFrame) kind = 'bare';
  const foldStyle = dev.fold ? (dev.fold.style || 'wide') : null;
  const notch = open ? (dev.fold.notch || dev.notch) : dev.notch;
  const g = { dev, kind, open, folded, foldStyle, land, sw, sh, notch, captured: !!item.captured };

  if (kind === 'phone' || kind === 'tablet' || kind === 'laptop' || kind === 'bare') {
    const home = notch === 'home';
    const fb = dev.fold ? ((open ? dev.fold.openBezel : dev.fold.coverBezel) || 0) : 0;
    const devKind = kindOf(dev);
    const bezel = fb || (devKind === 'tablet' ? 18 : devKind === 'laptop' ? 14 : home ? 14 : 12);
    let bx, by;
    if (devKind === 'laptop') bx = by = 14;
    else if (home) { bx = land ? 72 : 14; by = land ? 14 : 72; }
    else if (devKind === 'tablet') bx = by = 18;
    else bx = by = fb || 12;
    const r = devKind === 'laptop' ? 4 : (scr.radius || 0);
    const rad = home ? 52 : devKind === 'laptop' ? 14 : (open && dev.fold.openCorner != null ? dev.fold.openCorner : r + bezel);
    let bodyR = four(rad), scrR = four(r);
    if (folded && foldStyle !== 'flip') {
      const rl = dev.fold.coverCorner ?? 16;
      const rs = Math.max(2, rl - bezel);
      bodyR = land ? [rl, rl, rad, rad] : [rl, rad, rad, rl];
      scrR = land ? [rs, rs, r, r] : [rs, r, r, rs];
      g.rl = rl;
    }
    g.r = scrR; g.bodyR = bodyR; g.home = home; g.bezel = bezel;
    if (kind === 'bare') {
      g.ox = g.oy = 0; g.sx = g.sy = 0; g.W = sw; g.H = sh; g.Wb = sw; g.Hb = sh; g.margin = 1;
      return g;
    }
    g.Wb = sw + 2 * bx; g.Hb = sh + 2 * by;
    if (kind === 'laptop') {
      g.W = g.Wb * 1.12; g.H = g.Hb + 3 + 16;
      g.ox = (g.W - g.Wb) / 2; g.oy = 3;
    } else {
      g.W = g.Wb + 6; g.H = g.Hb + 6; g.ox = 3; g.oy = 3;
    }
    g.sx = g.ox + bx; g.sy = g.oy + by;
    g.margin = 14;
    return g;
  }
  if (kind === 'browser') {
    const bar = Math.max(30, Math.round(Math.min(sw, 1600) * 0.03));
    g.bar = bar; g.sx = 0; g.sy = bar;
    g.W = sw; g.H = sh + bar;
    g.r = four(0); g.bodyR = Math.max(6, Math.round(Math.min(sw, sh) * (style.radius ?? 1.2) / 100));
    g.margin = 1;
    return g;
  }
  // screenshot only
  const pad = screenPad(style, sw, sh);
  g.pad = pad; g.sx = pad; g.sy = pad;
  g.W = sw + 2 * pad; g.H = sh + 2 * pad;
  const rr = Math.round(Math.min(sw, sh) * (style.radius ?? 4) / 100);
  g.r = four(rr);
  g.bodyR = rr + pad;
  g.margin = 2;
  return g;
}

// ---------- device drawing ----------
function cssLinear(ctx, deg, x, y, w, h, stops) {
  const a = deg * Math.PI / 180;
  const dx = Math.sin(a), dy = -Math.cos(a);
  const len = Math.abs(w * dx) + Math.abs(h * dy);
  const cx = x + w / 2, cy = y + h / 2;
  const gr = ctx.createLinearGradient(cx - dx * len / 2, cy - dy * len / 2, cx + dx * len / 2, cy + dy * len / 2);
  stops.forEach(([o, c]) => gr.addColorStop(o, c));
  return gr;
}

function drawScreen(ctx, g, item, img, opts) {
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(g.sx, g.sy, g.sw, g.sh, g.r);
  ctx.clip();
  // iPhone Duo cover: the simulator puts status, camera and controls in a column on the
  // right. Screens captured from the simulator already contain it; uploads get one drawn.
  const duoCol = g.folded && g.foldStyle === 'duo' && !g.land && (g.kind === 'phone' || g.kind === 'bare') && !g.captured;
  const aw = duoCol ? g.sw - DUO_COL : g.sw;
  if (img) {
    const iw = img.width, ih = img.height;
    const s = Math.max(aw / iw, g.sh / ih);
    const dw = iw * s, dh = ih * s;
    const fx = item.focusX ?? 0.5, fy = item.focusY ?? 0;
    ctx.imageSmoothingQuality = 'high';
    ctx.save();
    ctx.beginPath(); ctx.rect(g.sx, g.sy, aw, g.sh); ctx.clip();
    ctx.drawImage(img, g.sx + (aw - dw) * fx, g.sy + (g.sh - dh) * fy, dw, dh);
    ctx.restore();
  } else {
    ctx.fillStyle = cssLinear(ctx, 135, g.sx, g.sy, g.sw, g.sh, [[0, '#232838'], [1, '#141720']]);
    ctx.fillRect(g.sx, g.sy, g.sw, g.sh);
    if (opts.placeholder) {
      const u = Math.min(aw, g.sh);
      const cx = g.sx + aw / 2, cy = g.sy + g.sh / 2 - u * 0.05;
      ctx.fillStyle = 'rgba(198,244,50,.9)';
      ctx.beginPath(); ctx.arc(cx, cy, u * 0.07, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#0d1016';
      const p = u * 0.035;
      ctx.fillRect(cx - p, cy - p * 0.14, p * 2, p * 0.28);
      ctx.fillRect(cx - p * 0.14, cy - p, p * 0.28, p * 2);
      ctx.fillStyle = 'rgba(232,235,241,.75)';
      ctx.font = `600 ${Math.round(u * 0.05)}px "Inter Tight", system-ui, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.fillText('Drop or paste an image', cx, cy + u * 0.11);
    }
  }
  if (duoCol) drawDuoColumn(ctx, g);
  if (g.kind === 'phone') {
    if (g.folded && g.foldStyle === 'flip') drawFlipCams(ctx, g, item);
    if (g.open) drawCrease(ctx, g);
    drawCutout(ctx, g);
  }
  if (opts.glare && (g.kind === 'phone' || g.kind === 'tablet' || g.kind === 'laptop')) {
    ctx.fillStyle = cssLinear(ctx, 118, g.sx, g.sy, g.sw, g.sh, [[0, 'rgba(255,255,255,.16)'], [0.28, 'rgba(255,255,255,.05)'], [0.42, 'rgba(255,255,255,0)']]);
    ctx.fillRect(g.sx, g.sy, g.sw, g.sh);
  }
  ctx.restore();
}

function drawDuoColumn(ctx, g) {
  const x = g.sx + g.sw - DUO_COL, cx = x + DUO_COL / 2;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(x, g.sy, DUO_COL, g.sh);
  let y = g.sy + 16;
  ctx.fillStyle = '#000';
  ctx.beginPath(); ctx.arc(cx, y + 15, 17, 0, Math.PI * 2); ctx.fill();
  const cam = ctx.createRadialGradient(cx - 1.5, y + 13.5, 0, cx, y + 15, 15);
  cam.addColorStop(0, '#33405e'); cam.addColorStop(0.17, '#33405e'); cam.addColorStop(0.24, '#0b0d12'); cam.addColorStop(1, '#0b0d12');
  ctx.fillStyle = cam;
  ctx.beginPath(); ctx.arc(cx, y + 15, 15, 0, Math.PI * 2); ctx.fill();
  y += 30 + 14;
  ctx.fillStyle = '#000';
  ctx.font = '700 15px "Inter Tight", system-ui, sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'top';
  ctx.fillText('9:41', cx, y);
  y += 28;
  // wifi + battery
  ctx.strokeStyle = '#000'; ctx.lineWidth = 1.5;
  for (const [rr, a] of [[8, 1], [5, 1]]) { ctx.beginPath(); ctx.arc(cx - 12, y + 9, rr, Math.PI * 1.25, Math.PI * 1.75); ctx.stroke(); }
  ctx.beginPath(); ctx.arc(cx - 12, y + 8.5, 1.4, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.roundRect(cx - 1, y, 22, 11, 4); ctx.stroke();
  ctx.fillRect(cx + 1.5, y + 2.5, 15, 6);
}

function drawFlipCams(ctx, g, item) {
  const R = ring(item.finish);
  const right = g.land;
  const cy = g.sy + g.sh - 14 - 29;
  const x0 = right ? g.sx + g.sw - 14 - 58 - 10 - 10 - 58 : g.sx + 14;
  [x0 + 29, x0 + 58 + 10 + 29].forEach((cx) => {
    ctx.fillStyle = R.b; ctx.beginPath(); ctx.arc(cx, cy, 31, 0, Math.PI * 2); ctx.fill();
    const gr = ctx.createRadialGradient(cx, cy, 0, cx, cy, 29);
    gr.addColorStop(0, '#1d2433'); gr.addColorStop(7 / 29, '#1d2433'); gr.addColorStop(8 / 29, '#07080b'); gr.addColorStop(19 / 29, '#07080b');
    gr.addColorStop(20 / 29, '#2a2d33'); gr.addColorStop(23 / 29, '#2a2d33'); gr.addColorStop(24 / 29, R.a); gr.addColorStop(1, R.a);
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(cx, cy, 29, 0, Math.PI * 2); ctx.fill();
  });
  const fx = x0 + 58 * 2 + 10 + 10 + 5, fy = cy - 29 + 7;
  const fl = ctx.createRadialGradient(fx, fy, 0, fx, fy, 5);
  fl.addColorStop(0, '#fff6d8'); fl.addColorStop(0.6, '#fff6d8'); fl.addColorStop(0.8, '#c9c3b2'); fl.addColorStop(1, '#c9c3b2');
  ctx.fillStyle = fl; ctx.beginPath(); ctx.arc(fx, fy, 5, 0, Math.PI * 2); ctx.fill();
}

function drawCrease(ctx, g) {
  // Book folds crease vertically (horizontally in landscape); the Flip creases across.
  const across = g.foldStyle === 'flip' ? !g.land : g.land;
  const st = [[0, 'rgba(0,0,0,0)'], [0.35, 'rgba(0,0,0,.07)'], [0.5, 'rgba(255,255,255,.18)'], [0.65, 'rgba(0,0,0,.07)'], [1, 'rgba(0,0,0,0)']];
  if (across) {
    const y = g.sy + g.sh / 2 - 5;
    ctx.fillStyle = cssLinear(ctx, 180, g.sx, y, g.sw, 10, st);
    ctx.fillRect(g.sx, y, g.sw, 10);
  } else {
    const x = g.sx + g.sw / 2 - 5;
    ctx.fillStyle = cssLinear(ctx, 90, x, g.sy, 10, g.sh, st);
    ctx.fillRect(x, g.sy, 10, g.sh);
  }
}

function drawCutout(ctx, g) {
  if (g.home) return;
  if (g.folded && g.foldStyle === 'duo') return;
  const n = g.notch;
  if (n !== 'island' && n !== 'notch' && n !== 'punch') return;
  // Unfolded book foldables carry the camera on the right half; the Flip keeps it centred.
  const at = g.open && g.foldStyle !== 'flip' ? 0.75 : 0.5;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  if (!g.land) {
    const cx = g.sx + g.sw * at;
    if (n === 'island') ctx.roundRect(cx - 62, g.sy + 11, 124, 36, 20);
    else if (n === 'notch') ctx.roundRect(cx - 80, g.sy, 160, 32, [0, 0, 20, 20]);
    else ctx.arc(cx, g.sy + 8 + 6, 6, 0, Math.PI * 2);
  } else {
    const cy = g.sy + g.sh * at;
    if (n === 'island') ctx.roundRect(g.sx + 11, cy - 62, 36, 124, 20);
    else if (n === 'notch') ctx.roundRect(g.sx, cy - 80, 32, 160, [0, 20, 20, 0]);
    else ctx.arc(g.sx + 8 + 6, cy, 6, 0, Math.PI * 2);
  }
  ctx.fill();
}

function drawHardware(ctx, g, item, img, opts) {
  const R = ring(item.finish);
  const X = g.ox, Y = g.oy, Wb = g.Wb, Hb = g.Hb;
  // Folded: the other half of the phone peeks out behind the cover on the hinge side.
  if (g.folded) {
    if (g.foldStyle === 'flip' || g.land) {
      const flip = g.foldStyle === 'flip';
      const inset = Wb * (flip ? 0.06 : 0.025);
      const h = Hb * (flip ? 0.3 : 0.4);
      ctx.fillStyle = cssLinear(ctx, 180, X + inset, Y - 10, Wb - inset * 2, h, [[0, R.b], [0.3, R.a], [1, R.b]]);
      ctx.beginPath(); ctx.roundRect(X + inset, Y - 10, Wb - inset * 2, h, flip ? [14, 14, 0, 0] : [g.rl + 4, g.rl + 4, 0, 0]); ctx.fill();
      const hi = Wb * (flip ? 0.1 : 0.07);
      ctx.fillStyle = cssLinear(ctx, 90, X + hi, Y - 7, Wb - hi * 2, 3, [[0, R.a], [0.5, R.c], [1, R.a]]);
      ctx.beginPath(); ctx.roundRect(X + hi, Y - 7, Wb - hi * 2, 3, 2); ctx.fill();
    } else {
      ctx.fillStyle = cssLinear(ctx, 90, X - 10, Y + Hb * 0.025, Wb * 0.4, Hb * 0.95, [[0, R.b], [0.3, R.a], [1, R.b]]);
      ctx.beginPath(); ctx.roundRect(X - 10, Y + Hb * 0.025, Wb * 0.4, Hb * 0.95, [g.rl + 4, 0, 0, g.rl + 4]); ctx.fill();
      ctx.fillStyle = cssLinear(ctx, 180, X - 7, Y + Hb * 0.07, 3, Hb * 0.86, [[0, R.a], [0.5, R.c], [1, R.a]]);
      ctx.beginPath(); ctx.roundRect(X - 7, Y + Hb * 0.07, 3, Hb * 0.86, 2); ctx.fill();
    }
  }
  // Side buttons (regular phones only)
  if (g.kind === 'phone' && !g.dev.fold) {
    ctx.fillStyle = R.btn;
    const b = (x, y, w, h) => { ctx.beginPath(); ctx.roundRect(x, y, w, h, 1.5); ctx.fill(); };
    if (!g.land) { b(X + Wb + 3, Y + Hb * 0.26, 3, 70); b(X - 6, Y + Hb * 0.2, 3, 46); b(X - 6, Y + Hb * 0.2 + 56, 3, 46); }
    else { b(X + Wb * 0.26, Y - 6, 70, 3); b(X + Wb * 0.2, Y + Hb + 3, 46, 3); b(X + Wb * 0.2 + 56, Y + Hb + 3, 46, 3); }
  }
  // Metal ring, 3px outside the bezel
  ctx.fillStyle = cssLinear(ctx, 135, X - 3, Y - 3, Wb + 6, Hb + 6, [[0, R.c], [0.22, R.a], [0.5, R.b], [0.78, R.a], [1, R.c]]);
  ctx.beginPath(); ctx.roundRect(X - 3, Y - 3, Wb + 6, Hb + 6, addR(g.bodyR, 3)); ctx.fill();
  // Unfolded: hinge tabs on the frame edge
  if (g.open) {
    ctx.fillStyle = R.c;
    const across = g.foldStyle === 'flip' ? !g.land : g.land;
    ctx.beginPath();
    if (across) { ctx.roundRect(X - 6, Y + Hb / 2 - 20, 6, 40, 3); ctx.roundRect(X + Wb, Y + Hb / 2 - 20, 6, 40, 3); }
    else { ctx.roundRect(X + Wb / 2 - 20, Y - 6, 40, 6, 3); ctx.roundRect(X + Wb / 2 - 20, Y + Hb, 40, 6, 3); }
    ctx.fill();
  }
  // Glass bezel
  ctx.fillStyle = '#07080a';
  ctx.beginPath(); ctx.roundRect(X, Y, Wb, Hb, g.bodyR); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,.06)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.roundRect(X + 0.5, Y + 0.5, Wb - 1, Hb - 1, addR(g.bodyR, -0.5)); ctx.stroke();
  if (g.home) {
    ctx.strokeStyle = R.btn; ctx.lineWidth = 2;
    ctx.beginPath();
    if (!g.land) ctx.arc(X + Wb / 2, Y + Hb - 11 - 25, 24, 0, Math.PI * 2);
    else ctx.arc(X + Wb - 11 - 25, Y + Hb / 2, 24, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = '#22252b';
    ctx.beginPath();
    if (!g.land) ctx.roundRect(X + Wb / 2 - 28, Y + 33, 56, 6, 3); else ctx.roundRect(X + 33, Y + Hb / 2 - 28, 6, 56, 3);
    ctx.fill();
  }
  drawScreen(ctx, g, item, img, opts);
  if (g.kind === 'laptop') {
    const bx = X - Wb * 0.06, bw = Wb * 1.12, by = Y + Hb;
    ctx.fillStyle = cssLinear(ctx, 180, bx, by, bw, 16, [[0, R.c], [1, R.b]]);
    ctx.beginPath(); ctx.roundRect(bx, by, bw, 16, [0, 0, 14, 14]); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,.25)';
    ctx.beginPath(); ctx.roundRect(bx + bw * 0.42, by, bw * 0.16, 5, [0, 0, 8, 8]); ctx.fill();
  }
}

function drawWindow(ctx, g, item, img, opts, dark) {
  ctx.save();
  ctx.beginPath(); ctx.roundRect(0, 0, g.W, g.H, g.bodyR); ctx.clip();
  ctx.fillStyle = dark ? '#1c1f26' : '#eef0f3';
  ctx.fillRect(0, 0, g.W, g.bar);
  ctx.fillStyle = dark ? '#2a2e37' : '#dfe2e7';
  ctx.fillRect(0, g.bar - 1, g.W, 1);
  const r = g.bar * 0.18, cy = g.bar / 2;
  ['#ff5f57', '#febc2e', '#28c840'].forEach((c, i) => {
    ctx.fillStyle = c; ctx.beginPath(); ctx.arc(g.bar * 0.55 + i * r * 3.3, cy, r, 0, Math.PI * 2); ctx.fill();
  });
  const aw = Math.min(g.W * 0.46, 620), ah = g.bar * 0.6;
  ctx.fillStyle = dark ? '#2a2e37' : '#ffffff';
  ctx.beginPath(); ctx.roundRect(g.W / 2 - aw / 2, cy - ah / 2, aw, ah, ah / 2); ctx.fill();
  if (item.host) {
    ctx.fillStyle = dark ? '#9aa3b5' : '#5b6372';
    ctx.font = `500 ${Math.round(ah * 0.5)}px "Inter Tight", system-ui, sans-serif`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(item.host, g.W / 2, cy + 1, aw - ah);
  }
  drawScreen(ctx, g, item, img, opts);
  ctx.restore();
  ctx.strokeStyle = dark ? 'rgba(255,255,255,.12)' : 'rgba(0,0,0,.10)';
  ctx.lineWidth = 1;
  ctx.beginPath(); ctx.roundRect(0.5, 0.5, g.W - 1, g.H - 1, g.bodyR); ctx.stroke();
}

function innerShadow(ctx, g, strength, dark) {
  ctx.save();
  ctx.beginPath(); ctx.roundRect(g.sx, g.sy, g.sw, g.sh, g.r); ctx.clip();
  ctx.shadowColor = dark ? 'rgba(0,0,0,.65)' : `rgba(0,0,0,${0.28 * strength})`;
  ctx.shadowBlur = Math.max(2, g.pad * 0.55);
  ctx.lineWidth = g.pad;
  ctx.strokeStyle = '#000';
  ctx.beginPath(); ctx.roundRect(g.sx - g.pad / 2, g.sy - g.pad / 2, g.sw + g.pad, g.sh + g.pad, addR(g.r, g.pad / 2)); ctx.stroke();
  ctx.restore();
}

function drawScreenOnly(ctx, g, item, img, opts, style) {
  const st = g.kind === 'bare' ? 'default' : style.screenStyle;
  const lw = Math.max(1, Math.min(g.sw, g.sh) * 0.0035);
  if (st === 'glass-light' || st === 'glass-dark') {
    ctx.fillStyle = st === 'glass-light' ? 'rgba(255,255,255,.30)' : 'rgba(10,12,16,.45)';
    ctx.beginPath(); ctx.roundRect(0, 0, g.W, g.H, g.bodyR); ctx.fill();
    ctx.strokeStyle = st === 'glass-light' ? 'rgba(255,255,255,.65)' : 'rgba(255,255,255,.16)';
    ctx.lineWidth = lw;
    ctx.beginPath(); ctx.roundRect(lw / 2, lw / 2, g.W - lw, g.H - lw, g.bodyR); ctx.stroke();
  } else if (st === 'liquid') {
    const gr = ctx.createLinearGradient(0, 0, g.W, g.H);
    gr.addColorStop(0, 'rgba(255,255,255,.42)'); gr.addColorStop(0.5, 'rgba(255,255,255,.10)'); gr.addColorStop(1, 'rgba(255,255,255,.26)');
    ctx.fillStyle = gr;
    ctx.beginPath(); ctx.roundRect(0, 0, g.W, g.H, g.bodyR); ctx.fill();
    const rim = ctx.createLinearGradient(0, 0, g.W, g.H);
    rim.addColorStop(0, 'rgba(255,255,255,.95)'); rim.addColorStop(0.35, 'rgba(255,255,255,.2)'); rim.addColorStop(0.7, 'rgba(255,255,255,.05)'); rim.addColorStop(1, 'rgba(255,255,255,.7)');
    ctx.strokeStyle = rim; ctx.lineWidth = lw * 1.6;
    ctx.beginPath(); ctx.roundRect(lw, lw, g.W - lw * 2, g.H - lw * 2, g.bodyR); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = lw;
    ctx.beginPath(); ctx.roundRect(g.sx - lw * 1.5, g.sy - lw * 1.5, g.sw + lw * 3, g.sh + lw * 3, addR(g.r, lw)); ctx.stroke();
  } else if (st === 'inset-light' || st === 'inset-dark') {
    ctx.fillStyle = st === 'inset-light' ? '#f2f3f5' : '#1b1d23';
    ctx.beginPath(); ctx.roundRect(0, 0, g.W, g.H, g.bodyR); ctx.fill();
    ctx.strokeStyle = st === 'inset-light' ? 'rgba(0,0,0,.08)' : 'rgba(255,255,255,.08)';
    ctx.lineWidth = lw;
    ctx.beginPath(); ctx.roundRect(lw / 2, lw / 2, g.W - lw, g.H - lw, g.bodyR); ctx.stroke();
  } else if (st === 'border') {
    ctx.fillStyle = '#ffffff';
    ctx.beginPath(); ctx.roundRect(0, 0, g.W, g.H, g.bodyR); ctx.fill();
  }
  drawScreen(ctx, g, item, img, opts);
  if (st === 'inset-light' || st === 'inset-dark') innerShadow(ctx, g, 1, st === 'inset-dark');
  if (st === 'outline') {
    ctx.strokeStyle = 'rgba(255,255,255,.6)';
    ctx.lineWidth = lw * 1.4;
    ctx.beginPath(); ctx.roundRect(g.sx, g.sy, g.sw, g.sh, g.r); ctx.stroke();
  }
}

// Renders one device into its own canvas at `k` output pixels per device unit.
export function renderDevice(item, style, img, k, opts = {}) {
  const g = geometry(item, style);
  const cw = Math.max(1, Math.round((g.W + 2 * g.margin) * k));
  const ch = Math.max(1, Math.round((g.H + 2 * g.margin) * k));
  const c = document.createElement('canvas');
  c.width = cw; c.height = ch;
  const ctx = c.getContext('2d');
  ctx.scale(k, k);
  ctx.translate(g.margin, g.margin);
  const o = { glare: style.glare, placeholder: opts.placeholder };
  if (g.kind === 'phone' || g.kind === 'tablet' || g.kind === 'laptop') drawHardware(ctx, g, item, img, o);
  else if (g.kind === 'browser') drawWindow(ctx, g, item, img, o, !!style.dark);
  else drawScreenOnly(ctx, g, item, img, o, style);
  return { canvas: c, g };
}

// ---------- background and effects ----------
function drawBackgroundLayer(ctx, P, W, H, images) {
  const bg = P.bg;
  if (bg.kind === 'transparent') return;
  if (bg.kind === 'image') {
    const img = images.get(bg.image);
    ctx.fillStyle = '#111'; ctx.fillRect(0, 0, W, H);
    if (img) {
      const s = Math.max(W / img.width, H / img.height);
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, (W - img.width * s) / 2, (H - img.height * s) / 2, img.width * s, img.height * s);
    }
    return;
  }
  paintPreset(ctx, resolveBg(bg), W, H, images);
}

// Background with its own effects (blur, noise, vignette), painted in device pixels.
function drawBackground(ctx, P, W, H, sc, images) {
  const fx = P.fx;
  const blur = (fx.blur || 0) / 100 * Math.min(W, H) * 0.06 * sc;
  if (blur > 0.5 && P.bg.kind !== 'transparent') {
    const c = document.createElement('canvas');
    c.width = Math.round(W * sc); c.height = Math.round(H * sc);
    const x = c.getContext('2d');
    x.scale(sc, sc);
    drawBackgroundLayer(x, P, W, H, images);
    ctx.save();
    ctx.filter = `blur(${blur}px)`;
    const o = blur * 2 / sc;
    ctx.drawImage(c, -o, -o, W + o * 2, H + o * 2);
    ctx.restore();
  } else {
    drawBackgroundLayer(ctx, P, W, H, images);
  }
  if (P.bg.kind === 'transparent') return;
  if (fx.vignette > 0) {
    const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.25, W / 2, H / 2, Math.hypot(W, H) * 0.6);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${fx.vignette / 100 * 0.75})`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }
  if (fx.noise > 0) {
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = fx.noise / 100 * 0.22;
    ctx.globalCompositeOperation = 'overlay';
    ctx.fillStyle = ctx.createPattern(noiseTile(), 'repeat');
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.restore();
  }
}

function lightLeak(ctx, W, H, amount) {
  if (!(amount > 0)) return;
  const a = amount / 100;
  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  const D = Math.max(W, H);
  [[0.0, 0.0, 0.7, '#ff7a2d', 0.75], [0.15, 0.05, 0.45, '#ffd36b', 0.55], [1.0, 1.0, 0.55, '#ff3d8b', 0.35]].forEach(([x, y, r, c, k]) => {
    const g = ctx.createRadialGradient(x * W, y * H, 0, x * W, y * H, r * D);
    g.addColorStop(0, rgba(c, k * a)); g.addColorStop(1, rgba(c, 0));
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  });
  ctx.restore();
}

// Scene shadows: soft window and plant shadows over everything.
function sceneOverlay(ctx, P, W, H, sc) {
  const s = P.scene;
  if (!s) return;
  let id = s.shadow;
  if (s.kind === 'blinds') id = 'blinds';
  else if (s.kind === 'leaves') id = 'leaves';
  else if (s.kind !== 'shadow') return;
  drawSceneShadow(ctx, W, H, id || 'blinds', s.amount ?? 60, s.soft ?? 50, !!s.flip, sc);
}

function sceneShapes(ctx, P, W, H, box) {
  if (P.scene?.kind !== 'shapes') return;
  const pal = ['#c6f432', '#8b6cff', '#ff6ec4', '#36c5ff'];
  const D = Math.min(W, H);
  const spots = [[box.x + box.w * 0.1, box.y + box.h * 0.15, 0.13], [box.x + box.w * 0.92, box.y + box.h * 0.35, 0.09], [box.x + box.w * 0.18, box.y + box.h * 0.9, 0.07], [box.x + box.w * 0.85, box.y + box.h * 0.88, 0.11]];
  const a = (P.scene.amount ?? 60) / 100;
  spots.forEach(([x, y, r], i) => {
    const R = r * D * (0.6 + a * 0.6);
    const col = pal[i % pal.length];
    const g = ctx.createRadialGradient(x - R * 0.35, y - R * 0.4, R * 0.05, x, y, R);
    g.addColorStop(0, shade(col, 0.6)); g.addColorStop(0.5, col); g.addColorStop(1, shade(col, -0.45));
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,.3)'; ctx.shadowBlur = R * 0.5; ctx.shadowOffsetY = R * 0.25;
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x, y, R, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  });
}

// ---------- text ----------
function wrap(ctx, text, maxW) {
  const out = [];
  for (const para of String(text || '').split('\n')) {
    const words = para.split(/\s+/).filter(Boolean);
    let line = '';
    for (const w of words) {
      const t = line ? `${line} ${w}` : w;
      if (ctx.measureText(t).width > maxW && line) { out.push(line); line = w; } else line = t;
    }
    if (line) out.push(line);
  }
  return out;
}
export const FONTS = [
  { id: 'hubot', name: 'Hubot Sans', family: '"Hubot Sans"', max: 900 },
  { id: 'inter', name: 'Inter Tight', family: '"Inter Tight"', max: 900 },
  { id: 'bricolage', name: 'Bricolage', family: '"Bricolage Grotesque"', max: 800 },
  { id: 'jakarta', name: 'Plus Jakarta', family: '"Plus Jakarta Sans"', max: 800 },
  { id: 'space', name: 'Space Grotesk', family: '"Space Grotesk"', max: 700 },
  { id: 'sora', name: 'Sora', family: '"Sora"', max: 800 },
  { id: 'outfit', name: 'Outfit', family: '"Outfit"', max: 900 },
  { id: 'playfair', name: 'Playfair', family: '"Playfair Display"', max: 900 },
  { id: 'dmserif', name: 'DM Serif', family: '"DM Serif Display"', max: 400, fixed: true },
  { id: 'instrument', name: 'Instrument Serif', family: '"Instrument Serif"', max: 400, fixed: true },
  { id: 'mono', name: 'JetBrains Mono', family: '"JetBrains Mono"', max: 800 },
  { id: 'caveat', name: 'Caveat', family: '"Caveat"', max: 700 },
  { id: 'system', name: 'System', family: 'system-ui, -apple-system, "Segoe UI"', max: 900 },
  { id: 'georgia', name: 'Georgia', family: 'Georgia, "Times New Roman", serif', max: 700 }
];
const FONT_BY_ID = Object.fromEntries(FONTS.map((f) => [f.id, f]));
export function fontCss(id, weight, px) {
  const f = FONT_BY_ID[id] || FONT_BY_ID.hubot;
  const w = f.fixed ? 400 : Math.min(weight || 700, f.max);
  return `${w} ${px}px ${f.family}, "Inter Tight", system-ui, sans-serif`;
}

function layoutText(ctx, P, W, H) {
  const t = P.text;
  if (!t || !t.on || (!t.title && !t.sub)) return null;
  const base = Math.min(W, H * 0.9);
  const ts = base * (t.size || 7) / 100;
  const ss = ts * (t.subRatio || 0.42);
  const maxW = W * 0.84;
  ctx.font = fontCss(t.font || 'hubot', t.weight || 800, ts);
  const tl = t.title ? wrap(ctx, t.title, maxW) : [];
  ctx.font = fontCss(t.subFont || 'inter', 500, ss);
  const sl = t.sub ? wrap(ctx, t.sub, maxW) : [];
  const lh = t.font === 'caveat' || t.font === 'instrument' ? 1.0 : 1.08;
  const th = tl.length * ts * lh;
  const sh = sl.length * ss * 1.35;
  const gap = tl.length && sl.length ? ts * 0.35 : 0;
  return { tl, sl, ts, ss, th, sh, gap, lh, h: th + gap + sh };
}
function drawText(ctx, P, W, H, block, top) {
  const t = P.text;
  const ink = t.color && t.color !== 'auto' ? t.color : autoInk(P.bg);
  const align = t.align || 'center';
  const x = align === 'left' ? W * 0.08 : align === 'right' ? W * 0.92 : W / 2;
  ctx.textAlign = align;
  ctx.textBaseline = 'top';
  ctx.fillStyle = ink;
  let y = top;
  ctx.font = fontCss(t.font || 'hubot', t.weight || 800, block.ts);
  for (const l of block.tl) { ctx.fillText(l, x, y); y += block.ts * block.lh; }
  y += block.gap;
  ctx.globalAlpha = 0.78;
  ctx.font = fontCss(t.subFont || 'inter', 500, block.ss);
  for (const l of block.sl) { ctx.fillText(l, x, y); y += block.ss * 1.35; }
  ctx.globalAlpha = 1;
}

// ---------- watermark ----------
export const WM_STYLES = [{ id: 'default', name: 'Default' }, { id: 'shadow', name: 'Shadow' }, { id: 'glass', name: 'Glass' }, { id: 'badge', name: 'Badge' }];
export function drawWatermark(ctx, W, H, wm, logo) {
  const text = wm.text || '';
  if (!text && !logo) return;
  const style = wm.style || 'badge';
  const dark = wm.tone === 'dark';
  const fs = Math.min(W, H) * 0.026 * (wm.size ?? 100) / 100;
  ctx.save();
  ctx.font = `600 ${fs}px "Inter Tight", system-ui, sans-serif`;
  const tw = text ? ctx.measureText(text).width : 0;
  const ls = logo ? fs * 1.45 : 0;
  const gap = logo && text ? fs * 0.5 : 0;
  const boxed = style === 'glass' || style === 'badge';
  const px = boxed ? fs * (text ? 0.8 : 0.45) : 0, py = boxed ? fs * 0.45 : 0;
  const cw = ls + gap + tw + px * 2, ch = Math.max(ls, fs * 1.3) + py * 2;
  const inset = Math.min(W, H) * (wm.inset ?? 4) / 100;
  const pos = wm.pos || 'br';
  const v = pos[0], h = pos[1];
  const x = h === 'l' ? inset : h === 'c' ? (W - cw) / 2 : W - cw - inset;
  const y = v === 't' ? inset : v === 'm' ? (H - ch) / 2 : H - ch - inset;
  ctx.globalAlpha = (wm.opacity ?? 100) / 100;
  const ink = style === 'badge' ? (dark ? '#ffffff' : '#0d1016') : (dark ? '#0d1016' : '#ffffff');
  if (style === 'badge') {
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,.25)'; ctx.shadowBlur = fs * 0.8; ctx.shadowOffsetY = fs * 0.2;
    ctx.fillStyle = dark ? '#111318' : '#ffffff';
    ctx.beginPath(); ctx.roundRect(x, y, cw, ch, ch / 2); ctx.fill();
    ctx.restore();
  } else if (style === 'glass') {
    ctx.fillStyle = dark ? 'rgba(10,12,16,.32)' : 'rgba(255,255,255,.2)';
    ctx.beginPath(); ctx.roundRect(x, y, cw, ch, ch / 2); ctx.fill();
    ctx.strokeStyle = dark ? 'rgba(255,255,255,.14)' : 'rgba(255,255,255,.55)'; ctx.lineWidth = Math.max(1, fs * 0.06);
    ctx.beginPath(); ctx.roundRect(x, y, cw, ch, ch / 2); ctx.stroke();
  }
  if (style === 'shadow') { ctx.shadowColor = dark ? 'rgba(255,255,255,.55)' : 'rgba(0,0,0,.55)'; ctx.shadowBlur = fs * 0.7; ctx.shadowOffsetY = fs * 0.08; }
  let cx = x + px;
  if (logo) {
    const ly = y + (ch - ls) / 2;
    ctx.save();
    ctx.beginPath(); ctx.roundRect(cx, ly, ls, ls, ls * 0.24); ctx.clip();
    const s = Math.max(ls / logo.width, ls / logo.height);
    ctx.drawImage(logo, cx + (ls - logo.width * s) / 2, ly + (ls - logo.height * s) / 2, logo.width * s, logo.height * s);
    ctx.restore();
    cx += ls + gap;
  }
  if (text) {
    ctx.fillStyle = ink;
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(text, cx, y + ch / 2 + fs * 0.04);
  }
  ctx.restore();
}

// ---------- shadows ----------
// Draws only the shadow of `src` (never the image itself): the silhouette is drawn far off
// the canvas and the shadow is offset back into view, as in Shotcandy's renderer.
function drawShadow(ctx, src, x, y, w, h, P, ST, devPx, alphaScale) {
  const sh = SHADOW_BY_ID[ST.shadow] || SHADOW_BY_ID.soft;
  if (!sh.layers.length) return;
  const unit = devPx / 1000;
  const op = ST.shadowOpacity ?? 1;
  const ang = (ST.light ?? 90) * Math.PI / 180;
  const dist = ST.lightDist ?? 1;
  const col = sh.adaptive ? (P.bg.palette?.[1] || P.bg.palette?.[0] || '#5a3cff') : '#000000';
  const m = ctx.getTransform();
  const OFF = 40000;
  for (const [lx, ly, blur, spread, o] of sh.layers) {
    const L = Math.hypot(lx, ly) * dist * unit;
    const base = Math.atan2(ly, lx) - Math.PI / 2;
    const ox = L * Math.cos(ang + base), oy = L * Math.sin(ang + base);
    const sp = spread * unit / Math.max(1, devPx) ;
    const kx = 1 + 2 * sp, ky = 1 + 2 * sp * (devPx / Math.max(1, devPx));
    ctx.save();
    ctx.shadowColor = rgba(col, Math.min(1, o * op * alphaScale));
    ctx.shadowBlur = blur * unit;
    ctx.shadowOffsetX = m.a * OFF + ox;
    ctx.shadowOffsetY = m.b * OFF + oy;
    const ww = w * kx, hh = h * ky;
    ctx.drawImage(src, x - (ww - w) / 2 - OFF, y - (hh - h) / 2, ww, hh);
    ctx.restore();
  }
}

// ---------- scene ----------
export function stageBox(ctx, P, W, H) {
  const pad = Math.min(W, H) * (P.padding ?? 8) / 100;
  const block = layoutText(ctx, P, W, H);
  let top = pad, bottom = H - pad;
  let textTop = 0;
  if (block) {
    const gap = Math.min(W, H) * 0.04;
    if ((P.text.pos || 'top') === 'top') { textTop = pad; top = pad + block.h + gap; }
    else { textTop = H - pad - block.h; bottom = textTop - gap; }
  }
  return { x: pad, y: top, w: W - pad * 2, h: Math.max(10, bottom - top), block, textTop };
}

export function cameraOf(P) {
  const c = P.camera || { zoom: 1, fx: 0.5, fy: 0.5, rx: 0, ry: 0 };
  const z = Math.max(1, c.zoom || 1);
  const half = 1 / (2 * z);
  return { z, fx: clampN(c.fx ?? 0.5, half, 1 - half), fy: clampN(c.fy ?? 0.5, half, 1 - half), rx: c.rx || 0, ry: c.ry || 0 };
}

// P = project, images = Map(id -> drawable). opts.scale = output pixels per project pixel.
// Returns hit areas (quads in project pixels) for each item.
export function renderScene(ctx, P, images, opts = {}) {
  const W = P.size.w, H = P.size.h;
  const sc = opts.scale || 1;
  const ST = styleOf(P);
  ctx.save();
  ctx.scale(sc, sc);
  drawBackground(ctx, P, W, H, sc, images);
  const box = stageBox(ctx, P, W, H);
  const cam = cameraOf(P);
  const camMap = ([x, y]) => [(x - cam.fx * W) * cam.z + W / 2, (y - cam.fy * H) * cam.z + H / 2];

  ctx.save();
  ctx.translate(W / 2 - cam.fx * W * cam.z, H / 2 - cam.fy * H * cam.z);
  ctx.scale(cam.z, cam.z);
  sceneShapes(ctx, P, W, H, box);

  const hits = [];
  const order = P.items.map((it, i) => ({ it, i })).sort((a, b) => (a.it.z || 0) - (b.it.z || 0));
  for (const { it, i } of order) {
    const g0 = geometry(it, ST);
    const ow = g0.W + 2 * g0.margin, oh = g0.H + 2 * g0.margin;
    const k = Math.min(box.w * (it.share || 1) * it.s / g0.W, box.h * it.s / g0.H);
    if (!(k > 0)) continue;
    const img = images.get(mediaOf(it, ST).id) || null;
    const kk = Math.min(k * sc * cam.z, 6000 / Math.max(ow, oh));
    const { canvas } = renderDevice(it, ST, img, kk, { placeholder: opts.placeholder });
    let src = canvas, dw = ow * k, dh = oh * k, offx = 0, offy = 0;
    const rx = (it.rx || 0) + cam.rx, ry = (it.ry || 0) + cam.ry, rz = it.rz || 0;
    if (rx || ry || rz) {
      const wr = warp(canvas, rx, ry, rz);
      if (wr) {
        src = wr.canvas;
        const f = k / kk;
        dw = wr.w * f; dh = wr.h * f; offx = wr.cx * f; offy = wr.cy * f;
      }
    }
    const cx = box.x + box.w * it.cx, cy = box.y + box.h * it.cy;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate((it.rot || 0) * Math.PI / 180);
    const devPx = g0.H * k * sc * cam.z;
    if (it.blur) ctx.filter = `blur(${it.blur / 100 * devPx * 0.02}px)`;
    if (it.fade) ctx.globalAlpha = 1 - it.fade;
    // If the shadow source is the shared WebGL canvas, copy it first: drawing several layers
    // must not race with the next warp.
    let shadowSrc = src;
    if (src !== canvas) {
      const copy = document.createElement('canvas');
      copy.width = src.width; copy.height = src.height;
      copy.getContext('2d').drawImage(src, 0, 0);
      shadowSrc = src = copy;
    }
    drawShadow(ctx, shadowSrc, offx - dw / 2, offy - dh / 2, dw, dh, P, ST, devPx, 1);
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, offx - dw / 2, offy - dh / 2, dw, dh);
    ctx.restore();
    const a = (it.rot || 0) * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
    const quad = [[-dw / 2, -dh / 2], [dw / 2, -dh / 2], [dw / 2, dh / 2], [-dw / 2, dh / 2]]
      .map(([x, y]) => camMap([cx + (x + offx) * ca - (y + offy) * sa, cy + (x + offx) * sa + (y + offy) * ca]));
    hits[i] = { quad, box, z: cam.z };
  }
  // The headline belongs to the scene, so it moves and scales with the camera: zooming in
  // on a device pushes the text out of the frame instead of leaving it over the screen.
  if (box.block) drawText(ctx, P, W, H, box.block, box.textTop);
  ctx.restore();

  sceneOverlay(ctx, P, W, H, sc);
  lightLeak(ctx, W, H, P.fx.leak);
  if (P.fx.wm?.on) drawWatermark(ctx, W, H, P.fx.wm, P.fx.wm.logo ? images.get(P.fx.wm.logo) : null);
  if (opts.watermark) drawWatermark(ctx, W, H, { text: 'Made with PocketView', style: 'badge', tone: 'dark', pos: 'br', size: 66, inset: 2.5, opacity: 88 }, images.get('__pvlogo'));
  ctx.restore();
  return hits;
}

// ---------- layouts ----------
// Positions are fractions of the stage box. s = size relative to the box.
const L = (cx, cy, s, extra = {}) => ({ cx, cy, s, rot: 0, rx: 0, ry: 0, rz: 0, z: 0, blur: 0, ...extra });
export const LAYOUTS = {
  1: [
    { id: 'center', name: 'Center', items: [L(0.5, 0.5, 0.92)] },
    { id: 'lean', name: 'Lean', items: [L(0.5, 0.52, 0.84, { rot: -9 })] },
    { id: 'rise', name: 'Rise', items: [L(0.5, 0.82, 1.25)] },
    { id: 'rise-more', name: 'Rise more', items: [L(0.5, 1.02, 1.6)] },
    { id: 'drop', name: 'Drop', items: [L(0.5, 0.2, 1.25)] },
    { id: 'drop-more', name: 'Drop more', items: [L(0.5, 0.0, 1.6)] },
    { id: 'tilt-left', name: 'Tilt left', items: [L(0.5, 0.5, 0.86, { rx: 10, ry: 28 })] },
    { id: 'tilt-right', name: 'Tilt right', items: [L(0.5, 0.5, 0.86, { rx: 10, ry: -28 })] },
    { id: 'float', name: 'Float', items: [L(0.5, 0.5, 0.86, { rx: 34 })] },
    { id: 'iso', name: 'Isometric', items: [L(0.5, 0.5, 0.7, { rz: 38, rx: 52 })] }
  ],
  2: [
    { id: 'side', name: 'Side by side', items: [L(0.28, 0.5, 0.9), L(0.72, 0.5, 0.9)] },
    { id: 'stagger', name: 'Stagger', items: [L(0.28, 0.42, 0.84), L(0.72, 0.58, 0.84)] },
    { id: 'overlap', name: 'Overlap', items: [L(0.38, 0.45, 0.86), L(0.62, 0.57, 0.86, { z: 1 })] },
    { id: 'lean-pair', name: 'Lean pair', items: [L(0.36, 0.5, 0.88, { rot: -7 }), L(0.64, 0.5, 0.88, { rot: -7, z: 1 })] },
    { id: 'cross', name: 'Cross', items: [L(0.37, 0.44, 0.86, { rot: -10 }), L(0.63, 0.58, 0.86, { rot: 8, z: 1 })] },
    { id: 'depth', name: 'Depth', items: [L(0.36, 0.44, 0.72, { blur: 60, z: 0 }), L(0.6, 0.55, 0.92, { z: 1 })] },
    { id: 'pair-tilt', name: 'Tilted pair', items: [L(0.3, 0.5, 0.86, { rx: 8, ry: 26 }), L(0.7, 0.5, 0.86, { rx: 8, ry: 26 })] },
    { id: 'mirror', name: 'Mirror', items: [L(0.3, 0.5, 0.86, { ry: 24 }), L(0.7, 0.5, 0.86, { ry: -24 })] }
  ],
  3: [
    { id: 'row', name: 'Row', items: [L(0.18, 0.5, 0.86), L(0.5, 0.5, 0.86), L(0.82, 0.5, 0.86)] },
    { id: 'stairs', name: 'Stairs', items: [L(0.18, 0.58, 0.82), L(0.5, 0.5, 0.82), L(0.82, 0.42, 0.82)] },
    { id: 'fan', name: 'Fan', items: [L(0.24, 0.56, 0.78, { rot: -12 }), L(0.76, 0.56, 0.78, { rot: 12 }), L(0.5, 0.48, 0.88, { z: 2 })] },
    { id: 'lean-trio', name: 'Lean trio', items: [L(0.27, 0.54, 0.84, { rot: -8 }), L(0.5, 0.5, 0.84, { rot: -8, z: 1 }), L(0.73, 0.46, 0.84, { rot: -8, z: 2 })] },
    { id: 'cascade', name: 'Cascade', items: [L(0.3, 0.38, 0.76, { rot: -14 }), L(0.5, 0.5, 0.76, { rot: -14, z: 1 }), L(0.7, 0.62, 0.76, { rot: -14, z: 2 })] },
    { id: 'depth', name: 'Depth', items: [L(0.22, 0.5, 0.7, { blur: 55 }), L(0.78, 0.5, 0.7, { blur: 55 }), L(0.5, 0.5, 0.94, { z: 2 })] },
    { id: 'row-tilt', name: 'Tilted row', items: [L(0.2, 0.5, 0.84, { rx: 8, ry: 26 }), L(0.5, 0.5, 0.84, { rx: 8, ry: 26, z: 1 }), L(0.8, 0.5, 0.84, { rx: 8, ry: 26, z: 2 })] }
  ]
};

// Multi-device layouts share the stage, so each device gets a slot of the width.
export function applyLayout(P, layout) {
  const n = P.items.length;
  layout.items.forEach((l, i) => {
    const it = P.items[i];
    if (!it) return;
    const share = n === 1 ? 1 : n === 2 ? 0.5 : 0.34;
    Object.assign(it, { cx: l.cx, cy: l.cy, rot: l.rot, rx: l.rx, ry: l.ry, rz: l.rz || 0, z: l.z, s: l.s, blur: l.blur || 0, share });
  });
  P.layout = layout.id;
}
