// Scene shadows for Studio: soft window and plant shadows laid over the whole picture.
// Everything is drawn procedurally (black shapes on white), then blurred and multiplied.

export const SHADOW_SCENES = [
  { id: 'blinds', name: 'Blinds' },
  { id: 'blinds-wide', name: 'Wide blinds' },
  { id: 'blinds-steep', name: 'Steep blinds' },
  { id: 'window', name: 'Window' },
  { id: 'window-tall', name: 'Tall window' },
  { id: 'window-skew', name: 'Slanted window' },
  { id: 'lattice', name: 'Lattice' },
  { id: 'branch', name: 'Branch' },
  { id: 'leaves', name: 'Leaves' },
  { id: 'big-leaves', name: 'Big leaves' },
  { id: 'twigs', name: 'Twigs' },
  { id: 'palm', name: 'Palm' },
  { id: 'palms', name: 'Palms' },
  { id: 'fern', name: 'Fern' },
  { id: 'monstera', name: 'Monstera' },
  { id: 'bamboo', name: 'Bamboo' },
  { id: 'grass', name: 'Grass' },
  { id: 'dapple', name: 'Dappled light' }
];

function rng(seed) {
  let t = seed >>> 0;
  return () => { t += 0x6d2b79f5; let r = Math.imul(t ^ (t >>> 15), 1 | t); r ^= r + Math.imul(r ^ (r >>> 7), 61 | r); return ((r ^ (r >>> 14)) >>> 0) / 4294967296; };
}

function leaf(x, cx, cy, len, wid, ang) {
  x.save(); x.translate(cx, cy); x.rotate(ang);
  x.beginPath();
  x.moveTo(0, 0);
  x.quadraticCurveTo(len * 0.45, -wid, len, 0);
  x.quadraticCurveTo(len * 0.45, wid, 0, 0);
  x.fill();
  x.restore();
}
function stem(x, pts, w) {
  x.lineWidth = w; x.lineCap = 'round'; x.lineJoin = 'round';
  x.beginPath(); pts.forEach(([a, b], i) => (i ? x.lineTo(a, b) : x.moveTo(a, b))); x.stroke();
}
// A curved branch from (x0,y0) heading `ang`, with leaves along it.
function branch(x, r, x0, y0, ang, len, leafLen, leafW, count, bend = 0.4) {
  const pts = [];
  for (let i = 0; i <= 20; i++) {
    const t = i / 20;
    const a = ang + bend * t * t;
    pts.push([x0 + Math.cos(a) * len * t, y0 + Math.sin(a) * len * t]);
  }
  stem(x, pts, Math.max(1, leafW * 0.18));
  for (let i = 1; i <= count; i++) {
    const t = i / (count + 1);
    const [px, py] = pts[Math.round(t * 20)];
    const side = i % 2 ? 1 : -1;
    const a = ang + bend * t * t + side * (0.7 + r() * 0.5);
    leaf(x, px, py, leafLen * (0.75 + r() * 0.5), leafW * (0.8 + r() * 0.4), a);
  }
}

// Paints scene `id` in black on a white canvas of size w x h.
function paint(x, id, w, h) {
  const r = rng(id.length * 977 + 13);
  const D = Math.max(w, h);
  x.fillStyle = '#fff'; x.fillRect(0, 0, w, h);
  x.fillStyle = '#000'; x.strokeStyle = '#000';
  const bars = (angle, gap, thick) => {
    x.save(); x.translate(w / 2, h / 2); x.rotate(angle);
    for (let y = -D; y < D; y += gap) x.fillRect(-D, y, D * 2, thick);
    x.restore();
  };
  switch (id) {
    case 'blinds': bars(-0.55, D * 0.07, D * 0.035); break;
    case 'blinds-wide': bars(-0.42, D * 0.19, D * 0.08); break;
    case 'blinds-steep': bars(-1.05, D * 0.09, D * 0.04); break;
    case 'window': {
      x.save(); x.translate(w * 0.62, h * 0.4); x.rotate(-0.18);
      const s = D * 0.95, f = D * 0.035;
      x.fillRect(-s, -s, s * 2, f); x.fillRect(-s, s * 0.05, s * 2, f);
      x.fillRect(-s * 0.02, -s, f, s * 2); x.fillRect(-s * 0.55, -s, f, s * 2); x.fillRect(s * 0.5, -s, f, s * 2);
      x.restore();
      break;
    }
    case 'window-tall': {
      x.fillRect(0, 0, w * 0.18, h);
      for (let i = 0; i < 4; i++) x.fillRect(w * (0.18 + i * 0.2), 0, D * 0.02, h);
      for (let i = 1; i < 4; i++) x.fillRect(w * 0.18, h * i * 0.27, w, D * 0.02);
      x.fillRect(w * 0.95, 0, w * 0.05, h);
      break;
    }
    case 'window-skew': {
      x.save(); x.transform(1, 0.25, -0.6, 1, w * 0.2, -h * 0.1);
      const f = D * 0.03;
      for (let i = 0; i < 6; i++) x.fillRect(i * D * 0.22, -D, f, D * 3);
      for (let i = 0; i < 5; i++) x.fillRect(-D, i * D * 0.26, D * 3, f);
      x.restore();
      break;
    }
    case 'lattice': {
      x.save(); x.translate(w / 2, h / 2);
      for (const a of [0.78, -0.78]) { x.save(); x.rotate(a); for (let y = -D; y < D; y += D * 0.12) x.fillRect(-D, y, D * 2, D * 0.02); x.restore(); }
      x.restore();
      break;
    }
    case 'branch': branch(x, r, w * 1.02, h * 0.05, Math.PI * 0.85, D * 0.95, D * 0.17, D * 0.055, 12, -0.5); break;
    case 'leaves': {
      for (let i = 0; i < 6; i++) branch(x, r, w * (0.75 + r() * 0.35), -h * 0.05 + r() * h * 0.2, Math.PI * (0.55 + r() * 0.35), D * (0.4 + r() * 0.3), D * 0.1, D * 0.036, 8, 0.6);
      break;
    }
    case 'big-leaves': {
      for (let i = 0; i < 7; i++) leaf(x, w * (0.7 + r() * 0.4), h * r() * 0.6, D * (0.25 + r() * 0.15), D * (0.07 + r() * 0.04), Math.PI * (0.6 + r() * 0.6));
      break;
    }
    case 'twigs': {
      const grow = (px, py, a, len, depth) => {
        if (depth === 0 || len < 2) { leaf(x, px, py, D * 0.045, D * 0.017, a); return; }
        const nx = px + Math.cos(a) * len, ny = py + Math.sin(a) * len;
        stem(x, [[px, py], [nx, ny]], Math.max(1, depth * D * 0.0035));
        grow(nx, ny, a - 0.35 - r() * 0.3, len * 0.72, depth - 1);
        grow(nx, ny, a + 0.3 + r() * 0.3, len * 0.68, depth - 1);
      };
      grow(w * 1.05, h * 0.0, Math.PI * 0.75, D * 0.22, 7);
      grow(w * 1.05, h * 0.45, Math.PI * 0.95, D * 0.18, 6);
      break;
    }
    case 'palm': case 'palms': {
      const frond = (px, py, a, len) => {
        const pts = [];
        for (let i = 0; i <= 24; i++) { const t = i / 24; pts.push([px + Math.cos(a + 0.35 * t) * len * t, py + Math.sin(a + 0.35 * t) * len * t]); }
        stem(x, pts, D * 0.012);
        for (let i = 2; i <= 24; i++) {
          const t = i / 24; const [qx, qy] = pts[i]; const ll = len * 0.32 * Math.sin(Math.PI * t) + len * 0.05;
          leaf(x, qx, qy, ll, D * 0.016, a + 0.35 * t + 0.9); leaf(x, qx, qy, ll, D * 0.016, a + 0.35 * t - 0.9);
        }
      };
      frond(w * 1.08, h * 0.02, Math.PI * 0.82, D * 0.85);
      if (id === 'palms') { frond(w * 1.05, h * 0.7, Math.PI * 1.08, D * 0.7); frond(w * 0.85, -h * 0.08, Math.PI * 0.6, D * 0.6); }
      break;
    }
    case 'fern': {
      for (let k = 0; k < 3; k++) {
        const px = w * (0.8 + k * 0.1), py = -h * 0.05 + k * h * 0.15, a = Math.PI * (0.65 + k * 0.08), len = D * (0.7 - k * 0.1);
        const pts = [];
        for (let i = 0; i <= 30; i++) { const t = i / 30; pts.push([px + Math.cos(a + 0.5 * t) * len * t, py + Math.sin(a + 0.5 * t) * len * t]); }
        stem(x, pts, D * 0.008);
        for (let i = 1; i <= 30; i++) { const t = i / 30; const [qx, qy] = pts[i]; const ll = D * 0.09 * (1 - t * 0.75); leaf(x, qx, qy, ll, ll * 0.3, a + 0.5 * t + 1.2); leaf(x, qx, qy, ll, ll * 0.3, a + 0.5 * t - 1.2); }
      }
      break;
    }
    case 'monstera': {
      for (let i = 0; i < 4; i++) {
        const cx = w * (0.72 + r() * 0.35), cy = h * (r() * 0.7), R = D * (0.14 + r() * 0.08);
        x.beginPath(); x.ellipse(cx, cy, R, R * 0.8, r() * Math.PI, 0, Math.PI * 2); x.fill();
        x.save(); x.globalCompositeOperation = 'destination-out';
        for (let k = 0; k < 7; k++) { const a = k / 7 * Math.PI * 2; x.beginPath(); x.ellipse(cx + Math.cos(a) * R * 0.75, cy + Math.sin(a) * R * 0.6, R * 0.28, R * 0.07, a, 0, Math.PI * 2); x.fill(); }
        x.restore();
        x.fillStyle = '#fff'; x.globalCompositeOperation = 'destination-over'; x.fillRect(0, 0, w, h); x.globalCompositeOperation = 'source-over'; x.fillStyle = '#000';
      }
      break;
    }
    case 'bamboo': {
      for (let i = 0; i < 4; i++) {
        const bx = w * (0.65 + i * 0.1), lean = (r() - 0.5) * 0.15;
        stem(x, [[bx, h * 1.1], [bx + lean * h, -h * 0.1]], D * 0.018);
        for (let k = 0; k < 4; k++) { const ky = h * (0.15 + k * 0.22); const kx = bx + lean * (h * 1.1 - ky) / 1.2; leaf(x, kx, ky, D * 0.2, D * 0.03, Math.PI * (0.85 + r() * 0.25)); }
      }
      break;
    }
    case 'grass': {
      for (let i = 0; i < 70; i++) {
        const gx = r() * w, gh = h * (0.25 + r() * 0.45), bend = (r() - 0.5) * 0.6;
        x.beginPath(); x.moveTo(gx - D * 0.006, h); x.quadraticCurveTo(gx + bend * gh * 0.5, h - gh * 0.6, gx + bend * gh, h - gh); x.quadraticCurveTo(gx + bend * gh * 0.4, h - gh * 0.5, gx + D * 0.006, h); x.fill();
      }
      break;
    }
    case 'dapple': {
      x.fillStyle = '#000'; x.fillRect(0, 0, w, h);
      x.fillStyle = '#fff';
      for (let i = 0; i < 26; i++) { x.beginPath(); x.ellipse(r() * w, r() * h, D * (0.02 + r() * 0.06), D * (0.015 + r() * 0.04), r() * Math.PI, 0, Math.PI * 2); x.fill(); }
      x.globalAlpha = 0.55; x.fillRect(0, 0, w, h); x.globalAlpha = 1;
      break;
    }
    default: bars(-0.55, D * 0.07, D * 0.035);
  }
}

const cache = new Map();
function scene(id, aspect) {
  const key = `${id}|${aspect.toFixed(2)}`;
  if (cache.has(key)) return cache.get(key);
  const w = aspect >= 1 ? 360 : Math.round(360 * aspect), h = aspect >= 1 ? Math.round(360 / aspect) : 360;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  paint(c.getContext('2d'), id, w, h);
  cache.set(key, c);
  if (cache.size > 60) cache.delete(cache.keys().next().value);
  return c;
}

// Multiplies the shadow over everything already drawn on ctx (W x H project units).
export function drawSceneShadow(ctx, W, H, id, amount = 60, softness = 50, flip = false, scale = 1) {
  const src = scene(id, W / H);
  ctx.save();
  ctx.globalCompositeOperation = 'multiply';
  ctx.globalAlpha = Math.max(0, Math.min(1, amount / 100)) * 0.7;
  ctx.filter = `blur(${Math.max(W, H) * scale * (0.002 + softness / 100 * 0.012)}px)`;
  ctx.imageSmoothingQuality = 'high';
  if (flip) { ctx.translate(W, 0); ctx.scale(-1, 1); }
  ctx.drawImage(src, 0, 0, W, H);
  ctx.restore();
}
