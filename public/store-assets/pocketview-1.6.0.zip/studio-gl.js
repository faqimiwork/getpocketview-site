// Perspective tilt for Studio: maps a flat canvas onto a 3D-rotated plane with WebGL,
// so textures stay sharp and correctly foreshortened at any export size.

let gl = null, glCanvas = null, prog = null, buf = null, tex = null, isGL2 = false;

const VS = `
attribute vec4 aPos;
attribute vec2 aUv;
varying vec2 vUv;
void main() { gl_Position = aPos; vUv = aUv; }`;
const FS = `
precision highp float;
varying vec2 vUv;
uniform sampler2D uTex;
void main() { gl_FragColor = texture2D(uTex, vUv); }`;

function init() {
  if (gl) return true;
  glCanvas = document.createElement('canvas');
  const attrs = { alpha: true, premultipliedAlpha: true, antialias: true, preserveDrawingBuffer: true };
  gl = glCanvas.getContext('webgl2', attrs);
  isGL2 = !!gl;
  if (!gl) gl = glCanvas.getContext('webgl', attrs);
  if (!gl) return false;
  const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; };
  prog = gl.createProgram();
  gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS));
  gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS));
  gl.linkProgram(prog);
  buf = gl.createBuffer();
  tex = gl.createTexture();
  return true;
}

const rad = (d) => d * Math.PI / 180;

// rx: tilt around the horizontal axis (top away from viewer when positive)
// ry: turn around the vertical axis (right side away from viewer when positive)
// Returns { canvas, w, h, cx, cy } where cx/cy is the offset of the result's centre
// from the source centre, in source pixels. The canvas is reused: draw it right away.
export function warp(src, rxDeg, ryDeg, rzDeg = 0, persp = 1.8) {
  if (!init()) return null;
  const w = src.width, h = src.height;
  const D = persp * Math.max(w, h);
  const ax = rad(rxDeg), ay = rad(ryDeg);
  const cxs = Math.cos(ax), sxs = Math.sin(ax), cy = Math.cos(ay), sy = Math.sin(ay);
  const az = rad(rzDeg), cz = Math.cos(az), sz = Math.sin(az);
  const corners = [[-w / 2, -h / 2, 0, 0], [w / 2, -h / 2, 1, 0], [-w / 2, h / 2, 0, 1], [w / 2, h / 2, 1, 1]];
  const proj = corners.map(([x0, y0, u, v]) => {
    // spin in the screen plane first (for isometric looks), then tilt.
    const x = x0 * cz - y0 * sz, y = x0 * sz + y0 * cz;
    // rotate around X, then Y. z grows toward the viewer.
    const y1 = y * cxs;
    const z1 = y * sxs;
    const x2 = x * cy - z1 * sy;
    const z2 = x * sy + z1 * cy;
    const f = D / (D + z2);
    return { x: x2 * f, y: y1 * f, wq: 1 / f, u, v };
  });
  const minX = Math.min(...proj.map((p) => p.x)), maxX = Math.max(...proj.map((p) => p.x));
  const minY = Math.min(...proj.map((p) => p.y)), maxY = Math.max(...proj.map((p) => p.y));
  let bw = maxX - minX, bh = maxY - minY;
  // Keep inside GPU limits.
  const maxSide = Math.min(gl.getParameter(gl.MAX_RENDERBUFFER_SIZE) || 4096, 8192);
  const fit = Math.min(1, maxSide / Math.max(bw, bh));
  const cw = Math.max(1, Math.ceil(bw * fit)), ch = Math.max(1, Math.ceil(bh * fit));
  glCanvas.width = cw; glCanvas.height = ch;
  gl.viewport(0, 0, cw, ch);
  gl.clearColor(0, 0, 0, 0);
  gl.clear(gl.COLOR_BUFFER_BIT);

  const mx = (minX + maxX) / 2, my = (minY + maxY) / 2;
  const data = new Float32Array(proj.flatMap((p) => {
    const nx = (p.x - mx) / (bw / 2), ny = -(p.y - my) / (bh / 2);
    return [nx * p.wq, ny * p.wq, 0, p.wq, p.u, p.v];
  }));
  gl.useProgram(prog);
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, data, gl.DYNAMIC_DRAW);
  const aPos = gl.getAttribLocation(prog, 'aPos'), aUv = gl.getAttribLocation(prog, 'aUv');
  gl.enableVertexAttribArray(aPos);
  gl.vertexAttribPointer(aPos, 4, gl.FLOAT, false, 24, 0);
  gl.enableVertexAttribArray(aUv);
  gl.vertexAttribPointer(aUv, 2, gl.FLOAT, false, 24, 16);

  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  if (isGL2) {
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
  } else {
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  }
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  return { canvas: glCanvas, w: bw, h: bh, cx: mx, cy: my };
}
