// PocketView ambient light: samples what each device screen is showing and
// returns a tiny image (for the blurred glow) plus a color palette.

export function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

export async function captureTab(format = 'jpeg') {
  if (document.visibilityState !== 'visible') return null;
  try {
    const url = await chrome.tabs.captureVisibleTab(format === 'png' ? { format: 'png' } : { format: 'jpeg', quality: 55 });
    return await loadImage(url);
  } catch (e) {
    return null;
  }
}

const toHex = (c) => '#' + [c.r, c.g, c.b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
const dist = (a, b) => Math.hypot(a.r - b.r, a.g - b.g, a.b - b.b);

export function luminance(c) {
  const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
}

export function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return { r: 91, g: 140, b: 255 };
  const n = parseInt(m[1], 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

export function mix(a, b, t) {
  return { r: a.r + (b.r - a.r) * t, g: a.g + (b.g - a.g) * t, b: a.b + (b.b - a.b) * t };
}

function palette(data) {
  const buckets = new Map();
  let sr = 0, sg = 0, sb = 0, n = 0;
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    sr += r; sg += g; sb += b; n++;
    const key = (r >> 4) << 8 | (g >> 4) << 4 | (b >> 4);
    const e = buckets.get(key) || { r: 0, g: 0, b: 0, n: 0 };
    e.r += r; e.g += g; e.b += b; e.n++;
    buckets.set(key, e);
  }
  const avg = { r: sr / n, g: sg / n, b: sb / n };
  const list = [...buckets.values()].map((e) => {
    const c = { r: e.r / e.n, g: e.g / e.n, b: e.b / e.n };
    const max = Math.max(c.r, c.g, c.b), min = Math.min(c.r, c.g, c.b);
    const sat = max ? (max - min) / max : 0;
    return { c, score: e.n * (0.35 + sat * 1.8) };
  }).sort((a, b) => b.score - a.score);

  const picks = [];
  for (const { c } of list) {
    if (picks.every((p) => dist(p, c) > 70)) picks.push(c);
    if (picks.length === 3) break;
  }
  while (picks.length < 3) picks.push(picks[picks.length - 1] || avg);
  return { avg, colors: picks };
}

/**
 * Crop a viewport rect from the captured tab image.
 * @returns {{url:string, avg:object, colors:object[], hex:string[]}}
 */
export function sample(img, rect, k) {
  const W = 48;
  const H = Math.max(8, Math.round(W * rect.h / Math.max(1, rect.w)));
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(img, rect.x * k, rect.y * k, rect.w * k, rect.h * k, 0, 0, W, H);
  const { data } = ctx.getImageData(0, 0, W, H);
  const p = palette(data);
  return { url: c.toDataURL('image/png'), avg: p.avg, colors: p.colors, hex: p.colors.map(toHex) };
}

export { toHex };
